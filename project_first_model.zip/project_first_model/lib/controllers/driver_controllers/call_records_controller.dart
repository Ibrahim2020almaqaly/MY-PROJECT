import 'package:url_launcher/url_launcher.dart';

import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/models/call_record_model.dart';
import 'package:project_first_model/services/firebase_services/call_record_service.dart';

class CallRecordController extends MasterController {
  late CallRecordService _callRecordService;

  CallRecordController() {
    _callRecordService = CallRecordService();
  }

  // static Future<void> _addCallRecord2(
  //     String userID, CallRecordModel callRecord) async {
  //   try {
  //     await CallRecordService.addCallRecord2(userID, callRecord);
  //   } catch (e) {
  //     rethrow;
  //   }
  // }

  Future<bool> didICallThisDriver(String userID, String driverID) async {
    try {
      final didI = await _callRecordService.didICallTheDriver(userID, driverID);

      return didI;
    } catch (_) {
      rethrow;
    }
  }

  Future<void> callAndRegister(
      String phoneNumber, String userID, String driverID,
      {bool record = true}) async {
    try {
      final can = await canLaunchUrl(Uri.parse('tel: $phoneNumber'));
      if (can) {
        if (record) {
          await addCallRecord(
            userID,
            CallRecordModel(
              userID: userID,
              driverID: driverID,
              driverNumber: phoneNumber,
              calltime: DateTime.now(),
            ),
          );
        }
        await Utiles.call(phoneNumber);
      }
    } catch (_) {
      rethrow;
    }
  }

  Future<void> addCallRecord(String userID, CallRecordModel callRecord) async {
    try {
      await _callRecordService.addCallRecord(userID, callRecord);
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> deleteCallRecord(String userID) async {
    try {
      await _callRecordService.deleteCallRecord(userID);
      update();
    } catch (_) {
      rethrow;
    }
  }
}
