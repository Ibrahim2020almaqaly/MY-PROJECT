import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/models/report_model.dart';
import 'package:project_first_model/services/firebase_services/report_service.dart';

class ReportController extends MasterController {
  final _reportService = ReportService();

  // Future<void> addDriverReport(String driverID, ReportsModel report) async {
  //   try {
  //     await _reportService.addDriverReport(driverID, report);
  //     update();
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  // Future<void> updateDriverReport(String driverID, ReportsModel report) async {
  //   try {
  //     await _reportService.updateDriverReport(driverID, report);
  //     update();
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  // Future<void> deleteDriverReport(String driverID) async {
  //   try {
  //     await _reportService.deleteDriverReport(driverID);
  //     update();
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  Future<void> addCustomerReport(
      String driverID, CustomersReport custReport) async {
    try {
      final customer = await _reportService.getCustomerReport(
          driverID, custReport.customerID);
      if (customer == null) {
        await _reportService.addCustomerReport(driverID, custReport);
      } else {
        await updateCustomerReport(driverID, custReport);
      }
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> updateCustomerReport(
      String driverID, CustomersReport custReport) async {
    try {
      await _reportService.updateCustomerReport(driverID, custReport);
      update();
    } catch (_) {
      rethrow;
    }
  }
}
