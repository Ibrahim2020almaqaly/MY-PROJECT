import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/models/rating_model.dart';
import 'package:project_first_model/services/firebase_services/rating_service.dart';

class RatingController extends MasterController {
  var _driverRatingModel = DriverRatingModel.defaultRate;
  StreamSubscription<DriverRatingModel>? _ratingStream;
  late RatingService _ratingService;
  late Query<DriverRatingModel> _higherRate;
  late Query<DriverRatingModel> _filteredHigherRate;

  var filterByRegion = '';
  var _isFiltered = false;

  RatingController() {
    _ratingService = RatingService();
    _higherRate = _ratingService.higherRateQuery(filterByRegion);
    _filteredHigherRate = _ratingService.higherRateQuery(filterByRegion);
    _ratingService.isThereUserStream.listen((loggedin) {
      if (loggedin) {
        _ratingStream ??=
            _ratingService.listernToRatingChnages().listen((rate) {
          if (_driverRatingModel != rate) {
            _driverRatingModel = rate;
            update();
          }
        });
      } else {
        if (_ratingStream != null) {
          _ratingStream?.cancel();
        }
        _ratingStream = null;
      }
    });
    // if (_ratingService.isThereUser) {
    //   _ratingStream = _ratingService.listernToRatingChnages().listen((rate) {
    //     if (_driverRatingModel != rate) {
    //       _driverRatingModel = rate;
    //       update();
    //     }
    //   });
    // }
  }

  Query<DriverRatingModel> get getHigherRateDriver {
    return _higherRate;
  }

  Query<DriverRatingModel> get getFilteredHigherRateDriver {
    return _filteredHigherRate;
  }

  void refershHigherRate() {
    _ratingService.refershHigherDriverRate();
    _higherRate = _ratingService.higherRateQuery(filterByRegion);
  }

  void refershFilteredHigherRate() {
    _ratingService.refershHigherDriverRate();
    _filteredHigherRate = _ratingService.higherRateQuery(filterByRegion);
  }

  void addFilter(String region) {
    if (region != filterByRegion) {
      filterByRegion = region;
      _filteredHigherRate = _ratingService.higherRateQuery(filterByRegion);
      _isFiltered = true;
      update();
    }
  }

  void clearFilter() {
    if (_isFiltered) {
      filterByRegion = '';
      _filteredHigherRate = _ratingService.higherRateQuery(filterByRegion);
      _isFiltered = false;
      update();
    }
  }

  DriverRatingModel get getCurrentDriverRating {
    return _driverRatingModel;
  }

  Future<DriverRatingModel> getDriverRate(String driverID) async {
    try {
      final rate = await _ratingService.getDriverRate(driverID) ??
          DriverRatingModel.defaultRate;
      update();
      _driverRatingModel = rate;
      return rate;
    } catch (_) {
      rethrow;
    }
  }

  Future<TripRatingModel> getTripRate(String driverID, String tripID) async {
    try {
      final rate = await _ratingService.getTripRate(driverID, tripID) ??
          TripRatingModel.defaultRate;
      update();
      return rate;
    } catch (_) {
      rethrow;
    }
  }

  /// save the stars count so we can use it in
  /// updating the rate
  Future<CustomerRatingModel> getCustomerRating(
      String driverID, String tripID, String customerID) async {
    try {
      final rate = await _ratingService.getCustomerRating(
              driverID, tripID, customerID) ??
          CustomerRatingModel.defaultCustomerRate;
      update();
      // _oldCustomerRating = rate;
      return rate;
    } catch (_) {
      rethrow;
    }
  }

  // Future<void> addDriverRate(String driverID, DriverRatingModel rate) async {
  //   try {
  //     var oldRate = await getDriverRate(driverID);
  //     if (oldRate == DriverRatingModel.defaultRate) {
  //       await _ratingService.addDriverRate(driverID, rate);
  //     } else {
  //       oldRate = oldRate.copyWith(
  //         driverName: rate.driverName,
  //         driverPic: rate.driverPic,
  //         region: rate.region,
  //       );
  //       await updateDriverRate(driverID, oldRate);
  //     }
  //     update();
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  // Future<void> updateDriverRate(String driverID, DriverRatingModel rate) async {
  //   try {
  //     await _ratingService.updateDriverRate(driverID, rate);
  //     update();
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  Future<void> deleteDriverRate(String driverID, DriverRatingModel rate) async {
    try {
      await _ratingService.deleteDriverRate(driverID);
      update();
    } catch (_) {
      rethrow;
    }
  }

  // Future<void> addTripRate(
  //     String driverID, String tripID, TripRatingModel rate) async {
  //   try {
  //     final oldRate = await getTripRate(driverID, tripID);
  //     if (oldRate == TripRatingModel.defaultRate) {
  //       await _ratingService.addTripRate(driverID, tripID, rate);
  //     } else {
  //       await updateTripRate(driverID, tripID, oldRate);
  //     }
  //     update();
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  // Future<void> updateTripRate(
  //     String driverID, String tripID, TripRatingModel rate) async {
  //   try {
  //     await _ratingService.updateTripRate(driverID, tripID, rate);
  //     update();
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  Future<void> deleteTripRate(String driverID, String tripID) async {
    try {
      await _ratingService.deleteTripRate(driverID, tripID);
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> addCustomerRate(
      String driverID, String tripID, CustomerRatingModel custRate) async {
    try {
      await _ratingService.addCustomerRate(driverID, tripID, custRate);
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> updateCustomerRate(String driverID, String tripID,
      CustomerRatingModel custRate, int oldRateStar) async {
    try {
      await _ratingService.updateCustomerRate(
          driverID, tripID, custRate, oldRateStar);
      update();
    } catch (_) {
      rethrow;
    }
  }

  @override
  void dispose() async {
    await _ratingStream?.cancel();
    _ratingService.dispose();
    super.dispose();
  }
}
