import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/screens/profile_pages/account_settings_screen.dart';
import 'package:project_first_model/screens/trip_pages/search_trips.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/handel_connection.dart';

import '../screens/trip_pages/add_trip_screen.dart';

class BottomNavBarController extends MasterController {
  int index = 0;
  Map<String, Widget> items = {
    'home': const Icon(
      FontAwesomeIcons.house,
      size: 28,
    ),
    'addTrip': const Icon(
      FontAwesomeIcons.circlePlus,
      size: 28,
    ),
    'search': const Icon(
      FontAwesomeIcons.magnifyingGlass,
      size: 28,
    ),
    'profile': GetBuilder<UserController>(
      init: UserController(),
      builder: (prov) {
        return CircleSqureImage(
          pic: prov.getUserData.userPic,
          height: 100,
          width: 100,
          radius: 50,
          id: prov.getUserData.userPic,
        );
      },
    ),
  };
  List<Widget> screens = const [
    HandelConnection(),
    AddTripScreen(),
    SearchTrips(),
    AccountSettingsScreen(),
  ];

  BottomNavBarController() {
    index = 0;
  }

  // Widget get getScreen {
  //   return screens[index];
  // }

  void indexChanged(int idx) {
    if (idx != index) {
      index = idx;
      update();
    }
  }
}
