import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/models/filter_model.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/services/firebase_services/trip_service_v2.dart';

class TripFilterController extends MasterController {
  late Query<TripModel> _filteredTripsQuery;
  late final TripServiceV2 _tripService;

  TripFilterController() {
    _tripService = TripServiceV2();
    _filteredTripsQuery = _tripService.filteredTripQuery;
  }

  var _filtersModel = const FiltersModel();
  var _isFiltered = false;

  FiltersModel get filter {
    return _filtersModel;
  }

  bool get isTherefilter {
    return _isFiltered;
  }

  Query<TripModel> get getFilterdTripsQuery {
    _tripService.requestFilterTrips(_filtersModel);
    _filteredTripsQuery = _tripService.filteredTripQuery;
    return _filteredTripsQuery;
  }

  Query<TripModel> getMyRegionTripsQuery(String region) {
    _tripService.requestFilterTrips(FiltersModel(from: region));

    return _tripService.filteredTripQuery;
  }

  void refershFilteredTripQuery() {
    _tripService.refershFilteredTripQuery(_filtersModel);
    _filteredTripsQuery = _tripService.filteredTripQuery;
    update();
  }

  void addFilters(FiltersModel filter) async {
    if (_filtersModel != filter) {
      _filtersModel = filter;
      _isFiltered = true;

      _tripService.requestFilterTrips(_filtersModel);
      _filteredTripsQuery = _tripService.filteredTripQuery;
      update();
    }
  }

  void clearFilter() {
    if (_isFiltered) {
      _filtersModel = FiltersModel.defaultFilters;
      _isFiltered = false;
      update();
    }
  }
}
