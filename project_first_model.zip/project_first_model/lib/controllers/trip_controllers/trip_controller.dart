import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/helpers/custom_exception.dart';

import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/services/firebase_services/trip_service_v2.dart';

class TripController extends MasterController {
  late final TripServiceV2 _tripService;
  late Query<TripModel> _tripsQuery;
  late Query<TripModel> _tripsHistoryQuery;
  late Query<TripModel> _higherRatingTripsQuery;

  TripController() {
    _tripService = TripServiceV2();
    _tripsQuery = _tripService.tripQuery;
    _higherRatingTripsQuery = _tripService.higherRateTripQuery;
  }

  Query<TripModel> get _getNonFilteredTripsQuery {
    return _tripsQuery;
  }

  Query<TripModel> get _getHigherTripsQuery {
    return _higherRatingTripsQuery;
  }

  Query<TripModel> get getTripsQuery {
    return _getNonFilteredTripsQuery;
  }

  Query<TripModel> get getTripsHistoryQuery {
    try {
      _tripsHistoryQuery = _tripService.tripHistoryQuery;
      return _tripsHistoryQuery;
    } on Exception catch (_) {
      rethrow;
    }
  }

  Query<TripModel> get getHigherTripsQuery {
    return _getHigherTripsQuery;
  }

  Future<String> getDriverPhoneNumber(String userID, String tripID) async {
    try {
      final phoneNumber =
          await _tripService.getDriverPhoneNumber(userID, tripID);

      return phoneNumber;
    } catch (_) {
      rethrow;
    }
  }

  void refershNonFilteredTripsQuery() {
    _tripService.refershTripQuery();
    _tripsQuery = _tripService.tripQuery;
    update();
  }

  void refershTripsHistoryQuery() {
    _tripService.refershTripHistoryQuery();
    _tripsQuery = _tripService.tripHistoryQuery;
    update();
  }

  Future<TripModel?> findByUserId(String userId) async {
    return await _tripService.findByUserId(userId);
  }

  Future<TripModel?> findTripById(String tripId) async {
    return await _tripService.findTripById(tripId);
  }

  Future<TripModel?> findTripHistoryById(String tripId) async {
    return await _tripService.findTripHistoryById(tripId);
  }

  Future<TripModel> addTrip(TripModel trip) async {
    try {
      final tripIddoc = await _tripService.addTrip(trip);

      trip = trip.copyWith(
          tripId: tripIddoc); //await updateTrip(trip, id: tripIddoc);

      update();
      return trip;
    } catch (e) {
      rethrow;
    }
  }

  Future<TripModel> updateTrip(TripModel trip, {String id = ''}) async {
    try {
      await _tripService.updateTrip(trip, id);

      update();
      return trip;
    } catch (e) {
      rethrow;
    }
  }

  Future<void> deleteTrip(String tripId) async {
    try {
      if (tripId == '' || tripId.isEmpty) {
        throw CustomException('لا يوجد معرف الرحلة');
      }
      await _tripService.deleteTrip(tripId);

      update();
    } catch (e) {
      rethrow;
    }
  }

  Future<void> deleteTripHistory(String tripId) async {
    try {
      if (tripId == '' || tripId.isEmpty) {
        throw CustomException('لا يوجد معرف الرحلة');
      }
      await _tripService.deleteTripHistory(tripId);

      update();
    } catch (e) {
      rethrow;
    }
  }
}
