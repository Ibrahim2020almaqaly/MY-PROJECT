import 'package:project_first_model/controllers/master_controller.dart';

class SecondaryCityController extends MasterController {
  final List<String> _cities = [];

  List<String> get cities {
    return [..._cities];
  }

  void resetCities() {
    _cities.clear();
    update();
  }

  void addCity(String cityName) {
    _cities.add(cityName);
    update();
  }

  void addCities(List<String> cityName) {
    _cities.addAll(cityName);
    update();
  }

  void removeCity(String cityName) {
    _cities.remove(cityName);
    update();
  }

  void restCities() {
    _cities.clear();
    update();
  }
}
