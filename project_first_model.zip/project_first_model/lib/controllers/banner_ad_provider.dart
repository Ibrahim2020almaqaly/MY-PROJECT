// import 'package:flutter/material.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';
// import 'package:project_first_model/services/ads/google_mob_ads.dart';
// import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';

// class BannerAdProvider {
//   // static BannerAd? _bannerAd;

//   static Future<Widget> buildBannerWidget(
//     BuildContext context,
//     AdSize adSize,
//     String bannerUnitID,
//     bool inlineAd,
//   ) async {
//     AdSize size = adSize;

//     if (inlineAd) {
//       final medaiQuery = MediaQuery.of(context);
//       size = //AdSize(width: medaiQuery.size.width.toInt(), height: 200);
//           AdSize.getInlineAdaptiveBannerAdSize(
//         medaiQuery.size.width.toInt(),
//         200,
//       );
//     }

//     var bannerAd = await _buildBannerAd(size, bannerUnitID);
//     await bannerAd.load();
//     if (inlineAd) {
//       size = (await bannerAd.getPlatformAdSize())!;
//     }

//     return Container(
//       margin: CustomEdgeInsets.all(5),
//       height: size.height.toDouble(), //_bannerAd.size.height.toDouble(),
//       width: size.width.toDouble(), //_bannerAd.size.width.toDouble(),
//       alignment: Alignment.center,
//       child: AdWidget(ad: bannerAd),
//     );
//   }

//   static Future<BannerAd> _buildBannerAd(
//       AdSize adSize, String bannerUnitID) async {
//     return GoogleMobAds.createBannerAd(adSize, bannerUnitID);
//   }
// }
