import 'package:get/get.dart';
import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/models/alarm_model.dart';
import 'package:project_first_model/services/app_settings.dart';
import 'package:project_first_model/services/database/app_database.dart';

class AlarmController extends MasterController {
  final List<AlarmModel> _alarms = [];
  final _appDB = AppDatabase();

  AlarmController() {
    fetchAllAlarms();
  }

  List<AlarmModel> get alarms {
    return [..._alarms];
    // .followedBy(
    //   [
    //     AlarmModel(
    //       isEnabled: 1,
    //       tripId: '',
    //       tripTime: DateTime.now(),
    //       alarmId: 1,
    //       driverName: 'nooooooo',
    //       driverPhone: '9999999',
    //     ),
    //   ],
    // ).toList();
  }

  bool checkIfTheTripIsALreadyAdded(String tripID) {
    for (var alarm in _alarms) {
      if (alarm.tripId == tripID) {
        return true;
      }
    }
    return false;
  }

  Future<void> fetchAllAlarms() async {
    try {
      final userID =
          Get.find<FirebaseAuthController>().getCurrentUser?.uid ?? '';
      List<AlarmModel> tempList = [];
      final res = await _appDB.getItemsFiltered(
        AlarmModel.alarmsTableName,
        whereColumnName: AlarmModel.userIdCol,
        filter: userID,
      );

      for (var alarm in res) {
        tempList.add(AlarmModel.fromMap(alarm));
      }

      _alarms.clear();
      _alarms.addAll([...tempList]);
      update();
    } catch (_) {
      rethrow;
    }
  }

  /// First we add alarm
  /// then we add it to the list
  /// after that we get the id of the inserted model
  /// finally we set alarm by the id which was returned
  /// by this method.
  Future<int> addAlarm(AlarmModel model) async {
    try {
      final colorIndex = AlarmModel.gradientColorIndex(model.tripTime);
      model = model.copyWith(colorIndex: colorIndex);
      final alarmID = await _appDB.insertItem(
        AlarmModel.alarmsTableName,
        model.toMap(),
      );

      final remind =
          AppSettings.getSettingValue<int>(AppSettings.remindMeKey, 15);
      final subDate = DateTimeHelpers.substuctDate(model.tripTime, remind);

      if (!DateTimeHelpers.isDateTimeNOWAfter(subDate)) {
        model = model.copyWith(tripTime: subDate);
      }

      model = model.copyWith(alarmId: alarmID);

      _alarms.add(model);
      update();

      return alarmID;
    } catch (_) {
      rethrow;
    }
  }

  Future<void> updateAlarm(AlarmModel model) async {
    try {
      final colorIndex = AlarmModel.gradientColorIndex(model.tripTime);
      model = model.copyWith(colorIndex: colorIndex);

      final alarmIndex =
          _alarms.indexWhere((alarm) => alarm.alarmId == model.alarmId);

      if (alarmIndex >= 0) {
        await _appDB.updateItem(
          AlarmModel.alarmsTableName,
          AlarmModel.alarmIdCol,
          model.toMap(),
        );

        _alarms[alarmIndex] = model;
        update();
      }
    } catch (_) {
      rethrow;
    }
  }

  Future<void> disableAlarm(int id) async {
    try {
      var model = _alarms.firstWhere((element) => element.alarmId == id);
      final colorIndex = AlarmModel.gradientColorIndex(model.tripTime);
      model = model.copyWith(colorIndex: colorIndex, isEnabled: 0);

      final alarmIndex =
          _alarms.indexWhere((alarm) => alarm.alarmId == model.alarmId);

      if (alarmIndex >= 0) {
        await _appDB.updateItem(
          AlarmModel.alarmsTableName,
          AlarmModel.alarmIdCol,
          model.toMap(),
        );

        _alarms[alarmIndex] = model;
        update();
      }
    } catch (_) {
      rethrow;
    }
  }

  Future<void> deleteAlarm(int alarmID) async {
    try {
      final alarmIndex =
          _alarms.indexWhere((alarm) => alarm.alarmId == alarmID);
      if (alarmIndex >= 0) {
        await _appDB.deleteItem(
          AlarmModel.alarmsTableName,
          AlarmModel.alarmIdCol,
          alarmID,
        );

        _alarms.removeAt(alarmIndex);
        update();
      }
    } catch (_) {
      rethrow;
    }
  }

  Future<void> disableAllAlarms() async {
    for (var alarm in _alarms) {
      await updateAlarm(alarm.copyWith(isEnabled: 0));
    }
  }
}
