import 'dart:io';

import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/models/user_modelv2.dart';
import 'package:project_first_model/services/firebase_services/user_service.dart';

class UserController extends MasterController {
  late UserService _userService;
  var _userModel = UserModelV2.defaultUser;

  UserController() {
    _userService = UserService();
    requestMyData();
  }

  Future<UserModelV2> requestMyData() async {
    try {
      final user = await _userService.getMyData();
      _userModel = user;
      update();

      return user;
    } catch (_) {
      rethrow;
    }
  }

  UserModelV2 get getUserData {
    return _userModel;
  }

  bool get isUserHasAccount {
    return (_userModel.userName.isNotEmpty && _userModel.userName != '') ||
        (_userModel.userPhoneNumber.isNotEmpty &&
            _userModel.userPhoneNumber != '');
  }

  Future<bool> bringUserWithThatPhone(String phoneNumber) async {
    final exist = await _userService.getUserWithPhone(phoneNumber);
    return exist != null;
  }

  String? checkIfNotEmpty() {
    var error = 'يجب تسجيل بياناتك في الملف الشخصي قبل إضافة رحلة';
    error += '\n معلومات إضافية:';
    var thereIsError = false;
    if (_userModel.userName.isEmpty) {
      error += '\n إسم السائق غير موجود "إجباري" ';
      thereIsError = true;
    }
    if (_userModel.userPhoneNumber.isEmpty) {
      error += '\n رقم السائق غير موجود "إجباري" ';
      thereIsError = true;
    }
    if (_userModel.userPic == '' || _userModel.userPic.isEmpty) {
      error += '\n صورة السائق غير موجودة "إجباري" ';
      thereIsError = true;
    }
    if ((_userModel.userCarPic1 == '' || _userModel.userCarPic1.isEmpty) &&
        (_userModel.userCarPic2 == '' || _userModel.userCarPic2.isEmpty)) {
      error += '\n يجب توفر صورة واحدة على الأقل للمركبة "إختياري" ';
      // thereIsError = true;
    }

    return thereIsError ? error : null;
  }

  ///this Method is to check if the the image exist and
  ///save it to the fire storage
  Future<String> _saveImageHandler(
    String? pic,
    String type,
    bool isUpdate,
  ) async {
    try {
      String picUrl = '';
      if (pic != null) {
        if (pic.contains('https://firebasestorage')) {
          return pic;
        } else if (pic.isNotEmpty && pic != '') {
          picUrl = await (isUpdate
              ? _userService.updateImage(File(pic), type)
              : _userService.saveImage(File(pic), type));
        } else {
          await _userService.deleteImage(type);
        }
      }
      return picUrl;
    } catch (_) {
      rethrow;
    }
  }

  Future<void> addUser(UserModelV2 model) async {
    try {
      final userPic = await _saveImageHandler(
        model.userPic,
        'Driver',
        false,
      );
      final carPic1 = await _saveImageHandler(
        model.userCarPic1,
        'Car1',
        false,
      );
      final carPic2 = await _saveImageHandler(
        model.userCarPic2,
        'Car2',
        false,
      );
      model = model.copyWith(
        userPic: userPic,
        userCarPic1: carPic1,
        userCarPic2: carPic2,
      );
      await _userService.addUser(model);
      _userModel = model;
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> updateUser(UserModelV2 model) async {
    try {
      final userPic = await _saveImageHandler(
        model.userPic,
        'Driver',
        false,
      );
      final carPic1 = await _saveImageHandler(
        model.userCarPic1,
        'Car1',
        false,
      );
      final carPic2 = await _saveImageHandler(
        model.userCarPic2,
        'Car2',
        false,
      );
      model = model.copyWith(
        userPic: userPic,
        userCarPic1: carPic1,
        userCarPic2: carPic2,
      );
      await _userService.updateUser(model);
      _userModel = model;
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> deleteUser(String userId) async {
    try {
      await _userService.deleteImageFile();
      await _userService.deleteUser(userId);
      _userModel = UserModelV2.defaultUser;
      update();
    } catch (_) {
      rethrow;
    }
  }
}
