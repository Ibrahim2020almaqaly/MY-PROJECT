import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/services/firebase_services/auth_service.dart';

class FirebaseAuthController extends MasterController {
  late AuthService _authService;
  var _isLoading = false;
  var _verifiyState = VerificationState.none;
  User? _currentUser;
  StreamSubscription<VerificationState>? _verificationStateListener;
  late StreamSubscription<User?> _userIDListener;
  var _buttonPressed = false;

  // StreamSubscription<User?>? _authChangesListener;

  FirebaseAuthController() {
    _authService = AuthService();
    _userIDListener = _authService.listenToUserIDChnages().listen((userID) {
      if (userID != _currentUser) {
        setUser = userID;
      }
    });
    setUser = _authService.getCurrentUser;
    // _authChangesListener =
    //     _authService.listenToAuthStateChanges().listen((user) {
    //   //
    // });
  }

  void changeButtonStatus(bool val) {
    if (val != _buttonPressed) {
      update();
      _buttonPressed = val;
    }
  }

  bool get getbuttonStatus {
    return _buttonPressed;
  }

  Future<bool> validToken() async {
    final valid = await _authService.validToken();
    return valid;
  }

  User? get getCurrentUser {
    return _currentUser;
  }

  bool get isThereAUserLoggedin {
    return _currentUser != null;
  }

  bool get isUserDisabled {
    return _authService.idDisabled;
  }

  Future<bool> checkFromDBIfDisabled(String phoneNumber) async {
    return await _authService.checkFromDBIfDisabled(phoneNumber);
  }

  set setUser(User? user) {
    _currentUser = user;
    update();
  }

  bool get isCodeSent {
    final vId = _authService.getVerificationID;
    return vId.isNotEmpty && vId != '';
  }

  bool get isCodeReciveved {
    final sms = _authService.getSMSCode;
    return sms.isNotEmpty && sms != '';
  }

  String get smsCode {
    return _authService.getSMSCode;
  }

  bool get getLoadingStatus {
    return _isLoading;
  }

  void _beginSubscribtion() {
    _authService.initializeStream();
    _verificationStateListener =
        _authService.listenToVerificationState().listen(
      (state) {
        if (state != _verifiyState) {
          _verifiyState = state;
          switch (state) {
            case VerificationState.none:
              break;
            case VerificationState.codeSent:
              _isLoading = false;
              changeButtonStatus(false);
              update();
              break;
            case VerificationState.completed:
              // _closeSubscribtion();
              update();
              break;
            case VerificationState.failed:
              _isLoading = false;
              changeButtonStatus(false);
              update();
              // _closeSubscribtion();
              break;
            default:
          }
        }
      },
    );
  }

  void closeSubscribtion() async {
    if (_verifiyState == VerificationState.completed ||
        _verifiyState == VerificationState.failed) {
      if (_verificationStateListener != null) {
        await _verificationStateListener?.cancel();
      }
      _verifiyState = VerificationState.none;
      _authService.closeStream();
      update();
    }
  }

  Future<void> sendOTPMSG(String phoneNumber) async {
    try {
      _markAsLoading();
      _beginSubscribtion();
      await Future.delayed(const Duration(seconds: 2));
      await _authService.beginToVerifyUser(phoneNumber);
    } catch (_) {
      rethrow;
    } finally {
      _isLoading = false;
      update();
    }
  }

  void _markAsLoading() {
    _isLoading = true;
    update();
  }

  Future<void> verifiyUser(String otbCode) async {
    try {
      _markAsLoading();
      await Future.delayed(const Duration(seconds: 3));
      await _authService.confirmUser(otbCode);
    } catch (_) {
      rethrow;
    } finally {
      _isLoading = false;
      update();
    }
  }

  Stream<User?> watchAuthChanges() {
    return _authService.listenToAuthStateChanges();
  }

  Future<void> logOut() async {
    await _authService.userLogOut();
    update();
  }

  @override
  void dispose() async {
    closeSubscribtion();
    _authService.dispose();
    await _userIDListener.cancel();
    // disposed = true;
    super.dispose();
  }
}
