import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/models/user_model.dart';
import 'package:project_first_model/services/database/app_database.dart';

class UserLocalController extends MasterController {
  UserModel _user = UserModel.defaultModel;
  final AppDatabase _appDB = AppDatabase();

  UserLocalController() {
    getUserData();
  }

  UserModel get getUser {
    return _user;
  }

  String? checkIfNotEmpty() {
    var error = 'يجب تسجيل بياناتك في الملف الشخصي قبل إضافة رحلة';
    error += '\n معلومات إضافية:';
    var thereIsError = false;
    if (_user.driverName.isEmpty) {
      error += '\n إسم السائق غير موجود"إجباري" ';
      thereIsError = true;
    }
    if (_user.phoneNumber.isEmpty) {
      error += '\n رقم السائق غير موجود"إجباري" ';
      thereIsError = true;
    }
    if (_user.driverPic == null || _user.driverPic!.isEmpty) {
      error += '\n صورة السائق غير موجودة"إجباري" ';
      thereIsError = true;
    }
    if (_user.carPic1 == null ||
        _user.carPic1!.isEmpty ||
        _user.carPic2 == null ||
        _user.carPic2!.isEmpty) {
      error += '\n صور المركبة غير موجودة"إختياري" ';
    }

    return thereIsError ? error : null;
  }

  ///if User Dose Not Exsist We Create Custom User So
  ///That We Only Have To Operation Update And GetUser
  Future<UserModel> getUserData() async {
    final data = await _appDB.getItems(UserModel.userModelTableName);
    if (data.isEmpty) {
      final id = await _appDB.insertItem(
        UserModel.userModelTableName,
        _user.toMap(),
      );
      if (id > 0) {
        final user = await _appDB.getItemsFiltered(
          UserModel.userModelTableName,
          whereColumnName: UserModel.idUserCol,
          filter: id,
        );
        if (user.isNotEmpty) {
          _user = UserModel.fromMap(user.first);
        }
      }
    } else {
      _user = UserModel.fromMap(data.first);
    }
    update();
    return _user;
  }

  Future<void> adduser(UserModel model) async {
    final id = await _appDB.insertItem(
      UserModel.userModelTableName,
      model.toMap(),
    );
    _user = model;
    _user = _user.copyWith(idUser: id);
    update();
  }

  Future<void> updateUserData(UserModel model) async {
    _user = model;

    await _appDB.updateItem(
      UserModel.userModelTableName,
      UserModel.idUserCol,
      model.toMap(),
    );
    update();
  }
}
