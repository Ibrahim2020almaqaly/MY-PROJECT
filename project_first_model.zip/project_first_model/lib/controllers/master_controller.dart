import 'package:get/get.dart';

class MasterController extends GetxController {
  var _isLoading = false;

  bool get isLoading => _isLoading;

  set isLoading(bool loading) {
    _isLoading = loading;
    update();
  }
}
