import 'dart:io';

import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/models/error_report_model.dart';
import 'package:project_first_model/services/firebase_services/error_report_service.dart';

class ErrorReportController extends MasterController {
  late final ErrorReportService _errorReportService;

  ErrorReportController() {
    _errorReportService = ErrorReportService();
  }

  Future<void> addErrorReport(ErrorReportModel errorReport) async {
    try {
      final alreadyAddSuggestion =
          await _errorReportService.getUserErrorReport(errorReport.userID);
      if (errorReport.errorScreenImgURL != '' &&
          errorReport.errorScreenImgURL!.isNotEmpty) {
        final imgUrl = await _errorReportService.saveImage(
          File(errorReport.errorScreenImgURL!),
        );
        errorReport = errorReport.copyWith(errorScreenImgURL: imgUrl);
      } else {
        await _errorReportService.deleteImage();
      }

      if (alreadyAddSuggestion == null) {
        await _errorReportService.addUserErrorReport(errorReport);
      } else {
        await updateErrorReport(errorReport);
      }
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> updateErrorReport(ErrorReportModel errorReport) async {
    try {
      await _errorReportService.updateUserErrorReport(errorReport);
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> deleteErrorReport(String userID) async {
    try {
      await _errorReportService.deleteUserErrorReport(userID);
      update();
    } catch (_) {
      rethrow;
    }
  }
}
