import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/models/privacy_model.dart';
import 'package:project_first_model/services/firebase_services/privacy_service.dart';

class PrivacyController extends MasterController {
  late PrivacyService _privacyService;

  PrivacyController() {
    _privacyService = PrivacyService();
  }

  Future<PrivacyModel> getPrivacy() async {
    try {
      final res = await _privacyService.getPrivacy();

      return res;
    } on Exception catch (_) {
      rethrow;
    }
  }

  Future<void> addPrivacy(PrivacyModel privacy) async {
    try {
      await _privacyService.addPrivacy(privacy);
    } on Exception catch (_) {
      rethrow;
    }
  }
}
