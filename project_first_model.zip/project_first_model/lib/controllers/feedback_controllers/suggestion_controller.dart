import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/models/suggestion_model.dart';
import 'package:project_first_model/services/firebase_services/suggestions_service.dart';

class SuggestionController extends MasterController {
  late final SuggestionsService _suggestionsService;

  SuggestionController() {
    _suggestionsService = SuggestionsService();
  }

  Future<void> addSuggestion(SuggestionModel suggestion) async {
    try {
      final alreadyAddSuggestion =
          await _suggestionsService.getUserSuggestions(suggestion.userID);
      if (alreadyAddSuggestion == null) {
        await _suggestionsService.addUserSuggestion(suggestion);
      } else {
        await updateSuggestion(suggestion);
      }
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> updateSuggestion(SuggestionModel suggestion) async {
    try {
      await _suggestionsService.updateUserSuggestion(suggestion);
      update();
    } catch (_) {
      rethrow;
    }
  }

  Future<void> deleteSuggestion(String userID) async {
    try {
      await _suggestionsService.deleteUserSuggestion(userID);
      update();
    } catch (_) {
      rethrow;
    }
  }
}
