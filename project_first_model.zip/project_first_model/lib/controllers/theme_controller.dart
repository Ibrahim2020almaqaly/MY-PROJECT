import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/master_controller.dart';
import 'package:project_first_model/services/app_settings.dart';

class ThemeController extends MasterController {
  ThemeMode _themeMode = ThemeMode.system;
  final themeModes = {
    0: ThemeMode.system,
    1: ThemeMode.light,
    2: ThemeMode.dark,
  };

  ThemeController() {
    final mode = AppSettings.getSettingValue(AppSettings.themeKey, 1);
    _themeMode = themeModes[mode]!;
    Get.changeThemeMode(_themeMode);
  }

  ThemeMode get themeMode {
    return _themeMode;
  }

  bool get isDarkMode {
    if (_themeMode == ThemeMode.system) {
      final brightness =
          SchedulerBinding.instance.platformDispatcher.platformBrightness;
      return brightness == Brightness.dark;
    } else {
      return _themeMode == ThemeMode.dark;
    }
  }

  void toggleTheme(int mode) {
    final theme = themeModes[mode]!;
    if (theme != _themeMode) {
      _themeMode = theme;
      Get.changeThemeMode(_themeMode);
      update();
    }
  }
}

class MyThemes {
  static TextTheme? textTheme;
  static const _dARKTHEMETEXTCOLOR = Colors.white;
  // static const _lIGHTTHEMETEXTCOLOR = Colors.black;
  static const _primaryColor = Color(0xFF00BEAB); //Colors.amber;
  // static const _primaryColorLighter =
  //     Color.fromARGB(255, 245, 247, 249); //Colors.amber;
  static const _deepColor = Color(0xFF6ACACA); //Colors.deepOrange;
  static const _deepAccentColor = Color(0xFF509B9B); //Colors.deepOrangeAccent;

  //  final darkTheme = ThemeData(
  // //   brightness: Brightness.dark,
  // //  scaffoldBackgroundColor: Colors.grey.shade900,
  //   splashColor: Colors.black,
  //   appBarTheme: AppBarTheme(
  //     titleTextStyle: _titleTextStyle(Colors.white),
  //     elevation: 0,
  //     toolbarTextStyle: const TextStyle(color: Colors.white),
  //     foregroundColor: Colors.white,
  //     backgroundColor: Colors.black, //_deepColor.withAlpha(100), //.shade700,
  //     iconTheme: _iconThemeData(_primaryColorLighter),
  //     actionsIconTheme: _iconThemeData(_primaryColor),
  //     systemOverlayStyle: _systemUiOverlayStyle(Colors.grey.shade900, true),
  //     scrolledUnderElevation: 0.2,
  //   ),
  //   bottomNavigationBarTheme: _bottomNavigationBarThemeData(
  //     backColor: _deepColor.withAlpha(100),
  //     selectIcon: _iconThemeData(_primaryColor),
  //     unselectIcon: _iconThemeData(_primaryColor, opacity: 0.5),
  //   ),
  //   floatingActionButtonTheme: const FloatingActionButtonThemeData(
  //     backgroundColor: _deepAccentColor,
  //     foregroundColor: _dARKTHEMETEXTCOLOR,
  //     elevation: 3.0,
  //   ),
  //   primaryColor: Colors.black,
  //   colorScheme: const ColorScheme.dark().copyWith(
  //     primary: _primaryColorLighter,
  //     brightness: Brightness.dark,
  //   ),
  //   fontFamily: "Cairo",
  //   useMaterial3: true,
  //   iconTheme: _iconThemeData(_primaryColorLighter),
  //   // primarySwatch: Colors.amber, //_primaryColor, //Colors.amber,
  //   focusColor: _deepAccentColor,
  //   elevatedButtonTheme: _elevatedButtonThemeData(_primaryColor),
  //   textButtonTheme: _textButtonThemeData(_primaryColor),
  //   outlinedButtonTheme: _outlinedButtonThemeData(_primaryColor),
  //   buttonTheme: _buttonThemeData(_primaryColor),
  //   primaryIconTheme: _iconThemeData(_primaryColorLighter),
  //   textSelectionTheme: _textSelectionThemeData(
  //     _primaryColor,
  //     _primaryColorLighter,
  //   ),
  //   textTheme: TextTheme(
  //     headlineMedium: _textTheme(44.0),
  //     headlineSmall: _textTheme(34.0),
  //   ),
  //   pageTransitionsTheme: _pageTransitionsTheme(),
  //   iconButtonTheme: IconButtonThemeData(
  //     style: IconButton.styleFrom(),
  //   ),
  //   cardTheme: const CardTheme(
  //     surfaceTintColor: Color.fromARGB(255, 23, 23, 23),
  //   ),
  //   dividerTheme: _dividerThemeData(Colors.white24),
  //   // cardTheme: const CardTheme(
  //   //   color: Colors.black,
  //   // ),
  //   timePickerTheme: const TimePickerThemeData(
  //     backgroundColor: Color.fromARGB(255, 23, 23, 23),
  //   ),
  //   dialogTheme: _dialogTheme(Colors.grey.shade900),
  // );

  static final lightTheme = ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: Colors.white,
    // const Color.fromARGB(
    //     246, 255, 254, 254), //_deepColor.withAlpha(50), //_deepColor[50],
    splashColor: Colors.white,
    appBarTheme: AppBarTheme(
      titleTextStyle: _titleTextStyle(Colors.black),
      elevation: 0,
      toolbarTextStyle: const TextStyle(color: Colors.black),
      foregroundColor: Colors.black,
      backgroundColor: Colors.white, //_deepColor.withAlpha(100), //.shade700,
      iconTheme: _iconThemeData(_primaryColor),
      actionsIconTheme: _iconThemeData(_primaryColor),
      systemOverlayStyle: _systemUiOverlayStyle(Colors.white, false),
      scrolledUnderElevation: 0.2,
    ),
    bottomNavigationBarTheme: _bottomNavigationBarThemeData(
      backColor: _deepColor.withAlpha(100),
      selectIcon: _iconThemeData(_primaryColor),
      unselectIcon: _iconThemeData(_primaryColor, opacity: 0.5),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: _deepAccentColor,
      foregroundColor: _dARKTHEMETEXTCOLOR,
      elevation: 3.0,
    ),
    // primaryColor: Colors.white,
    colorScheme: const ColorScheme.light().copyWith(
      primary: _primaryColor,
      brightness: Brightness.light,
    ),
    fontFamily: "Cairo",
    useMaterial3: true,
    iconTheme: _iconThemeData(_primaryColor),
    // primarySwatch: Colors.amber, //_primaryColor, //Colors.amber,
    focusColor: _deepAccentColor,
    elevatedButtonTheme: _elevatedButtonThemeData(_primaryColor),
    outlinedButtonTheme: _outlinedButtonThemeData(_primaryColor),
    textButtonTheme: _textButtonThemeData(_primaryColor),
    buttonTheme: _buttonThemeData(_primaryColor),
    primaryIconTheme: _iconThemeData(_primaryColor),
    textSelectionTheme: _textSelectionThemeData(
      _primaryColor,
      _primaryColor,
    ),
    textTheme: TextTheme(
      headlineMedium: _textTheme(44.0),
      headlineSmall: _textTheme(34.0),
    ),
    applyElevationOverlayColor: true,
    cardTheme: const CardTheme(
      surfaceTintColor: Color.fromARGB(255, 234, 234, 234),
    ),
    pageTransitionsTheme: _pageTransitionsTheme(),
    dividerTheme: _dividerThemeData(Colors.grey),
    timePickerTheme: const TimePickerThemeData(
      backgroundColor: Colors.white,
    ),
    dialogTheme: _dialogTheme(Colors.white),
  );

  static SystemUiOverlayStyle _systemUiOverlayStyle(
      Color statusBarColor, bool isDark) {
    // var dividerColor = Colors.white;
    var brightness = Brightness.light;
    var brightnessIOS = Brightness.dark;

    if (!isDark) {
      // dividerColor = Colors.black;
      brightness = Brightness.dark;
      brightnessIOS = Brightness.light;
    }
    return SystemUiOverlayStyle(
      statusBarColor: statusBarColor,
      statusBarBrightness: brightnessIOS, // For iOS (dark icons)
      statusBarIconBrightness: brightness, // For Android (dark icons)
      systemNavigationBarColor: statusBarColor,
      systemNavigationBarDividerColor: Colors.grey,
      systemNavigationBarIconBrightness: brightness,
      systemNavigationBarContrastEnforced: true,
      systemStatusBarContrastEnforced: true,
    );
  }

  static DialogTheme _dialogTheme(Color color) {
    return DialogTheme(
      surfaceTintColor: color,
      elevation: 1.5,
    );
  }

  static DividerThemeData _dividerThemeData(Color color) {
    return DividerThemeData(
      color: color,
      thickness: 0.2,
    );
  }

  static TextStyle _titleTextStyle(Color textColor) {
    return TextStyle(
      fontSize: 49.sp,
      color: textColor,
      fontWeight: FontWeight.w600,
      fontFamily: 'Cairo',
    );
  }

  static BottomNavigationBarThemeData _bottomNavigationBarThemeData({
    required Color backColor,
    IconThemeData? selectIcon,
    IconThemeData? unselectIcon,
  }) {
    return BottomNavigationBarThemeData(
      backgroundColor: backColor,
      selectedIconTheme: selectIcon,
      unselectedIconTheme: unselectIcon,
    );
  }

  static TextButtonThemeData _textButtonThemeData(Color primary) {
    return TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: primary,
        // shape: RoundedRectangleBorder(
        //   borderRadius: BorderRadius.circular(24.0),
        // ),
      ),
    );
  }

  static OutlinedButtonThemeData _outlinedButtonThemeData(Color primary) {
    return OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24.0.r),
          side: BorderSide(color: primary),
        ),
        side: BorderSide(color: primary),
      ),
    );
  }

  static ElevatedButtonThemeData _elevatedButtonThemeData(Color primary) {
    return ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24.0),
        ),
      ),
    );
  }

  static TextSelectionThemeData _textSelectionThemeData(
      Color cursor, Color selection) {
    return TextSelectionThemeData(
      cursorColor: cursor,
      selectionColor: selection,
    );
  }

  static ButtonThemeData _buttonThemeData(Color color) {
    return ButtonThemeData(buttonColor: color);
  }

  static IconThemeData _iconThemeData(Color color, {double opacity = 0.8}) {
    return IconThemeData(
      color: color,
      opacity: opacity,
    );
  }

  static TextStyle _textTheme(double fontSize) {
    return TextStyle(
      // color: _dARKTHEMETEXTCOLOR,
      fontSize: fontSize.sp,
      fontWeight: FontWeight.bold,
    );
  }

  static PageTransitionsTheme _pageTransitionsTheme() {
    return const PageTransitionsTheme(
      builders: {
        TargetPlatform.iOS: NoShadowCupertinoPageTransitionsBuilder(),
        TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
      },
    );
  }
}
