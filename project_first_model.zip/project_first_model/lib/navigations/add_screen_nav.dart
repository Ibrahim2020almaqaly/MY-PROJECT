import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';

class AddScreenNav {
  static Future<void> navigateToAddScreen(BuildContext context) async {
    final isthereUser =
        Get.find<FirebaseAuthController>().getCurrentUser != null;

    var error = Get.find<UserController>().checkIfNotEmpty();

    final connState = Get.find<ConnectionController>().isOnline;

    if (!connState) {
      error = 'يجب أن تكون متصلاً بالإنترنت لكي تستطيع إضافة رحلة';
      await ShowAnyMessages.showDialogMessage(
        context,
        error,
        'لا يمكنك إضافة رحلة',
        icon: Assets.lottieIcons.animationIcon02Nowifi,
      );
    } else if (!isthereUser) {
      await ShowCustomDialog.notLoggedInUserWithNavigation(context);
    } else if (error != null) {
      await ShowAnyMessages.showDialogMessage(
        context,
        error,
        'لا يمكنك إضافة رحلة',
        icon: Assets.lottieIcons.userProfileV2,
      );
    } else {
      Get.find<AppRouter>().pushNamed(AddTripRouter.name);
      // Get.toNamed(Routes.addtripName);
      // Navigator.of(context).pushNamed(AddTripScreen.routeName);
    }
  }
}
