import 'package:flutter/material.dart';

class CreationAwareListItem extends StatefulWidget {
  const CreationAwareListItem({
    Key? key,
    required this.itemCreated,
    required this.child,
  }) : super(key: key);
  final void Function() itemCreated;
  final Widget child;

  @override
  CreationAwareListItemState createState() => CreationAwareListItemState();
}

class CreationAwareListItemState extends State<CreationAwareListItem> {
  @override
  void initState() {
    super.initState();
    widget.itemCreated();
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}
