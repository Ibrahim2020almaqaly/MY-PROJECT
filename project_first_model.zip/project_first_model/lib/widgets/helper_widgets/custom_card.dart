import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class CustomCard extends StatelessWidget {
  const CustomCard({
    Key? key,
    required this.children,
    required this.title,
    this.paddingEdges = true,
    this.showElevation = true,
  }) : super(key: key);

  final List<Widget> children;
  final String title;
  final bool paddingEdges;
  final bool showElevation;

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    final showTitle = title != '';

    return Card(
      color: themeColor.scaffoldBackgroundColor,
      elevation: showElevation ? 2 : 0,
      margin: CustomEdgeInsets.only(bottom: paddingEdges ? 5.0 : 0.0),
      child: Padding(
        padding: CustomEdgeInsets.all(paddingEdges ? 32.0 : 0.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showTitle)
              Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 48.sp,
                  color: themeColor.colorScheme.onSurface,
                  // color: Theme.of(context).primaryColor,
                ),
              ),
            if (showTitle) const VerticalSizedBox(40),
            ...children,
          ],
        ),
      ),
    );
  }
}
