// // ignore_for_file: use_build_context_synchronously

// import 'package:auto_route/auto_route.dart';
// import 'package:flutter/material.dart';
// import 'package:project_first_model/router/router.gr.dart';
// import 'package:project_first_model/screens/alarms_screen.dart';
// import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
// import 'package:provider/provider.dart';

// import 'package:project_first_model/helpers/show_custom_dialog.dart';
// import 'package:project_first_model/navigations/add_screen_nav.dart';
// import 'package:project_first_model/providers/firebase_auth_provider.dart';
// import 'package:project_first_model/providers/user_provider.dart';
// import 'package:project_first_model/widgets/drawer_widgets/app_icon_theme.dart';
// import 'package:project_first_model/widgets/drawer_widgets/drawer_buttons.dart';
// import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';

// class AppDrawer extends StatelessWidget {
//   const AppDrawer({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     final themeColor = Theme.of(context);
//     return SafeArea(
//       child: Drawer(
//         child: SingleChildScrollView(
//           padding: EdgeInsets.zero,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               // Consumer<UserProvider>(
//               //   builder: (ctx, userProv, _) {
//               //     final user = userProv.getUserData;
//               //     final name = user.userName;
//               //     final phone = user.userPhoneNumber;
//               //     return UserAccountsDrawerHeader(
//               //       accountName:
//               //           // name.isEmpty
//               //           //     ? ShimmerWidget.rectangular(height: 10)
//               //           Text(name.isEmpty ? "إسم المستخدم" : name),
//               //       accountEmail: Row(
//               //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               //         mainAxisSize: MainAxisSize.max,
//               //         children: [
//               //           // phone.isEmpty
//               //           //     ? ShimmerWidget.rectangular(height: 10)
//               //           //     :
//               //           Text(
//               //             phone.isEmpty ? "رقم الهاتف" : phone,
//               //             textDirection: TextDirection.ltr,
//               //           ),
//               //           const SizedBox(
//               //             width: 10,
//               //           ),
//               //           const AppIconTheme(),
//               //         ],
//               //       ),
//               //       currentAccountPicture: CircleSqureImage(
//               //         height: 150,
//               //         width: 150,
//               //         radius: 50,
//               //         pic: user.userPic!,
//               //         assetImage: 'assets/images/driver_80px.png',
//               //       ),
//               //       currentAccountPictureSize: Size.square(dimension),
//               //     );
//               //   },
//               // ),

//               Container(
//                 margin: const EdgeInsets.only(top: 15, bottom: 15, right: 10),
//                 // padding: const EdgeInsets.only(top: 6, bottom: 6),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceAround,
//                   children: [
//                     Consumer<UserProvider>(
//                       builder: (_, userProv, child) {
//                         final user = userProv.getUserData;
//                         final auth = Provider.of<FirebaseAuthProvider>(context,
//                                 listen: false)
//                             .getCurrentUser
//                             ?.uid;

//                         if (auth != null &&
//                             (user.userId == '' || user.userId.isEmpty)) {
//                           userProv.requestMyData();
//                         }
//                         final driverName = user.userName.isEmpty
//                             ? "إسم المستخدم"
//                             : user.userName;
//                         final phoneNumber = user.userPhoneNumber.isEmpty
//                             ? "رقم الهاتف"
//                             : user.userPhoneNumber;
//                         return Column(
//                           // crossAxisAlignment: CrossAxisAlignment.center,
//                           mainAxisAlignment: MainAxisAlignment.end,
//                           children: [
//                             CircleSqureImage(
//                               height: 150,
//                               width: 150,
//                               radius: 75,
//                               pic: user.userPic,
//                               // assetImage: 'assets/images/driver_80px.png',
//                             ), //don't need expanded
//                             const VerticalSizedBox(10),
//                             Text(
//                               driverName,
//                               style: themeColor.textTheme.headline4,
//                               // TextStyle(
//                               //   color: themeColor.colorScheme.onSurface,
//                               //   fontSize: 18,
//                               //   fontWeight: FontWeight.bold,
//                               // ),
//                             ),
//                             const VerticalSizedBox(6),
//                             Text(
//                               phoneNumber,
//                               textDirection: TextDirection.ltr,
//                               style: themeColor.textTheme.headline5,
//                               // TextStyle(
//                               //   color: themeColor.colorScheme.onSurface,
//                               //   fontSize: 13,
//                               //   fontWeight: FontWeight.bold,
//                               // ),
//                             ),
//                           ],
//                         );
//                       },
//                     ),
//                     const HorizantalSizedBox(10),
//                     const AppIconTheme(),
//                   ],
//                 ),
//               ),

//               DrawerButtons(
//                 iconData: Icons.settings_outlined,
//                 title: 'إعدادات الملف الشخصي',
//                 onTab: () {
//                   // Navigator.of(context).pushNamed(ProfileScreen.routeName);
//                 },
//               ),
//               DrawerButtons(
//                 iconData: Icons.design_services_outlined,
//                 title: 'الخدمات',
//                 onTab: () {
//                   //
//                 },
//               ),
//               DrawerButtons(
//                 iconData: Icons.design_services_outlined,
//                 title: 'إضافة رحلة',
//                 onTab: () {
//                   AddScreenNav.navigateToAddScreen(context);
//                 },
//               ),
//               DrawerButtons(
//                 iconData: Icons.access_alarms_outlined,
//                 title: 'قائمة تنبيهات الرحلات',
//                 onTab: () {
//                   Navigator.of(context).pushNamed(AlarmsScreen.routeName);
//                 },
//               ),
//               DrawerButtons(
//                 iconData: Icons.settings_outlined,
//                 title: 'الإعدادات',
//                 onTab: () {
//                   //
//                 },
//               ),
//               DrawerButtons(
//                 iconData: Icons.logout_outlined,
//                 title: 'تسجيل الخروج',
//                 onTab: () async {
//                   final logout =
//                       await ShowCustomDialog.showConfirmationDialogMessage(
//                     context,
//                     'هل تريد فعلاً تسجيل الخروج ؟',
//                     'تأكيد تسجيل الخروج',
//                   );
//                   if (logout) {
//                     await Provider.of<FirebaseAuthProvider>(context,
//                             listen: false)
//                         .logOut();
//                     Get.find<AppRouter>().pushAndPopUntil(const WelcomeScreenRouter(),
//                         predicate: (route) => false);
//                   }
//                 },
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
