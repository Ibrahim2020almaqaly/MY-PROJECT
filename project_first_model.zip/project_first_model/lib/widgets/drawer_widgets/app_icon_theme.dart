// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import 'package:project_first_model/providers/theme_provider.dart';

// class AppIconTheme extends StatelessWidget {
//   const AppIconTheme({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     final themeProvider = Provider.of<ThemeProvider>(context);
//     return IconButton(
//       tooltip: themeProvider.isDarkMode
//           ? 'تغيير إلى الوضع العادي'
//           : 'تغيير إلى الوضع المظلم',
//       onPressed: () {
//         // final provider = Provider.of<ThemeProvider>(context, listen: false);
//         // provider.toggleTheme(!themeProvider.isDarkMode);
//       },
//       icon: Icon(
//         !themeProvider.isDarkMode
//             ? Icons.dark_mode_outlined
//             : Icons.light_mode_outlined,
//         semanticLabel:
//             themeProvider.isDarkMode ? 'الوضع العادي' : 'الوضع المظلم',
//       ),
//     );
//   }
// }
