// import 'package:flutter/material.dart';
// import 'package:project_first_model/helpers/show_messages.dart';
// import 'package:project_first_model/providers/connection_provider.dart';
// import 'package:provider/provider.dart';

// class DrawerButtons extends StatelessWidget {
//   const DrawerButtons({
//     Key? key,
//     required this.iconData,
//     required this.title,
//     required this.onTab,
//   }) : super(key: key);
//   final IconData iconData;
//   final String title;
//   final void Function() onTab;

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);
//     return Consumer<ConnectionProvider>(
//       builder: (ctx, connProv, _) {
//         return ListTile(
//           leading: Icon(
//             iconData,
//             color: theme.iconTheme.color,
//           ),
//           title: Text(
//             title,
//             // style: TextStyle(
//             //   color: themeColor.colorScheme.onSurface,
//             // ),
//           ),
//           onTap: connProv.isOnline
//               ? onTab
//               : () => ShowAnyMessages.showToastMSG(noCONNECTIONMSG),
//         );
//       },
//     );
//   }
// }
