import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class SendButtonWidget extends StatefulWidget {
  final void Function() save;

  const SendButtonWidget({
    Key? key,
    required this.save,
  }) : super(key: key);

  @override
  State<SendButtonWidget> createState() => _SendButtonWidgetState();
}

class _SendButtonWidgetState extends State<SendButtonWidget> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<FirebaseAuthController>(
      builder: (prov) {
        return SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () async {
              if (prov.getbuttonStatus) {
                return;
              }

              final online = Get.find<ConnectionController>().isOnline;
              if (!online) {
                await ShowAnyMessages.noConnMsg(context);
                return;
              }
              widget.save();
            },
            style: ElevatedButton.styleFrom(
              shape: const StadiumBorder(),
            ),
            child: Padding(
              padding: CustomEdgeInsets.all(28.0),
              child: prov.getLoadingStatus || prov.getbuttonStatus
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const CircularProgressIndicator(
                          color: Colors.white,
                        ),
                        const HorizantalSizedBox(40),
                        Text(
                          "الرجاء الإنتظار ...",
                          style: TextStyle(fontSize: 40.sp),
                        ),
                      ],
                    )
                  : Text(
                      'إرسال',
                      style: TextStyle(fontSize: 40.sp),
                    ),
            ),
          ),
        );
      },
    );
  }
}
