import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class AppError extends StatelessWidget {
  const AppError({
    Key? key,
    required this.details,
  }) : super(key: key);
  final FlutterErrorDetails details;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: CustomEdgeInsets.symmetric(0, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'حدث خطأ غير متوقع!',
                  style: TextStyle(
                    fontSize: 50.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const VerticalSizedBox(20),
                Text(
                  details.exceptionAsString(),
                  style: TextStyle(
                    fontSize: 40.sp,
                  ),
                ),
                const VerticalSizedBox(20),
                CustomElevatedButton(
                  title: 'الخروج',
                  onPressed: () => SystemNavigator.pop(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
