import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:project_first_model/widgets/custom_loadings/shimmer_widget.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class TripsLoading extends StatelessWidget {
  const TripsLoading({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(
        // top: 12.0,
        left: 45.0,
        right: 12.0,
        bottom: 6.0,
      ),
      elevation: 4,
      child: SizedBox(
        height: 150.h,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              top: (150 / 2) - 50,
              left: -45,
              //driver picture shimmer
              child: ShimmerWidget.circular(
                height: 100,
                width: 100,
              ),
            ),
            Positioned(
              top: -20,
              left: 0,
              right: 0,
              bottom: 0,
              child: Align(
                alignment: Alignment.center,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    //driver name shimmer
                    ShimmerWidget.rectangular(
                      height: 20,
                      width: 150,
                    ),
                    const VerticalSizedBox(10),
                    //date shimmer
                    ShimmerWidget.rectangular(
                      height: 20,
                      width: 150,
                    ),
                    const VerticalSizedBox(10),
                    Container(
                      margin: CustomEdgeInsets.horizontal(4),
                      alignment: Alignment.center,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          //from Shimmer
                          ShimmerWidget.rectangular(
                            height: 20,
                            width: 100,
                          ),
                          const HorizantalSizedBox(10),
                          //to shimmer
                          ShimmerWidget.rectangular(
                            height: 20,
                            width: 100,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            //call driver shimmer
            Positioned(
              top: 44,
              right: 5,
              child: ShimmerWidget.circular(
                height: 60,
                width: 60,
              ),
            ),
            //Rating Shimmer
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: ShimmerWidget.rectangular(
                  height: 20,
                  width: 170,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
