import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:project_first_model/widgets/custom_loadings/shimmer_widget.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class OverlandTransportsLoading extends StatelessWidget {
  const OverlandTransportsLoading({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 430.h,
      width: 450.w,
      child: Card(
        // elevation: 6,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        margin: CustomEdgeInsets.all(10),
        child: InkWell(
          onTap: () {},
          child: Padding(
            padding:
                EdgeInsets.only(right: 10.0.w, top: 10.0.h, bottom: 10.0.h),
            child: Stack(
              fit: StackFit.expand,
              children: [
                //picture
                Align(
                  alignment: Alignment.topCenter,
                  child: SizedBox(
                    // width: double.infinity,
                    height: 350.0.h,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      // crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        ShimmerWidget.rectangular(
                          height: 230.0,
                          width: double.infinity,
                        ),
                        const VerticalSizedBox(30),
                        ShimmerWidget.rectangular(
                          height: 55,
                          width: 400,
                        ),
                        const VerticalSizedBox(20),
                      ],
                    ),
                  ),
                ),
                //rating
                Positioned(
                  bottom: 7,
                  right: 5,
                  child: ShimmerWidget.rectangular(
                    height: 30,
                    width: 170,
                  ),
                ),
                //origin
                Positioned(
                  bottom: 6,
                  left: 10,
                  child: ShimmerWidget.rectangular(
                    height: 40,
                    width: 180,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
