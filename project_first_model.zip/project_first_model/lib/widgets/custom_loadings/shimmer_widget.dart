import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';

import 'package:project_first_model/controllers/theme_controller.dart';

class ShimmerWidget extends StatelessWidget {
  final double height;
  final double width;
  final ShapeBorder shapeBorder;
  ShimmerWidget.rectangular({
    Key? key,
    required this.height,
    this.width = double.infinity,
  })  : shapeBorder = const RoundedRectangleBorder(),
        super(key: key);

  ShimmerWidget.circular({
    Key? key,
    required this.height,
    required this.width,
    this.shapeBorder = const CircleBorder(),
  }) : super(key: key);

  final baseColorLight = Colors.grey[300]!;
  final highlightColorLight = Colors.grey[200]!;

  final baseColorDark = Colors.grey[700]!;
  final highlightColorDark = Colors.grey[800]!;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(
      builder: (theme) {
        return Shimmer.fromColors(
          baseColor: theme.isDarkMode ? baseColorDark : baseColorLight,
          highlightColor:
              theme.isDarkMode ? highlightColorDark : highlightColorLight,
          child: Container(
            width: width.w,
            height: height.h,
            decoration: ShapeDecoration(
              color: baseColorLight,
              shape: shapeBorder,
            ),
          ),
        );
      },
    );
  }
}
