import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:project_first_model/widgets/custom_loadings/shimmer_widget.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class TripsLoadingV2 extends StatelessWidget {
  const TripsLoadingV2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      margin: const EdgeInsets.only(
        // top: 12.0,
        left: 12.0, //45.0,
        right: 12.0,
        bottom: 6.0,
      ),
      // elevation: 4,
      child: SizedBox(
        height: 270.h,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          mainAxisSize: MainAxisSize.max,
          children: [
            //trip data
            const HorizantalSizedBox(30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              mainAxisSize: MainAxisSize.max,
              children: [
                //driver pic
                ShimmerWidget.circular(
                  height: 210,
                  width: 210,
                ),

                const HorizantalSizedBox(28),
                //trip info
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    const VerticalSizedBox(24),
                    //driverName
                    ShimmerWidget.rectangular(
                      height: 40,
                      width: 450,
                    ),

                    //date and time
                    ShimmerWidget.rectangular(
                      height: 36,
                      width: 300,
                    ),
                    //dest
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: ShimmerWidget.rectangular(
                                  height: 38.0,
                                  width: 40.0,
                                ),
                              ),
                              const TextSpan(text: ' '),
                              WidgetSpan(
                                child: ShimmerWidget.circular(
                                  height: 38.0,
                                  width: 38.0,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const HorizantalSizedBox(6),
                        ShimmerWidget.rectangular(
                          height: 30,
                          width: 40,
                        ),
                        const HorizantalSizedBox(6),
                        RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: ShimmerWidget.rectangular(
                                  height: 38.0,
                                  width: 40.0,
                                ),
                              ),
                              const TextSpan(text: ' '),
                              WidgetSpan(
                                child: ShimmerWidget.circular(
                                  height: 38.0,
                                  width: 38.0,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    //rating
                    ShimmerWidget.rectangular(
                      height: 35,
                      width: 170,
                    ),
                  ],
                ),
              ],
            ),
            // const Expanded(
            //   child: SizedBox(width: double.infinity),
            // ),
            const HorizantalSizedBox(20.0),
            ShimmerWidget.circular(
              height: 160.0,
              width: 160.0,
            ),
            const HorizantalSizedBox(30),
          ],
        ),
      ),
    );
  }
}
