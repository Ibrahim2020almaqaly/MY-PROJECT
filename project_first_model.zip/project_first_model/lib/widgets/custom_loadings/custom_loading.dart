import 'package:flutter/material.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class CustomLoading extends StatelessWidget {
  const CustomLoading({
    Key? key,
    this.showSemanticLabal = true,
  }) : super(key: key);
  final bool showSemanticLabal;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            semanticsLabel: showSemanticLabal ? "جارِ التحميل ..." : "",
          ),
          const VerticalSizedBox(12),
          Text(
            showSemanticLabal ? "جارِ التحميل ..." : "",
          ),
        ],
      ),
    );
  }
}
