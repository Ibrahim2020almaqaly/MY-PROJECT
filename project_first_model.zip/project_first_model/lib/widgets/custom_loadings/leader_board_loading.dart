import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:project_first_model/widgets/custom_loadings/shimmer_widget.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class LeaderBoardLoading extends StatelessWidget {
  const LeaderBoardLoading({
    Key? key,
    required this.index,
  }) : super(key: key);
  final int index;

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      margin: const EdgeInsets.only(
        // top: 12.0,
        left: 12.0, //45.0,
        right: 12.0,
        bottom: 6.0,
      ),
      // elevation: 4,
      child: SizedBox(
        height: 295.h,
        child: InkWell(
          onTap: () {},
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              const HorizantalSizedBox(25),
              SizedBox(
                width: 85.w,
                height: 130.h,
                child: FittedBox(
                  child: Text(
                    '#$index',
                    style: TextStyle(
                      fontSize: 46.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Row(
                // mainAxisAlignment: MainAxisAlignment.spaceAround,
                mainAxisSize: MainAxisSize.max,
                children: [
                  const HorizantalSizedBox(25),
                  // const HorizantalSizedBox(30),
                  //driver pic
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (index < 4)
                        Icon(
                          FontAwesomeIcons.crown,
                          color: index == 1
                              ? Colors.amber
                              : index == 2
                                  ? const Color.fromARGB(255, 190, 190, 190)
                                  : const Color(0xffcd7f32),
                        ),
                      ShimmerWidget.circular(height: 210, width: 210),
                      if (index < 4) const VerticalSizedBox(10),
                    ],
                  ),
                  const HorizantalSizedBox(20),
                  //trip info
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const VerticalSizedBox(24),
                      //driverName
                      ShimmerWidget.rectangular(
                        height: 48,
                        width: 500,
                      ),
                      //Loaction
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          ShimmerWidget.circular(height: 38, width: 38),
                          const HorizantalSizedBox(7),
                          ShimmerWidget.rectangular(
                            height: 40,
                            width: 200,
                          ),
                        ],
                      ),
                      //rating
                      ShimmerWidget.rectangular(
                        height: 45,
                        width: 270,
                      ),
                      const VerticalSizedBox(7),
                    ],
                  ),
                ],
              ),
              const Expanded(
                child: HorizantalSizedBox(double.infinity),
              ),
              const HorizantalSizedBox(10),
              ShimmerWidget.rectangular(
                height: 44,
                width: 100,
              ),
              const HorizantalSizedBox(25),
            ],
          ),
        ),
      ),
    );
  }
}
