import 'package:flutter/material.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';

class CustomListLoading extends StatelessWidget {
  const CustomListLoading({
    Key? key,
    required this.child,
    required this.count,
    this.scrollDirection = Axis.vertical,
  }) : super(key: key);
  final Widget child;
  final int count;
  final Axis scrollDirection;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      primary: false,
      scrollDirection: scrollDirection,
      physics: const NeverScrollableScrollPhysics(),
      padding: CustomEdgeInsets.only(top: 5.0, bottom: 5.0),
      clipBehavior: Clip.antiAlias,
      itemCount: count,
      itemBuilder: (context, index) {
        return child;
      },
    );
  }
}
