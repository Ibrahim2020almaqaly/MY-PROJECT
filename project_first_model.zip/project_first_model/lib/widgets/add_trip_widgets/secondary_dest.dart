import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/trip_controllers/secondary_city_controller.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class SecondaryDestWidget extends StatelessWidget {
  const SecondaryDestWidget({Key? key}) : super(key: key);

  // final List<String> _otherDest = [];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: CustomEdgeInsets.all(30),
      // height: 100,
      child: GetBuilder<SecondaryCityController>(
        builder: (citiesProv) {
          if (citiesProv.cities.isEmpty) {
            // print(citiesProv.cities.length);
            return const Center(
              child: Text('لا يوجد وجهات فرعية بعد!'),
            );
          }
          //print(citiesProv.cities.length);
          return SizedBox(
            height: 260.h,
            child: ListView(
              children: [
                Wrap(
                  // crossAxisAlignment: WrapCrossAlignment.start,
                  direction: Axis.horizontal,
                  spacing: 5,
                  runSpacing: 5,
                  alignment: WrapAlignment.spaceAround,
                  runAlignment: WrapAlignment.spaceAround,
                  children: [
                    ...citiesProv.cities
                        .map(
                          (cityName) => DestItems(
                            dest: cityName,
                            // removeHandeler: _remove,
                          ),
                        )
                        .cast<DestItems>(),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class DestItems extends StatelessWidget {
  const DestItems({
    Key? key,
    required this.dest,
    // required this.removeHandeler,
  }) : super(key: key);

  final String dest;
  // final void Function(String dest) removeHandeler;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      // crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(dest),
        const HorizantalSizedBox(25),
        IconButton(
          onPressed: () {
            Get.find<SecondaryCityController>().removeCity(dest);
          },
          icon: const Icon(Icons.remove_circle_outline_outlined),
          tooltip: "حذف الوجهة",
        ),
      ],
    );
  }
}
