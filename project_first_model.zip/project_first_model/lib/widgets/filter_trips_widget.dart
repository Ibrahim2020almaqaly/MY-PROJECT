import 'package:flutter/material.dart';

import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';

import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/trips_filters_widget.dart';
import 'package:project_first_model/widgets/utiles/custom_dialog_form_show.dart';
import 'package:project_first_model/widgets/utiles/custom_modal_bottom_sheet.dart';

class FilterTrips {
  static Future<void> showFiltesDailog(BuildContext context) async {
    return await CustomDialogFormShow.showCustomDialog(
      context,
      const TripsFiltersWidget(
        showTitle: false,
        popAfterSave: true,
      ),
      "بحث على حسب: ",
    );
  }

  static Future<void> showFiltesModal(BuildContext context) async {
    return CustomModalBottomSheet.buildCustomModalSheet(
      context,
      DraggableScrollableSheet(
        initialChildSize: 0.95, // 0.77,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        builder: (modalCtx, scrollController) {
          return CustomModalBottomSheet.buildStack(
            Container(
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(25),
                ),
              ),
              padding: CustomEdgeInsets.all(32.0),
              child: ListView(
                primary: false,
                shrinkWrap: false,
                controller: scrollController,
                children: const [
                  TripsFiltersWidget(
                    showElevation: false,
                    popAfterSave: true,
                    paddingEdges: false,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
