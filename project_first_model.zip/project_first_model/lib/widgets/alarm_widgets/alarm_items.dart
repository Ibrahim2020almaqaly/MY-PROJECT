import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'package:project_first_model/controllers/alarm_controllers/alarm_controller.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/helpers/gradient_colors.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/models/alarm_model.dart';
import 'package:project_first_model/widgets/alarm_widgets/add_alarm.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_ink_well.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_switch.dart';

class AlarmItem extends StatefulWidget {
  const AlarmItem({
    Key? key,
    required this.alarm,
  }) : super(key: key);
  final AlarmModel alarm;

  @override
  State<AlarmItem> createState() => _AlarmItemState();
}

class _AlarmItemState extends State<AlarmItem> {
  @override
  void initState() {
    super.initState();
    initializeDateFormatting('ar_SA', null);
  }

  void _updateTrip(int enabled) async {
    await Get.find<AlarmController>()
        .updateAlarm(widget.alarm.copyWith(isEnabled: enabled));
  }

  @override
  Widget build(BuildContext context) {
    final prov = Get.find<AlarmController>();
    var alarmTime = DateTimeHelpers.getTimeFromDate(widget.alarm.tripTime);
    var alarmDayString =
        DateTimeHelpers.getDateInLetterFormat(widget.alarm.tripTime);
    var gradientColor =
        GradientTemplates.alarmGradientTemplate[widget.alarm.colorIndex].colors;
    var enabled = widget.alarm.isEnabled == 1;

    return CustomInkWell(
      onTap: () {
        showAddReminder(
          context,
          'تعديل التنبيه',
          alarm: widget.alarm,
        );
      },
      allowOnlineOnly: false,
      child: Container(
        margin: const EdgeInsets.only(bottom: 22),
        padding: CustomEdgeInsets.symmetric(16, 32),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradientColor,
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: gradientColor.last.withOpacity(0.4),
              blurRadius: 8,
              spreadRadius: 2,
              offset: const Offset(4, 4),
            ),
          ],
          borderRadius: const BorderRadius.all(
            Radius.circular(24),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.label,
                      color: Colors.white,
                      size: 80.sp,
                    ),
                    const HorizantalSizedBox(16),
                    Text(
                      widget.alarm.driverName,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 50.sp,
                      ),
                    ),
                  ],
                ),
                Expanded(
                  child: CustomSwitch(
                    enabled: enabled,
                    updateSwitch: _updateTrip,
                  ),
                ),
              ],
            ),
            Text(
              alarmDayString, //'Mon-Fri',
              style: TextStyle(
                color: Colors.white,
                fontSize: 46.sp,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  alarmTime,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 44.sp,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                CustomIconButton(
                  iconData: Icons.delete,
                  iconSize: 80,
                  allowOnlineOnly: false,
                  tooltip: 'حذف التنبيه',
                  iconColor: Colors.white,
                  makeTheme: false,
                  onPressed: () async {
                    final delete = await Utiles.deleteItem(context);
                    if (delete) {
                      await prov.deleteAlarm(widget.alarm.alarmId!);
                    }
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
