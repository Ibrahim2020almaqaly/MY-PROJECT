import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/alarm_controllers/alarm_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_date_time_picker.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/models/alarm_model.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_dialog_form_show.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

void showAddReminder(BuildContext context, String title,
    {AlarmModel? alarm}) async {
  CustomDialogFormShow.showCustomDialog(
    context,
    AddAlarm(alarm: alarm),
    title,
  );
}

class AddAlarm extends StatefulWidget {
  const AddAlarm({
    Key? key,
    this.alarm,
  }) : super(key: key);
  final AlarmModel? alarm;
  @override
  AddAlarmState createState() => AddAlarmState();
}

class AddAlarmState extends State<AddAlarm> {
  final _driverNameController = TextEditingController();
  final _phoneNbrController = TextEditingController();
  final _destinationController = TextEditingController();
  final _dateController = TextEditingController();
  final _timeController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      _getData();
    });
  }

  void _getData() {
    if (widget.alarm != null) {
      final alarm = widget.alarm!;
      _driverNameController.text = alarm.driverName;
      final phoneNumber = alarm.driverPhone;
      _phoneNbrController.text =
          phoneNumber.contains('+') ? phoneNumber.substring(1) : phoneNumber;
      _destinationController.text = alarm.destination;
      _dateController.text =
          DateTimeHelpers.convertDateToString(alarm.tripTime);
      _timeController.text = DateTimeHelpers.getTimeFromDate(alarm.tripTime);
    }
  }

  void _save() async {
    final isValid = _formKey.currentState!.validate();
    if (!isValid) return;
    try {
      CustomOverlayLoading.showOverlayLoading();
      final uid = Get.find<FirebaseAuthController>().getCurrentUser?.uid;
      //     ??
      // '';
      if (uid == null) {
        throw CustomException("not-logged-in");
      }

      final alarmProv = Get.find<AlarmController>();
      final tripDate = DateTimeHelpers.convertToDateTime(
        DateTimeHelpers.convertStringToDate(_dateController.text.trim()),
        DateTimeHelpers.convertToTimeOfDayV2(_timeController.text.trim()),
      );

      if (widget.alarm == null) {
        final alarm = AlarmModel(
          tripId: '',
          tripTime: tripDate,
          isEnabled: 1,
          userId: uid,
          driverId: '',
          driverName: _driverNameController.text.trim(),
          driverPhone: _phoneNbrController.text.trim(),
          destination: _destinationController.text.trim(),
          colorIndex: 0,
        );
        await alarmProv.addAlarm(alarm);
      } else {
        final alarm = widget.alarm!.copyWith(
          tripTime: tripDate,
          isEnabled: 1,
          userId: uid,
          driverName: _driverNameController.text.trim(),
          driverPhone: _phoneNbrController.text.trim(),
          destination: _destinationController.text.trim(),
          colorIndex: 0,
        );
        await alarmProv.disableAlarm(alarm.alarmId!);
      }

      // Navigator.of(context).pop(filters);
      // if (!mounted) return;
      CustomOverlayLoading.hideOverlayLoading();
      // Navigator.of(context).pop();
      Get.find<AppRouter>().pop();
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showDialogMessage(
        context,
        e.errorMessage,
        appNAME,
        icon: Assets.lottieIcons.errorOccurred,
      );
    } on Exception catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showDialogMessage(
        context,
        e.toString(),
        appNAME,
        icon: Assets.lottieIcons.errorOccurred,
      );
    }
  }

  @override
  void dispose() {
    super.dispose();
    _driverNameController.dispose();
    _dateController.dispose();
    _timeController.dispose();
    _phoneNbrController.dispose();
    _destinationController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        reverse: true,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const VerticalSizedBox(20),
            CustomTextFormField(
              label: 'إسم السائق',
              controller: _driverNameController,
              validator: Validators.checkIfNotEmpty,
              onSaved: null,
              textInputType: TextInputType.text,
              textInputAction: TextInputAction.next,
              maxLength: 30,
            ),
            const VerticalSizedBox(20),

            CustomTextFormField(
              label: 'رقم السائق',
              controller: _phoneNbrController,
              validator: Validators.validatePhoneNumberField,
              onSaved: null,
              textInputType: TextInputType.phone,
              textInputAction: TextInputAction.next,
              maxLength: 12,
            ),
            const VerticalSizedBox(20),

            CustomTextFormField(
              label: 'الوجهة',
              controller: _destinationController,
              validator: Validators.checkIfNotEmpty,
              onSaved: null,
              textInputType: TextInputType.text,
              textInputAction: TextInputAction.next,
              maxLength: 30,
            ),
            const VerticalSizedBox(20),
            //Date
            CustomTextFormField(
              label: 'التاريخ',
              controller: _dateController,
              readOnly: true,
              textInputAction: TextInputAction.next,
              textInputType: TextInputType.datetime,
              validator: Validators.validateDateField,
              onSaved: null,
              iconToolTip: 'حدد التاريخ',
              icon: Icons.date_range_outlined,
              showIconButton: true,
              onIconPressed: () async {
                await showDateDialog(context);
              },
              onTap: () async {
                await showDateDialog(context);
              },
            ),
            const VerticalSizedBox(20),
            //Time
            CustomTextFormField(
              label: 'الوقت',
              controller: _timeController,
              readOnly: true,
              textInputAction: TextInputAction.done,
              textInputType: TextInputType.datetime,
              validator: (value) {
                return Validators.validateTimeField(
                    value, _dateController.text.trim());
              },
              onSaved: null,
              showIconButton: true,
              icon: Icons.timer_outlined,
              iconToolTip: 'حدد الوقت',
              onIconPressed: () async {
                await showTimeDialog(context);
              },
              onTap: () async {
                await showTimeDialog(context);
              },
            ),
            const VerticalSizedBox(20),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomElevatedButton(
                  title: 'حفظ',
                  onPressed: _save,
                  allowOnlineOnly: false,
                  // allowRegisterOnly: false,
                ),
                CustomTextButton(
                  title: 'إلغاء',
                  onPressed: () {
                    // Navigator.of(context).pop();
                    Get.find<AppRouter>().pop();
                  },
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                ),
              ],
            ),
            const BottomPadding(),
          ],
        ),
      ),
    );
  }

  Future<void> showTimeDialog(BuildContext context) async {
    _timeController.text = await ShowDateTimePickers.showCustomTimePicker(
      // context,
      _timeController.text,
    );
  }

  Future<void> showDateDialog(BuildContext context) async {
    _dateController.text = await ShowDateTimePickers.showCustomDatePicker(
      // context,
      _dateController.text,
    );
  }
}
