import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/main_screen_widgets/higher_rating_drivers/show_higher_rate_driver_list.dart';
import 'package:project_first_model/widgets/main_screen_widgets/section_header.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/show_all_trips_.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/trip_from_your_place.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class MainScreenBody extends StatelessWidget {
  const MainScreenBody({
    Key? key,
    required this.controller,
  }) : super(key: key);
  final ScrollController controller;

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      controller: controller,
      children: [
        const VerticalSizedBox(15),
        const _HigherRateList(),
        const Divider(),
        // const _AvailableOverlandTransportList(),
        // const Divider(),
        const _TripsFromYourPlace(),
        const Divider(),
        _RecentTrips(scrollController: controller),
      ],
    );

    // RefreshIndicator(
    //   onRefresh: () async {
    //     _refreshTrips(context);
    //   },
    //   child: Consumer<TripProvider>(
    //     builder: (ctx, tripProv, _) {
    //       if (tripProv.loading) {
    //         return const CustomLoading();
    //       }
    //       if (!tripProv.initialized) {
    //         final online =
    //             Provider.of<ConnectionProvider>(context, listen: false)
    //                 .isOnline;
    //         if (online) {
    //           Future.delayed(Duration.zero, () {
    //             tripProv.listenToTrips();
    //           });
    //         }
    //       }
    //       final tripsList = tripProv.trips;
    //       if (tripsList.isEmpty) {
    //         return const Center(
    //           child: Text('لا يوجد رحلات!'),
    //         );
    //       }
    //       return ListView.separated(
    //         separatorBuilder: (ctx, index) => const Divider(),
    //         itemCount: tripsList.length,
    //         padding: const EdgeInsets.only(bottom: 5.0, top: 5.0),
    //         itemBuilder: (ctx, index) {
    //           return CreationAwareListItem(
    //             itemCreated: () {
    //               if (index % 10 == 0) {
    //                 tripProv.requestMoreData();
    //               }
    //             },
    //             child: OfferItems(trip: tripsList[index]),
    //           );
    //         },
    //       );
    //     },
    //   ),
    // );
  }
}

class _HigherRateList extends StatelessWidget {
  const _HigherRateList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 580.h,
      child: Column(
        children: [
          SectionHeader(
            title: 'الأعلى تقييماً ',
            onTap: () {
              Get.find<RatingController>().clearFilter();

              // Get.toNamed(Routes.higherRateListScreen);
              Get.find<AppRouter>().push(
                const HigherRateListRoute(),
              );
            },
          ),
          const VerticalSizedBox(10),
          SizedBox(
            height: 450.h,
            child: const ShowHigherRateDriverList(),
          ),
        ],
      ),
    );
  }
}

class _TripsFromYourPlace extends StatelessWidget {
  const _TripsFromYourPlace({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FirebaseAuthController>(
      builder: (authProv) {
        if (authProv.isThereAUserLoggedin) {
          return SizedBox(
            height: 470.h,
            child: Column(
              children: [
                SectionHeader(
                  showArrowIcon: false,
                  title: 'رحلات من منطقتك',
                  onTap: () {},
                ),
                const VerticalSizedBox(10),
                SizedBox(
                  height: 350.h,
                  child: const TripsFromYourPlace(),
                ),
              ],
            ),
          );
        } else {
          return const VerticalSizedBox(0.0);
        }
      },
    );
  }
}

// class _AvailableOverlandTransportList extends StatelessWidget {
//   const _AvailableOverlandTransportList({Key? key}) : super(key: key);
//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       height: 585.h,
//       child: Column(
//         children: [
//           SectionHeader(
//             title: 'وكالات النقل البرّي ',
//             onTap: () => Get.find<AppRouter>().push(
//               const OverlandTransportsListScreenRoute(),
//             ),
//           ),
//           const VerticalSizedBox(10),
//           SizedBox(
//             height: 450.h,
//             child: ListView.separated(
//               itemCount: 12,
//               scrollDirection: Axis.horizontal,
//               separatorBuilder: (BuildContext context, int index) {
//                 return const Divider(); //SizedBox(width: 5);
//               },
//               itemBuilder: (BuildContext context, int index) {
//                 // if (index == 0 || index == 11) {
//                 //   return const SizedBox(
//                 //     width: 1,
//                 //   );
//                 // }
//                 return const OverlandTransportItem();
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

class _RecentTrips extends StatelessWidget {
  const _RecentTrips({
    Key? key,
    required this.scrollController,
  }) : super(key: key);

  final ScrollController scrollController;

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      primary: false,
      physics: const ClampingScrollPhysics(),
      children: [
        SectionHeader(
          title: 'آخر الرحلات',
          onTap: () =>
              // Get.toNamed(Routes.tripsListScreen),
              Get.find<AppRouter>().push(
            const TripsListRoute(),
          ),
        ),
        const VerticalSizedBox(10),
        // ListView.separated(
        //   separatorBuilder: (context, index) => const Divider(),
        //   shrinkWrap: true,
        //   primary: false,
        //   itemCount: 10,
        //   itemBuilder: (BuildContext context, int index) {
        //     return OfferItemsV2(
        //       trip: TripModel.testTrip,
        //       getTripData: (tripID) async {
        //         return null;
        //       },
        //     );
        //   },
        // ),

        ShowAllTrips(controller: scrollController),
      ],
    );
  }
}
