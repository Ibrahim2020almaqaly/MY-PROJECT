import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:project_first_model/gen/assets.gen.dart';

import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/offer_items_v2.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class OverlandTransportItem extends StatelessWidget {
  const OverlandTransportItem({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 430.h,
      width: 450.w,
      child: Card(
        // elevation: 6,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        margin: CustomEdgeInsets.all(10),
        child: InkWell(
          onTap: () {},
          child: Padding(
            padding:
                EdgeInsets.only(right: 10.0.w, top: 10.0.h, bottom: 10.0.h),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // const Positioned(
                //   top: 5,
                //   left: 5,
                //   child: Icon(Icons.person_add),
                // ),

                //picture
                Align(
                  alignment: Alignment.topCenter,
                  child: SizedBox(
                    // width: double.infinity,
                    height: 350.0.h,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        CircleSqureImage(
                          pic: Assets.images.companyLogo.path,
                          width: double.infinity,
                          height: 230.0,
                          isCircle: false,
                          decoration: const ShapeDecoration(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(12.0),
                                  topRight: Radius.circular(12.0)),
                            ),
                          ),
                        ),
                        const VerticalSizedBox(30),
                        SizedBox(
                          height: 66.h,
                          width: 300.w,
                          child: FittedBox(
                            fit: BoxFit.contain,
                            child: Text(
                              'وكالة البراق للنقل البري والسفريات',
                              style: TextStyle(
                                fontSize: 24.0.sp,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.fade,
                              maxLines: 2,
                              softWrap: false,
                            ),
                          ),
                        ),
                        const VerticalSizedBox(20),
                      ],
                    ),
                  ),
                ),
                //name
                // Positioned(
                //   top: 160.h,
                //   right: 10.w,
                //   left: 10.w,
                //   child: SizedBox(
                //     height: 66.h,
                //     width: 300.w,
                //     child: FittedBox(
                //       fit: BoxFit.contain,
                //       child: Text(
                //         'وكالة البراق للنقل البري والسفريات',
                //         style: TextStyle(
                //           fontSize: 24.0.sp,
                //           fontWeight: FontWeight.bold,
                //         ),
                //         overflow: TextOverflow.fade,
                //         maxLines: 2,
                //         softWrap: false,
                //       ),
                //     ),
                //   ),
                // ),

                //rating
                Positioned(
                  bottom: 10,
                  right: 5,
                  child: SizedBox(
                    width: 170.w,
                    child: FittedBox(
                      child: ShowRating(
                        ratingRatio: 4.5,
                        itemSize: 15.sp,
                      ),
                    ),
                  ),
                ),
                //origin
                Positioned(
                  bottom: 6,
                  left: 10,
                  child: SizedBox(
                    height: 66.h,
                    width: 180.w,
                    child: FittedBox(
                      fit: BoxFit.contain,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Icon(
                            Icons.location_on,
                            size: 40.sp,
                          ),
                          const HorizantalSizedBox(8),
                          const Text(
                            'حضرموت',
                            // style: TextStyle(
                            //   fontSize: 12,
                            // ),
                          ),
                          const HorizantalSizedBox(8),
                        ],
                      ),
                    ),
                  ),
                ),

                //date
                // Positioned(
                //   top: 140,
                //   right: 5,
                //   child: SizedBox(
                //     width: 110,
                //     child: FittedBox(
                //       child: Text(
                //         DateTimeHelpers.getStingDate(DateTime.now()),
                //         style: const TextStyle(
                //           fontSize: 16.0,
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
                // //time
                // Positioned(
                //   bottom: 38,
                //   right: 5,
                //   child: SizedBox(
                //     width: 80,
                //     child: FittedBox(
                //       child: Text(
                //         DateTimeHelpers.getTimeFromDate(
                //           DateTime.now(),
                //         ),
                //         style: TextStyle(
                //           fontWeight: FontWeight.w600,
                //           fontSize: 18.0,
                //           color: Theme.of(context).iconTheme.color,
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
                // //trip dest
                // const Positioned(
                //   bottom: 5,
                //   right: 5,
                //   child: SizedBox(
                //     width: 145,
                //     child: FittedBox(
                //       child: Text(
                //         'من : الحديدة  إلى : لحج',
                //         style: TextStyle(
                //           fontSize: 18.0,
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
                // //call button
                // Positioned(
                //   bottom: 5,
                //   left: 5,
                //   child: SizedBox(
                //     width: 45,
                //     child: FittedBox(
                //       child: IconButton(
                //         onPressed: () {},
                //         icon: const Icon(
                //           Icons.call,
                //           size: 40.0,
                //         ),
                //       ),
                //     ),
                //   ),
                // ),

                // Align(
                //   alignment: Alignment.bottomCenter,
                //   child: SizedBox(
                //     width: double.infinity,
                //     child: ElevatedButton(
                //       onPressed: () {},
                //       child: const Text('الإتصال'),
                //     ),
                //   ),
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
