import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:project_first_model/widgets/main_screen_widgets/overland_transports/overland_transport_item.dart';

class OverlandTransportList extends StatefulWidget {
  const OverlandTransportList({
    Key? key,
    required this.controller,
  }) : super(key: key);
  final ScrollController controller;

  @override
  OverlandTransportListState createState() => OverlandTransportListState();
}

class OverlandTransportListState extends State<OverlandTransportList> {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      primary: false,
      shrinkWrap: true,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 2.0,
        // childAspectRatio: (450.w / 420.h),
        mainAxisExtent: 460.h,
      ),
      itemCount: 20,
      itemBuilder: (BuildContext context, int index) {
        return const OverlandTransportItem();
      },
    );
  }
}
