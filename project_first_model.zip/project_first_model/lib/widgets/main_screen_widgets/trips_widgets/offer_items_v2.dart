import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/models/rating_model.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/widgets/custom_loadings/shimmer_widget.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_ink_well.dart';
import 'package:project_first_model/widgets/utiles/custom_modal_bottom_sheet.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class OfferItemsV2 extends StatefulWidget {
  const OfferItemsV2({
    Key? key,
    required this.trip,
    required this.getTripData,
    this.showCallBtn = true,
    this.showModalBtns = true,
  }) : super(key: key);

  final TripModel trip;
  final Future<TripModel?> Function(String tripID) getTripData;
  final bool showCallBtn;
  final bool showModalBtns;

  @override
  State<OfferItemsV2> createState() => _OfferItemsV2State();
}

class _OfferItemsV2State extends State<OfferItemsV2> {
  TripRatingModel? _tripRatingModel;
  @override
  void initState() {
    super.initState();
    Future.delayed(
      Duration.zero,
      () async {
        if (!widget.showModalBtns) {
          _tripRatingModel = await getTripRate(context);
          setState(() {});
        }
      },
    );
  }

  Future<TripRatingModel> getTripRate(BuildContext context) async {
    final rateProv = await Get.find<RatingController>().getTripRate(
      widget.trip.userId,
      widget.trip.tripId,
    );
    return rateProv;
  }

  Row buildRating(double starRatio, int peoCount) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          ' ( ${Utiles.getCountString(peoCount)} ) ',
          style: TextStyle(
            fontSize: 33.sp,
          ),
        ),
        const HorizantalSizedBox(12),
        ShowRating(
          ratingRatio: starRatio,
          itemSize: 40,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    return Opacity(
      opacity: widget.showCallBtn &&
              DateTimeHelpers.isDateTimeNOWAfter(widget.trip.fullDateTime)
          ? 0.6
          : 1.0,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        margin: const EdgeInsets.only(
          // top: 12.0,
          left: 12.0, //45.0,
          right: 12.0,
          bottom: 6.0,
        ),
        // elevation: 4,
        child: SizedBox(
          height: 300.h,
          child: CustomInkWell(
            allowRegisterOnly: false,
            onTap: () {
              CustomModalBottomSheet.buildTripDetailsModalSheet(
                context,
                tripModel: _tripRatingModel == null
                    ? widget.trip
                    : widget.trip.copyWith(
                        ratingRatio: _tripRatingModel!.starsRatio,
                        ratingPeopleCount: _tripRatingModel!.ratingPeopleCount,
                      ),
                showBtns: widget.showModalBtns,
              );
              // _buildInfoPopupModalSheet(context);
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              mainAxisSize: MainAxisSize.max,
              children: [
                const HorizantalSizedBox(30),
                //trip data
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    //driver pic
                    CircleSqureImage(
                      pic: widget.trip.driverPic,
                      width: 210,
                      height: 210,
                      radius: 105,
                      id: widget.trip.driverPic,
                    ),
                    const HorizantalSizedBox(28),
                    //trip info
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        const VerticalSizedBox(24),
                        //driverName
                        Text(
                          widget.trip.driverName,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 40.sp,
                          ),
                        ),
                        //date and time
                        Text(
                          DateTimeHelpers.getFullDateTimeInLetterFormat(
                              widget.trip.fullDateTime),
                          style: TextStyle(
                            fontSize: 36.sp,
                          ),
                        ),
                        //dest
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _BuildLocations(
                              themeColor: themeColor,
                              location: widget.trip.from,
                            ),
                            const HorizantalSizedBox(8),
                            Icon(
                              FontAwesomeIcons.leftLong,
                              size: 55.sp,
                            ),
                            const HorizantalSizedBox(8),
                            _BuildLocations(
                              themeColor: themeColor,
                              location: widget.trip.to,
                            ),
                          ],
                        ),
                        //rating
                        if (widget.showCallBtn)
                          buildRating(
                            widget.trip.ratingRatio,
                            widget.trip.ratingPeopleCount,
                          ),
                        if (!widget.showCallBtn)
                          _tripRatingModel == null
                              ? ShimmerWidget.rectangular(
                                  height: 35,
                                  width: 170,
                                )
                              : buildRating(
                                  _tripRatingModel?.starsRatio ?? 0.0,
                                  _tripRatingModel?.ratingPeopleCount ?? 0,
                                ),
                        // FutureBuilder<TripRatingModel>(
                        //   future: getTripRate(context),
                        //   builder: (context, snapshot) {
                        //     if (snapshot.connectionState ==
                        //         ConnectionState.waiting) {
                        //       return ShimmerWidget.rectangular(
                        //         height: 35,
                        //         width: 170,
                        //       );
                        //     }
                        //     return ShowRating(
                        //       ratingRatio: snapshot.data?.starsRatio ?? 0.0,
                        //       itemSize: 40,
                        //     );
                        //   },
                        // ),

                        const VerticalSizedBox(7),
                      ],
                    ),
                  ],
                ),
                // const Expanded(
                //   child: SizedBox(width: double.infinity),
                // ),
                const HorizantalSizedBox(20.0),
                if (widget.showCallBtn)
                  CustomIconButton(
                    iconData: FontAwesomeIcons.phone,
                    tooltip: 'إتصل بالسائق',
                    iconSize: 90.0,
                    isError: DateTimeHelpers.isDateTimeNOWAfter(
                        widget.trip.fullDateTime),
                    onPressed: () {
                      if (DateTimeHelpers.isDateTimeNOWAfter(
                          widget.trip.fullDateTime)) {
                        ShowAnyMessages.faildTask(
                          context,
                          'الرحلة إنتهت بالفعل! لا يمكن الإتصال بالسائق',
                        );
                        return;
                      }
                      CustomModalBottomSheet.makeACall(
                        widget.trip.tripId,
                        context,
                        widget.trip.userId,
                      );
                    },
                  ),
                if (!widget.showCallBtn)
                  _tripRatingModel == null
                      ? ShimmerWidget.circular(
                          height: 80,
                          width: 80,
                        )
                      : InkWell(
                          child: Tooltip(
                            message: 'عدد المقيمين',
                            child: SizedBox(
                              width: 60.w,
                              height: 90.h,
                              child: FittedBox(
                                child: Text(
                                  Utiles.getCountString(
                                      _tripRatingModel?.ratingPeopleCount ?? 0),
                                  style: TextStyle(
                                    fontSize: 46.sp,
                                    // fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),

                const HorizantalSizedBox(30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BuildLocations extends StatelessWidget {
  const _BuildLocations({
    Key? key,
    required this.themeColor,
    required this.location,
  }) : super(key: key);

  final ThemeData themeColor;
  final String location;

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        style: TextStyle(
          fontFamily: themeColor.textTheme.bodyLarge?.fontFamily,
        ),
        children: [
          WidgetSpan(
            child: Padding(
              padding: CustomEdgeInsets.only(bottom: 12.0),
              child: Icon(
                Icons.location_pin,
                size: 38.0.sp,
              ),
            ),
          ),
          TextSpan(
            text: location,
            style: TextStyle(
              color: themeColor.textTheme.bodyLarge?.color,
              fontSize: 36.sp,
            ),
          ),
        ],
      ),
    );
  }
}

class ShowRating extends StatelessWidget {
  const ShowRating({
    Key? key,
    required this.ratingRatio,
    this.itemSize = 70,
  }) : super(key: key);
  final double ratingRatio;
  final double itemSize;

  @override
  Widget build(BuildContext context) {
    return RatingBarIndicator(
      itemSize: itemSize.sp,
      unratedColor: Colors.grey,
      itemBuilder: (ctx, index) {
        return const Icon(
          Icons.star,
          color: Colors.amber,
        );
      },
      rating: ratingRatio,
      textDirection: TextDirection.ltr,
    );
  }
}
