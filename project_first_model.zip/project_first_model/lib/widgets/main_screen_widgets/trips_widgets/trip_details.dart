import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/alarm_controllers/alarm_controller.dart';
import 'package:project_first_model/controllers/driver_controllers/call_records_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/models/alarm_model.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/offer_items_v2.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_modal_bottom_sheet.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';

class TripDetails extends StatefulWidget {
  const TripDetails({
    Key? key,
    required this.scrollController,
    this.tripID = '',
    this.tripModel,
    required this.makeACall,
    required this.showBelowBtns,
    this.getTripData,
  }) : super(key: key);
  final ScrollController scrollController;
  final bool showBelowBtns;
  final String tripID;
  final void Function(
    String phoneNumber,
    // BuildContext context,
    String driverID,
  ) makeACall;
  final Future<TripModel?> Function(String)? getTripData;
  final TripModel? tripModel;

  @override
  State<TripDetails> createState() => _TripDetailsState();
}

class _TripDetailsState extends State<TripDetails> {
  TripModel trip = TripModel.defaultTrip;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () async {
      await _getData();
    });
  }

  Future<void> _getData() async {
    CustomOverlayLoading.showOverlayLoading();
    try {
      TripModel? tempTrip;
      if (widget.tripModel == null) {
        if (widget.getTripData == null || widget.tripID == '') {
          throw CustomException("حدث خطأ أثناء التحميل يرجى المحاولة لاحقاً");
        }

        tempTrip = await widget.getTripData!(widget.tripID);
      } else {
        tempTrip = widget.tripModel;
      }

      if (tempTrip == null) {
        throw CustomException("trip-not-found");
      }

      setState(() {
        trip = tempTrip!;
      });
    } on CustomException catch (e) {
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        isError: true,
        floating: false,
      );
      CustomOverlayLoading.hideOverlayLoading();
      Get.find<AppRouter>().pop();
      // Navigator.of(context).pop();
    }
    // if (!mounted) return;
    CustomOverlayLoading.hideOverlayLoading();
  }

  Widget _buildDivider() => Divider(
        height: 5.h,
        color: Colors.blueGrey,
      );

  Row buildRating(double starRatio, int peoCount) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        ShowRating(
          ratingRatio: starRatio,
        ),
        const HorizantalSizedBox(12),
        Text(
          ' ( ${Utiles.getCountString(peoCount)} ) ',
          style: TextStyle(
            fontSize: 33.sp,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    int counter = 1;
    return Column(
      children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(25),
              ),
            ),
            padding: CustomEdgeInsets.only(
              top: 28.0,
              right: 32.0,
              left: 32.0,
            ),
            child: ListView(
              controller: widget.scrollController,
              children: [
                //Driver Pic
                Hero(
                  tag: 'DriverPic',
                  child: CircleSqureImage(
                    pic: trip.driverPic,
                    radius: 475.r,
                    width: 950.w,
                    height: 950.h,
                    id: trip.driverPic,
                  ),
                ),
                const VerticalSizedBox(40),
                //Driver Name
                Text(
                  trip.driverName,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 50.sp,
                  ),
                ),
                const VerticalSizedBox(30),
                //Rate Driver
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (widget.showBelowBtns)
                      CustomTextButton(
                        title: 'تقييم السائق',
                        onPressed: () async {
                          try {
                            final authProv = Get.find<FirebaseAuthController>();

                            final valid = await authProv.validToken();
                            if (!valid) return;

                            final currentUser = authProv.getCurrentUser?.uid;

                            // if (!mounted) return;
                            final prov = Get.find<CallRecordController>();

                            final calledTheDriverBefore =
                                await prov.didICallThisDriver(
                              currentUser ?? '',
                              trip.userId,
                            );

                            if (!calledTheDriverBefore) {
                              if (!mounted) return;
                              ShowAnyMessages.faildTask(
                                context,
                                'لا يمكن تقييم السائق حتى يتم التواصل معه.',
                              );
                              return;
                            }
                            // if (!mounted) return;
                            CustomModalBottomSheet.buildDriverRateModalSheet(
                              // context,
                              driverID: trip.userId,
                              driverName: trip.driverName,
                              driverPic: trip.driverPic,
                              tripID: trip.tripId,
                              userID: currentUser!,
                            );
                          } on CustomException catch (e) {
                            ShowAnyMessages.showSnackBar(
                              context,
                              e.errorMessage,
                              isError: true,
                              floating: false,
                            );
                          }
                        },
                      ),
                    const HorizantalSizedBox(30),
                    buildRating(trip.ratingRatio, trip.ratingPeopleCount),
                  ],
                ),
                const VerticalSizedBox(30),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    //Trip title
                    _Title(
                      title: 'تفاصيل الرحلة',
                      status: true,
                      isAvailable: !DateTimeHelpers.isDateTimeNOWAfter(
                          trip.fullDateTime),
                    ),
                    const VerticalSizedBox(20),
                    //Trip Time
                    _DetailView(
                      title: 'موعد الرحلة : ',
                      widgetvalue: Text(
                        DateTimeHelpers.getFullDateTimeInLetterFormat(
                            trip.fullDateTime),
                        style: TextStyle(
                          fontSize: 40.0.sp,
                        ),
                      ),
                    ),
                    _buildDivider(),
                    //From
                    _DetailView(
                      title: 'من :',
                      widgetvalue: Text(
                        trip.from,
                        textDirection: TextDirection.ltr,
                        style: TextStyle(
                          fontSize: 40.sp,
                          // fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    _buildDivider(),
                    //TO
                    _DetailView(
                      title: 'إلى :',
                      widgetvalue: Text(
                        trip.to,
                        textDirection: TextDirection.ltr,
                        style: TextStyle(
                          fontSize: 40.sp,
                          // fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    _buildDivider(),
                    //price
                    _DetailView(
                      title: 'السعر للراكب الواحد :',
                      widgetvalue: Text(
                        trip.tripPrice > 0
                            ? trip.tripPrice.toString()
                            : 'غير متوفر',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(
                          fontSize: 40.sp,
                          // fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    _buildDivider(),
                    //trusteeship
                    _DetailView(
                      title: 'متاح نقل أوراق & أمانات :',
                      widgetvalue: Text(
                        trip.trusteeship ? 'نعم' : 'لا',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(
                          fontSize: 40.sp,
                          fontWeight: FontWeight.bold,
                          color: trip.trusteeship ? Colors.green : Colors.red,
                        ),
                      ),
                    ),
                    _buildDivider(),
                    //Secondary Dest
                    _DetailView(
                      title: 'وجهات ثانوية :',
                      widgetvalue: SizedBox(
                        width: 400.w,
                        child: Wrap(
                          direction: Axis.horizontal,
                          spacing: 5,
                          runSpacing: 5,
                          alignment: WrapAlignment.spaceAround,
                          runAlignment: WrapAlignment.spaceAround,
                          children: [
                            ...trip.secondaryDest.map((dest) {
                              return Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    '${counter++} - $dest, ',
                                    // textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                      fontSize: 40.sp,
                                      // fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const HorizantalSizedBox(20),
                                ],
                              );
                            }).cast<Widget>(),
                          ],
                        ),
                      ),
                    ),
                    _buildDivider(),
                    //Notes
                    _DetailView(
                      title: 'ملاحظات :',
                      widgetvalue: SizedBox(
                        width: 600.h,
                        child: Text(
                          trip.notes.isEmpty || trip.notes == ''
                              ? 'لا يوجد ملاحظات !'
                              : trip.notes,
                          style: TextStyle(
                            fontSize: 40.sp,
                          ),
                          softWrap: true,
                          textAlign: TextAlign.end,
                        ),
                      ),
                    ),
                    _buildDivider(),
                    const VerticalSizedBox(20),
                    // if (widget.showBelowBtns)
                    //   SizedBox(
                    //     width: double.infinity,
                    //     child: CustomElevatedButton(
                    //       title: 'ارسال طلب انضمام',
                    //       onPressed: () {},
                    //       padding: 20.0,
                    //       style: ElevatedButton.styleFrom(
                    //         shape: const RoundedRectangleBorder(
                    //           borderRadius: BorderRadius.zero,
                    //         ),
                    //       ),
                    //     ),
                    //   ),

                    const VerticalSizedBox(20),
                    //Car title
                    const _Title(title: 'صور المركبة'),
                    const VerticalSizedBox(20),
                    //Car Pics
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Expanded(
                          child: CircleSqureImage(
                            pic: trip.carPic1,
                            radius: 0,
                            width: double.infinity,
                            height: 600,
                            isCircle: false,
                            id: trip.carPic1,
                          ),
                        ),
                        const HorizantalSizedBox(20),
                        Expanded(
                          child: CircleSqureImage(
                            pic: trip.carPic2,
                            radius: 0,
                            width: double.infinity,
                            height: 600,
                            isCircle: false,
                            id: trip.carPic2,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const VerticalSizedBox(20),
                if (widget.showBelowBtns)
                  CustomTextIconButton(
                    iconData: Icons.report_outlined,
                    title: 'الإبلاغ عن صاحب الرحلة ',
                    onPressed: () async {
                      // Get.toNamed(Routes.getDriverReportScreen(trip.userId));
                      Get.find<AppRouter>().push(
                        ReportRoute(
                          driverID: trip.userId,
                        ),
                      );
                    },
                  ),
                const VerticalSizedBox(20),
                CustomElevatedButton(
                  title: 'إغلاق',
                  onPressed: () async {
                    Navigator.of(context).pop();
                    // Get.find<AppRouter>().pop();
                  },
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                ),
              ],
            ),
          ),
        ),
        if (widget.showBelowBtns)
          Container(
            height: 170.h,
            color: Theme.of(context).scaffoldBackgroundColor,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              // crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const HorizantalSizedBox(6),
                Expanded(child: _RemindMeButton(trip: trip)),
                const HorizantalSizedBox(6),
                Expanded(
                  child: CustomElevatedButton(
                    title: 'الإتصال بالسائق',
                    onPressed: () {
                      if (DateTimeHelpers.isDateTimeNOWAfter(
                          trip.fullDateTime)) {
                        ShowAnyMessages.faildTask(
                          context,
                          'الرحلة إنتهت بالفعل! لا يمكن الإتصال بالسائق',
                        );
                        return;
                      }
                      widget.makeACall(trip.tripId, trip.userId);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          DateTimeHelpers.isDateTimeNOWAfter(trip.fullDateTime)
                              ? Colors.red
                              : Colors.green,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                  ),
                ),
                const HorizantalSizedBox(6),
              ],
            ),
          ),
      ],
    );
  }
}

class _DetailView extends StatelessWidget {
  const _DetailView({
    Key? key,
    required this.title,
    required this.widgetvalue,
  }) : super(key: key);
  final String title;
  final Widget widgetvalue;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: CustomEdgeInsets.all(10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 40.sp,
              // fontWeight: FontWeight.bold,
            ),
          ),
          const VerticalSizedBox(20),
          widgetvalue,
        ],
      ),
    );
  }
}

class _Title extends StatelessWidget {
  const _Title({
    Key? key,
    required this.title,
    this.status = false,
    this.isAvailable,
  }) : super(key: key);
  final String title;
  final bool status;
  final bool? isAvailable;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      mainAxisSize: MainAxisSize.max,
      children: [
        // const HorizantalSizedBox(20),
        Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 60.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
        if (status)
          Text(
            (isAvailable ?? false) ? 'متاحة' : 'انتهت',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 60.sp,
              fontWeight: FontWeight.bold,
              color: isAvailable ?? false ? Colors.green : Colors.red,
            ),
          ),
      ],
    );
  }
}

class _RemindMeButton extends StatelessWidget {
  const _RemindMeButton({
    Key? key,
    required this.trip,
  }) : super(key: key);

  final TripModel trip;

  void _addAlarm(AlarmController prov, BuildContext context) async {
    try {
      final auth = Get.find<FirebaseAuthController>().getCurrentUser?.uid ?? '';
      final tripProv = Get.find<TripController>();
      if (DateTimeHelpers.isDateTimeNOWAfter(trip.fullDateTime)) {
        //trip.fullDateTime.isBefore(DateTime.now())
        throw CustomException(
            'لقد إنقضى وقت الرحلة بالفعل الرحلة هي للتقييم فقط ');
      }

      if (prov.checkIfTheTripIsALreadyAdded(trip.tripId)) {
        throw CustomException('تمت إضافة الرحلة بالفعل لقائمة التنبيهات !');
      }

      final phoneNumber =
          await tripProv.getDriverPhoneNumber(trip.userId, trip.tripId);
      if (phoneNumber == '') {
        throw CustomException('number-not-found');
      }

      await prov.addAlarm(
        AlarmModel(
          tripId: trip.tripId,
          tripTime: trip.fullDateTime,
          isEnabled: 1,
          driverName: trip.driverName,
          driverPhone: phoneNumber,
          destination: trip.to,
          userId: auth,
          driverId: trip.userId,
          colorIndex: 0,
        ),
      );
      ShowAnyMessages.showSnackBar(
        context,
        'تمت الإضافة بنجاح  ',
        isSuccess: true,
      );
    } on CustomException catch (e) {
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        isError: true,
        floating: false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AlarmController>(
      builder: (prov) {
        final alreadyAdded = prov.checkIfTheTripIsALreadyAdded(trip.tripId);
        return CustomElevatedButton(
          title:
              alreadyAdded ? 'تمت إضافة الرحلة بالفعل !' : 'تذكير بموعد الرحلة',
          onPressed: alreadyAdded ? null : () => _addAlarm(prov, context),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.purple,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.zero,
            ),
          ),
        );
      },
    );
  }
}
