import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/trip_controllers/trip_filter_controller.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/helpers/show_date_time_picker.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/models/cities_model.dart';
import 'package:project_first_model/models/filter_model.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_card.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_checkbox.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';
import 'package:project_first_model/widgets/utiles/custom_text_field.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

class TripsFiltersWidget extends StatefulWidget {
  const TripsFiltersWidget({
    Key? key,
    this.showTitle = true,
    this.popAfterSave = false,
    this.showElevation = true,
    this.paddingEdges = true,
  }) : super(key: key);
  final bool showTitle;
  final bool showElevation;
  final bool popAfterSave;
  final bool paddingEdges;

  @override
  State<TripsFiltersWidget> createState() => _TripsFiltersWidgetState();
}

class _TripsFiltersWidgetState extends State<TripsFiltersWidget> {
  final _fromController = TextEditingController();
  final _toController = TextEditingController();
  // final _driverNameConttroler = TextEditingController();
  final _dateController = TextEditingController();
  final _timeController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _ischecked = false;

  @override
  void initState() {
    super.initState();

    // Future.delayed(Duration.zero, () {
    //   _getData();
    // });
  }

  bool noCityError(String cityName) {
    final cities = CityModel.cityList;
    if (cityName.isNotEmpty) {
      if (cities.contains(cityName)) return true;
    }
    return false;
  }

  void _getData(FiltersModel filter) {
    Future.delayed(
      Duration.zero,
      () {
        _fromController.text = filter.from;
        _toController.text = filter.to;
        _dateController.text = filter.date == null
            ? ''
            : DateTimeHelpers.convertDateToString(filter.date!);
        _timeController.text = filter.time == null
            ? ''
            : DateTimeHelpers.convertTimeOfDayToString(filter.time!);

        if (_ischecked != filter.searchForBigger) {
          setState(() {
            _ischecked = filter.searchForBigger;
          });
        }
      },
    );
  }

  void _save() {
    final isValid = _formKey.currentState!.validate();
    if (!isValid) return;
    if (_fromController.text.isEmpty &&
        _toController.text.isEmpty &&
        _dateController.text.isEmpty &&
        _timeController.text.isEmpty) {
      ShowAnyMessages.faildTask(
        context,
        'لا يمكن البحث وجميع الحقول فارغة',
      );
      return;
    }

    var filters = FiltersModel(
      from: _fromController.text,
      to: _toController.text,
      date: _dateController.text.isEmpty || _dateController.text == ''
          ? null
          : DateTimeHelpers.convertStringToDate(_dateController.text),
      fullDateTime: _dateController.text.isEmpty || _dateController.text == ''
          ? null
          : DateTimeHelpers.convertStringToDate(_dateController.text),
      time: _timeController.text.isEmpty || _timeController.text == ''
          ? null
          : DateTimeHelpers.convertToTimeOfDayV2(_timeController.text),
      searchForBigger: _ischecked,
    );

    if (_timeController.text.isNotEmpty && _dateController.text.isNotEmpty) {
      filters = filters.copyWith(
        fullDateTime:
            DateTimeHelpers.convertToDateTime(filters.date!, filters.time!),
      );
    }

    Get.find<TripFilterController>().addFilters(filters);

    if (!widget.popAfterSave) {
      // Get.toNamed(Routes.showFilterTripsPage);
      Get.find<AppRouter>().push(
        const ShowFilterTripsRoute(),
      );
    } else {
      Navigator.of(context).pop();
      // Get.find<AppRouter>().pop();
    }
  }

  void _handelCheckState(bool isChecked) {
    _ischecked = isChecked;
  }

  void _restWidget() {
    final prov = Get.find<TripFilterController>();
    if (prov.isTherefilter) {
      prov.clearFilter();
    } else {
      _getData(FiltersModel.defaultFilters);
    }
  }

  @override
  void dispose() {
    _fromController.dispose();
    _dateController.dispose();
    _timeController.dispose();
    _toController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: CustomEdgeInsets.all(8.0),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          reverse: true,
          primary: true,
          child: GetBuilder<TripFilterController>(
            builder: (tripProv) {
              _getData(tripProv.filter);
              return Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const VerticalSizedBox(15),
                  CustomCard(
                    paddingEdges: widget.paddingEdges,
                    showElevation: widget.showElevation,
                    title: widget.showTitle ? 'بحث على حسب: ' : '',
                    children: [
                      //From
                      CustomTextField(
                        title: 'من',
                        textController: _fromController,
                        otherControlersValues: [_toController],
                        autoValidate: true,
                        allowNullValue: true,
                        suggestionCallback: CityModel.citySuggestions,
                        fieldList: CityModel.getCities,
                        // initalValue: false,
                      ),
                      const VerticalSizedBox(30),
                      //TO
                      CustomTextField(
                        title: 'إلى',
                        textController: _toController,
                        otherControlersValues: [_fromController],
                        autoValidate: true,
                        allowNullValue: true,
                        isTheLast: true,
                        suggestionCallback: CityModel.citySuggestions,
                        fieldList: CityModel.getCities,
                        // initalValue: false,
                      ),
                      const VerticalSizedBox(30),
                      const Divider(),

                      //Date
                      CustomTextFormField(
                        label: 'التاريخ',
                        controller: _dateController,
                        readOnly: true,
                        textInputAction: TextInputAction.next,
                        textInputType: TextInputType.datetime,
                        validator: null,
                        onSaved: null,
                        showIconButton: true,
                        icon: Icons.date_range_outlined,
                        onIconPressed: () async {
                          await showDateDialog(context);
                        },
                        onTap: () async {
                          await showDateDialog(context);
                        },
                        iconToolTip: 'حدد التاريخ',
                      ),
                      const VerticalSizedBox(30),
                      //Time
                      CustomTextFormField(
                        label: 'الوقت',
                        controller: _timeController,
                        readOnly: true,
                        textInputAction: TextInputAction.done,
                        textInputType: TextInputType.datetime,
                        validator: null,
                        onSaved: null,
                        showIconButton: true,
                        icon: Icons.timer_outlined,
                        onIconPressed: () async {
                          await showTimeDialog(context);
                        },
                        onTap: () async {
                          await showTimeDialog(context);
                        },
                        iconToolTip: 'حدد الوقت',
                      ),
                      const VerticalSizedBox(30),
                      const Divider(),

                      CustomCheckBox(
                        checkedHandeler: _handelCheckState,
                        isChecked: _ischecked,
                        title:
                            'إظهار جميع الرحلات التي بعد أو تساوي التاريخ المحدد',
                      ),
                      const VerticalSizedBox(10),
                      const VerticalSizedBox(35),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomElevatedButton(
                            title: 'بحث',
                            allowRegisterOnly: false,
                            onPressed: _save,
                            // style: ElevatedButton.styleFrom(
                            //   shape: const RoundedRectangleBorder(
                            //     borderRadius: BorderRadius.all(Radius.zero),
                            //   ),
                            // ),
                          ),
                          const HorizantalSizedBox(12),
                          CustomTextButton(
                            title: 'إعادة تهيئة الحقول',
                            allowRegisterOnly: false,
                            onPressed: _restWidget,
                          ),
                        ],
                      ),
                    ],
                  ),
                  const VerticalSizedBox(15),
                  // const Divider(),
                  // AdsHelper(
                  //   adSize: AdSize.mediumRectangle,
                  //   bannerUnitID: GoogleMobAds.getTripSearchUnitID(),
                  // ),
                  // const Divider(),
                  const BottomPadding(),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> showTimeDialog(BuildContext context) async {
    _timeController.text = await ShowDateTimePickers.showCustomTimePicker(
      // context,
      _timeController.text,
    );
  }

  Future<void> showDateDialog(BuildContext context) async {
    _dateController.text = await ShowDateTimePickers.showCustomDatePicker(
      // context,
      _dateController.text,
      firstDateYearAgo: true,
    );
  }
}
