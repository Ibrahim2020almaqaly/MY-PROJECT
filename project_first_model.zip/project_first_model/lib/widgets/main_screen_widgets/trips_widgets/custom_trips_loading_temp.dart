import 'package:flutter/material.dart';
import 'package:project_first_model/widgets/custom_loadings/trips_loading_v2.dart';

class CustomTripsLoading extends StatelessWidget {
  const CustomTripsLoading({
    Key? key,
    this.direction = Axis.vertical,
  }) : super(key: key);
  final Axis direction;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      primary: false,
      scrollDirection: direction,
      itemCount: 10,
      itemBuilder: (BuildContext context, int index) {
        return const TripsLoadingV2();
      },
    );
  }
}
