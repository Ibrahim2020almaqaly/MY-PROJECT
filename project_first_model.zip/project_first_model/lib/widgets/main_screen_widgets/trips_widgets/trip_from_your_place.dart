import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_ui_firestore/firebase_ui_firestore.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/trip_filter_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/widgets/custom_loadings/custom_list_loading.dart';
import 'package:project_first_model/widgets/custom_loadings/trips_loading_v2.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/show_any_list_view.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/snapshot_error.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/offer_items_v2.dart';

class TripsFromYourPlace extends StatefulWidget {
  const TripsFromYourPlace({Key? key}) : super(key: key);

  @override
  State<TripsFromYourPlace> createState() => _TripsFromYourPlaceState();
}

class _TripsFromYourPlaceState extends State<TripsFromYourPlace> {
  final ScrollController scrollController = ScrollController();

  Widget _handleDataView(List<QueryDocumentSnapshot<dynamic>> driversDocs,
      int index, BuildContext context) {
    final trip = driversDocs[index].data();
    return OfferItemsV2(
      trip: trip,
      getTripData: (String tripID) async {
        return await Get.find<TripController>().findTripById(tripID);
      },
    );
  }

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      controller: scrollController,
      children: [
        GetBuilder<UserController>(
          builder: (userProv) {
            final region = userProv.getUserData.region;
            return GetBuilder<TripFilterController>(
              builder: (tripProv) {
                return FirestoreQueryBuilder<TripModel>(
                  pageSize: 5,
                  query: tripProv.getMyRegionTripsQuery(region),
                  builder: (ctx, snapshot, _) {
                    if (snapshot.isFetching) {
                      return const CustomListLoading(
                        count: 20,
                        scrollDirection: Axis.horizontal,
                        child: TripsLoadingV2(),
                      );
                    } else if (snapshot.hasError) {
                      return SnapshotError(
                        error: snapshot.error,
                        showIcon: false,
                        onPressed: () {
                          tripProv.refershFilteredTripQuery();
                        },
                      );
                    }
                    return ShowAnyListView(
                      noDataFoundTitle: 'لا توجد رحلات من منطقتك بعد !',
                      noMoreDataTitle: 'لا توجد رحلات أخرى من منطقتك !',
                      showIcon: false,
                      snapshot: snapshot,
                      scrollController: scrollController,
                      refershQuery: () {
                        tripProv.refershFilteredTripQuery();
                      },
                      handelDataView: _handleDataView,
                      scrollDirection: Axis.horizontal,
                    );
                  },
                );
              },
            );
          },
        ),
      ],
    );
  }
}
