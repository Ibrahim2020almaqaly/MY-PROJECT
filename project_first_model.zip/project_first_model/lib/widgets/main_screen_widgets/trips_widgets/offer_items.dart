import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/alarm_controllers/alarm_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/models/alarm_model.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_modal_bottom_sheet.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class OfferItems extends StatelessWidget {
  const OfferItems({
    Key? key,
    required this.trip,
  }) : super(key: key);

  final TripModel trip;

  // void _makeACall(String number, BuildContext context) async {
  //   try {
  //     final user = Provider.of<FirebaseAuthProvider>(context, listen: false)
  //         .getCurrentUser;
  //     if (user == null) {
  //       await ShowCustomDialog.notLoggedInUserWithNavigation(context);
  //       return;
  //       // throw CustomException('يجب أن تسجل حساب لكي تستطيع التواصل بالسائق');
  //     }
  //     await CallRecordProvider.callAndRegister(
  //       trip.phoneNumber,
  //       user.uid,
  //       trip.userId,
  //     );
  //   } on CustomException catch (e) {
  //     ShowAnyMessages.showToastMSG(e.errorMessage);
  //   } catch (e) {
  //     ShowAnyMessages.showToastMSG(e.toString());
  //   }
  // }

  Widget _makeDissmisable({
    required Widget child,
    required BuildContext context,
  }) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        // Navigator.of(context).pop();
        Get.find<AppRouter>().pop();
      },
      child: GestureDetector(
        onTap: () {},
        child: child,
      ),
    );
  }

  void _buildInfoPopupModalSheet(BuildContext context) {
    showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      context: context,
      builder: (ctx) {
        // final prov = Provider.of<AlarmProvider>(context, listen: false);
        // final alreadyAdded = prov.checkIfTheTripIsALreadyAdded(trip.tripId!);
        return _makeDissmisable(
          context: context,
          child: DraggableScrollableSheet(
            initialChildSize: 0.7,
            minChildSize: 0.4,
            maxChildSize: 0.9,
            builder: (modalCtx, scrollController) {
              int counter = 1;
              return Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).scaffoldBackgroundColor,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(25),
                      ),
                    ),
                    padding: CustomEdgeInsets.all(16.0),
                    child: ListView(
                      controller: scrollController,
                      children: [
                        Hero(
                          tag: 'DriverPic',
                          child: CircleSqureImage(
                            pic: trip.driverPic,
                            radius: 100,
                            width: 200,
                            height: 200,
                          ),
                        ),
                        const VerticalSizedBox(20),
                        Text(
                          trip.driverName,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20.sp,
                          ),
                        ),
                        const VerticalSizedBox(15),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ElevatedButton(
                              onPressed: () async {
                                final currentUser =
                                    Get.find<FirebaseAuthController>()
                                        .getCurrentUser
                                        ?.uid;
                                CustomModalBottomSheet
                                    .buildDriverRateModalSheet(
                                  // context,
                                  driverID: trip.userId,
                                  driverName: trip.driverName,
                                  driverPic: trip.driverPic,
                                  tripID: trip.tripId,
                                  userID: currentUser!,
                                );
                              },
                              child: const Text('تقييم السائق'),
                            ),
                            const HorizantalSizedBox(15),
                            ShowRating(
                              ratingRatio: trip.ratingRatio,
                            ),
                          ],
                        ),
                        const VerticalSizedBox(15),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            RemindMeButton(trip: trip),
                            ElevatedButton.icon(
                              icon: const Icon(
                                Icons.call_outlined,
                              ),
                              label: const Text('الإتصال بالسائق'),
                              onPressed: () {
                                // _makeACall(trip.phoneNumber, context);
                              },
                            ),
                          ],
                        ),
                        const VerticalSizedBox(10),
                        Column(
                          children: [
                            Text(
                              'موعد الرحلة: ',
                              style: TextStyle(
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const VerticalSizedBox(10),
                            Text(
                              DateTimeHelpers.convertDateTimeToString(
                                DateTimeHelpers.convertToDateTime(
                                  trip.tripDate,
                                  trip.tripTime,
                                ),
                              ),
                              textDirection: TextDirection.ltr,
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const VerticalSizedBox(10),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          // mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'الوجهة الرئيسية: ',
                              style: TextStyle(
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const VerticalSizedBox(10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              // mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  'من: ${trip.from}',
                                  style: const TextStyle(
                                    // fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'إلى: ${trip.to}',
                                  style: const TextStyle(
                                    // fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            Text(
                              'وجهات ثانوية',
                              style: TextStyle(
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const VerticalSizedBox(10),
                            Wrap(
                              direction: Axis.horizontal,
                              spacing: 5,
                              runSpacing: 5,
                              alignment: WrapAlignment.spaceAround,
                              runAlignment: WrapAlignment.spaceAround,
                              children: [
                                ...trip.secondaryDest.map((dest) {
                                  return Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '${counter++} - $dest, ',
                                        // textDirection: TextDirection.rtl,
                                        style: const TextStyle(
                                          // fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const HorizantalSizedBox(10),
                                    ],
                                  );
                                }).cast<Widget>(),
                              ],
                            ),
                          ],
                        ),
                        const VerticalSizedBox(10),
                        Text(
                          'ملاحظات:',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          trip.notes.isEmpty || trip.notes == ''
                              ? 'لا يوجد ملاحظات !'
                              : trip.notes,
                        ),
                        const VerticalSizedBox(10),
                        Text(
                          'صور المركبة',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const VerticalSizedBox(10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Expanded(
                              child: CircleSqureImage(
                                pic: trip.carPic1,
                                radius: 0,
                                width: double.infinity,
                                height: 300,
                                isCircle: false,
                              ),
                            ),
                            const HorizantalSizedBox(0),
                            Expanded(
                              child: CircleSqureImage(
                                pic: trip.carPic2,
                                radius: 0,
                                width: double.infinity,
                                height: 300,
                                isCircle: false,
                              ),
                            ),
                          ],
                        ),
                        const VerticalSizedBox(10),
                        ElevatedButton(
                          onPressed: () {
                            // Navigator.of(context).pop();
                            Get.find<AppRouter>().pop();
                          },
                          child: const Text('إغلاق'),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 5,
                    top: 5,
                    child: PopupMenuButton(
                      icon: const Icon(
                        Icons.more_vert_outlined,
                      ),
                      iconSize: 40,
                      offset: const Offset(0, 45),
                      itemBuilder: (_) => [
                        PopupMenuItem(
                          child: const Text('إبلاغ'),
                          onTap: () async {
                            final isUser = Get.find<FirebaseAuthController>()
                                    .getCurrentUser !=
                                null;

                            Navigator.pop(context);
                            // Navigator.pop(context);
                            if (isUser) {
                              // Navigator.push(
                              //   context,
                              //   MaterialPageRoute(
                              //     builder: (BuildContext context) =>
                              //         ReportScreen(driverID: trip.userId!),
                              //   ),
                              // );
                              // Get.toNamed(
                              //     Routes.getDriverReportScreen(trip.userId));
                              Get.find<AppRouter>().push(
                                ReportRoute(
                                  driverID: trip.userId,
                                ),
                              );
                              // Navigator.of(context).push(
                              //   MaterialPageRoute(
                              //     builder: (context) =>
                              //         ReportScreen(driverID: trip.userId!),
                              //   ),
                              // );
                            } else {
                              await ShowCustomDialog
                                  .notLoggedInUserWithNavigation(context);
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      margin: const EdgeInsets.only(
        // top: 12.0,
        left: 12.0, //45.0,
        right: 12.0,
        bottom: 6.0,
      ),
      elevation: 4,
      child: SizedBox(
        height: 150.h,
        child: InkWell(
          onTap: () {
            _buildInfoPopupModalSheet(context);
          },
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                //card width / 2
                //and - 50 to make it in the middle
                top: (150 / 2) - 50,
                left: 5, //-45,
                child: SizedBox(
                  width: 100.w,
                  child: FittedBox(
                    child: CircleSqureImage(
                      pic: trip.driverPic,
                      radius: 50.0,
                      width: 95.0,
                      height: 95.0,
                    ),
                  ),
                ),
              ),
              Positioned(
                top: -20,
                left: 15,
                right: 0,
                bottom: 0,
                child: Align(
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 190.w,
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            trip.driverName,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18.sp,
                              color: themeColor.colorScheme.onSurface,
                            ),
                          ),
                        ),
                      ),
                      const VerticalSizedBox(10),
                      SizedBox(
                        width: 140.w,
                        child: FittedBox(
                          child: Text(
                            DateTimeHelpers.convertDateTimeToString(
                              DateTimeHelpers.convertToDateTime(
                                trip.tripDate,
                                trip.tripTime,
                              ),
                            ),
                            textDirection: TextDirection.ltr,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16.sp,
                              color: themeColor.colorScheme.onSurface,
                            ),
                          ),
                        ),
                      ),
                      const VerticalSizedBox(10),
                      Container(
                        margin: CustomEdgeInsets.horizontal(4),
                        // alignment: Alignment.center,
                        child: SizedBox(
                          width: 160.w,
                          child: FittedBox(
                            child: Text(
                              'من ${trip.from}  إلى ${trip.to}',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14.sp,
                                color: themeColor.colorScheme.onSurface,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),

                        // Row(
                        //   mainAxisSize: MainAxisSize.min,
                        //   children: [
                        //     SizedBox(
                        //       width: 90,
                        //       child: FittedBox(
                        //         child: Text(
                        //           'من: ${trip.from}',
                        //           style: TextStyle(
                        //             fontWeight: FontWeight.bold,
                        //             fontSize: 14,
                        //             color: themeColor.colorScheme.onSurface,
                        //           ),
                        //           textAlign: TextAlign.center,
                        //         ),
                        //       ),
                        //     ),
                        //     const SizedBox(width: 5),
                        //     SizedBox(
                        //       width: 90,
                        //       child: FittedBox(
                        //         child: Text(
                        //           'إلى: ${trip.to}',
                        //           style: TextStyle(
                        //             fontWeight: FontWeight.bold,
                        //             fontSize: 14,
                        //             color: themeColor.colorScheme.onSurface,
                        //           ),
                        //           textAlign: TextAlign.center,
                        //         ),
                        //       ),
                        //     ),
                        //   ],
                        // ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 44,
                right: 5,
                child: SizedBox(
                  width: 50.w,
                  child: FittedBox(
                    child: IconButton(
                      tooltip: 'إتصل بالسائق',
                      onPressed: () {
                        // _makeACall(trip.phoneNumber, context);
                      },
                      icon: const Icon(
                        Icons.call_outlined,
                        size: 50,
                      ),
                    ),
                  ),
                ),
              ),
              Align(
                // top: 120,
                // left: -40,
                alignment: Alignment.bottomCenter,
                child: SizedBox(
                  width: 150.w,
                  child: FittedBox(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: ShowRating(
                        ratingRatio: trip.ratingRatio,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ReportButton extends StatelessWidget {
  const ReportButton({
    Key? key,
    required this.trip,
  }) : super(key: key);

  final TripModel trip;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton(
      icon: const Icon(
        Icons.more_vert_outlined,
      ),
      iconSize: 40,
      offset: const Offset(0, 45),
      itemBuilder: (_) => [
        PopupMenuItem(
          child: const Text('إبلاغ'),
          onTap: () async {
            final isUser =
                Get.find<FirebaseAuthController>().getCurrentUser != null;

            Navigator.pop(context);
            if (isUser) {
              // Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) =>
              //         ReportScreen(driverID: trip.userId!),
              //   ),
              // );
              // Get.toNamed(Routes.getDriverReportScreen(trip.userId));
              Get.find<AppRouter>().push(
                ReportRoute(
                  driverID: trip.userId,
                ),
              );
              // Navigator.of(context).push(
              //   MaterialPageRoute(
              //     builder: (context) => ReportScreen(driverID: trip.userId!),
              //   ),
              // );
            } else {
              await ShowCustomDialog.notLoggedInUserWithNavigation(context);
            }
          },
        ),
      ],
    );
  }
}

class ShowRating extends StatelessWidget {
  const ShowRating({
    Key? key,
    required this.ratingRatio,
    this.itemSize = 30,
  }) : super(key: key);
  final double ratingRatio;
  final double itemSize;

  @override
  Widget build(BuildContext context) {
    return RatingBarIndicator(
      itemSize: itemSize,
      unratedColor: Colors.grey,
      itemBuilder: (ctx, index) {
        return const Icon(
          Icons.star,
          color: Colors.amber,
        );
      },
      rating: ratingRatio,
      textDirection: TextDirection.ltr,
    );
  }
}

class RemindMeButton extends StatelessWidget {
  const RemindMeButton({
    Key? key,
    required this.trip,
  }) : super(key: key);

  final TripModel trip;

  void _addAlarm(AlarmController prov, BuildContext context) async {
    try {
      final auth = Get.find<FirebaseAuthController>().getCurrentUser?.uid ?? '';
      if (auth == '') {
        await ShowCustomDialog.notLoggedInUserWithNavigation(context);
        return;
      }
      if (trip.fullDateTime.isBefore(DateTime.now())) {
        throw CustomException(
            'لقد إنقضى وقت الرحلة بالفعل الرحلة هي للتقييم فقط ');
      }

      if (prov.checkIfTheTripIsALreadyAdded(trip.tripId)) {
        throw CustomException('تمت إضافة الرحلة بالفعل لقائمة التنبيهات !');
      }

      await prov.addAlarm(
        AlarmModel(
          tripId: trip.tripId,
          tripTime: trip.fullDateTime,
          isEnabled: 1,
          driverName: trip.driverName,
          driverPhone: trip.tripId,
          destination: trip.to,
          userId: auth,
          driverId: trip.userId,
          colorIndex: 0,
        ),
      );
      // ignore: use_build_context_synchronously
      ShowAnyMessages.showSnackBar(
        context,
        'تمت الإضافة بنجاح  ',
        isSuccess: true,
      );
    } on CustomException catch (e) {
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        isError: true,
        floating: false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AlarmController>(
      builder: (prov) {
        final alreadyAdded = prov.checkIfTheTripIsALreadyAdded(trip.tripId);
        return ElevatedButton.icon(
          icon: const Icon(Icons.add_alarm_outlined),
          onPressed: alreadyAdded ? null : () => _addAlarm(prov, context),
          label: alreadyAdded
              ? const Text('تمت إضافة الرحلة بالفعل !')
              : const Text('تذكير بموعد الرحلة'),
        );
      },
    );
  }
}
