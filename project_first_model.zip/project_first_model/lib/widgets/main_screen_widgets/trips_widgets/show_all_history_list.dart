import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_ui_firestore/firebase_ui_firestore.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/widgets/custom_loadings/custom_list_loading.dart';
import 'package:project_first_model/widgets/custom_loadings/trips_loading_v2.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/show_any_list_view.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/snapshot_error.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/offer_items_v2.dart';

class ShowAllHistoryList extends StatelessWidget {
  const ShowAllHistoryList({
    Key? key,
    required this.controller,
  }) : super(key: key);
  final ScrollController controller;

  Widget _handelTripDataView(List<QueryDocumentSnapshot<dynamic>> tripDocs,
      int index, BuildContext context) {
    var trip = tripDocs[index].data() as TripModel;
    final user = Get.find<UserController>().getUserData;
    trip = trip.copyWith(
      driverName: user.userName,
      driverPic: user.userPic,
      carPic1: user.userCarPic1,
      carPic2: user.userCarPic2,
    );

    return OfferItemsV2(
      trip: trip,
      getTripData: (String tripID) async {
        return await Get.find<TripController>().findTripHistoryById(tripID);
      },
      showCallBtn: false,
      showModalBtns: false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TripController>(
      builder: (tripProv) {
        return FirestoreQueryBuilder<TripModel>(
          query: tripProv.getTripsHistoryQuery,
          pageSize: 5,
          builder: (ctx, snapshot, _) {
            if (snapshot.isFetching) {
              return const CustomListLoading(
                count: 20,
                child: TripsLoadingV2(),
              );
            } else if (snapshot.hasError) {
              return SnapshotError(
                error: snapshot.error,
                onPressed: () {
                  tripProv.refershTripsHistoryQuery();
                },
              );
            }
            return ShowAnyListView(
              snapshot: snapshot,
              scrollController: controller,
              refershQuery: tripProv.refershTripsHistoryQuery,
              handelDataView: _handelTripDataView,
              noDataFoundTitle: 'لا توجد لديك رحلات بعد !',
              noMoreDataTitle: 'لا توجد لديك رحلات أخرى !',
            );
          },
        );
      },
    );
  }
}
