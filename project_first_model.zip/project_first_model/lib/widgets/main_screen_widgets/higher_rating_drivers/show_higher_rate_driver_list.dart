import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_ui_firestore/firebase_ui_firestore.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/models/rating_model.dart';
import 'package:project_first_model/widgets/custom_loadings/custom_list_loading.dart';
import 'package:project_first_model/widgets/custom_loadings/drivers_loading.dart';
import 'package:project_first_model/widgets/main_screen_widgets/higher_rating_drivers/higher_rate_driver.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/show_any_list_view.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/snapshot_error.dart';

class ShowHigherRateDriverList extends StatefulWidget {
  const ShowHigherRateDriverList({Key? key}) : super(key: key);

  @override
  State<ShowHigherRateDriverList> createState() =>
      _ShowHigherRateDriverListState();
}

class _ShowHigherRateDriverListState extends State<ShowHigherRateDriverList> {
  final ScrollController scrollController = ScrollController();
  Widget _handleDataView(List<QueryDocumentSnapshot<dynamic>> driversDocs,
      int index, BuildContext context) {
    final driver = driversDocs[index].data();
    return HigherRateDrivers(
      driverRate: driver,
    );
  }

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      controller: scrollController,
      children: [
        GetBuilder<RatingController>(
          builder: (rateProv) {
            return FirestoreQueryBuilder<DriverRatingModel>(
              pageSize: 5,
              query: rateProv.getHigherRateDriver,
              builder: (ctx, snapshot, _) {
                if (snapshot.isFetching) {
                  return const CustomListLoading(
                    count: 20,
                    scrollDirection: Axis.horizontal,
                    child: DriversLoading(),
                  );
                  // CustomDriversLoading();
                } else if (snapshot.hasError) {
                  return SnapshotError(
                    error: snapshot.error,
                    showIcon: false,
                    onPressed: () {
                      rateProv.refershFilteredHigherRate();
                    },
                  );
                }
                return ShowAnyListView(
                  noDataFoundTitle: 'لم يتم تقييم سائقين بعد !',
                  noMoreDataTitle: 'لا يوجد سائقين آخرين !',
                  showIcon: false,
                  snapshot: snapshot,
                  scrollController: scrollController,
                  refershQuery: () {
                    rateProv.refershFilteredHigherRate();
                  },
                  handelDataView: _handleDataView,
                  scrollDirection: Axis.horizontal,
                  // padding: 0,
                );
              },
            );
          },
        ),
      ],
    );
  }
}
