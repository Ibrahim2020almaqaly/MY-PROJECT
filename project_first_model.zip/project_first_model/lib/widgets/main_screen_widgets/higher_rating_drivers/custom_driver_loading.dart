import 'package:flutter/material.dart';
import 'package:project_first_model/widgets/custom_loadings/drivers_loading.dart';

class CustomDriversLoading extends StatelessWidget {
  const CustomDriversLoading({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      primary: false,
      itemCount: 20,
      scrollDirection: Axis.horizontal,
      physics: const NeverScrollableScrollPhysics(),
      itemBuilder: (BuildContext context, int index) {
        return const DriversLoading();
      },
    );
  }
}
