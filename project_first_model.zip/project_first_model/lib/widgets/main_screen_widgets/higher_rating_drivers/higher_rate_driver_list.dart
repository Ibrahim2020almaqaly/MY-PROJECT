import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_ui_firestore/firebase_ui_firestore.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/models/rating_model.dart';
import 'package:project_first_model/widgets/main_screen_widgets/higher_rating_drivers/custom_leader_board_loading.dart';
import 'package:project_first_model/widgets/main_screen_widgets/higher_rating_drivers/driver_rate_item.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/show_any_list_view.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/snapshot_error.dart';

class HigherRateDriverList extends StatefulWidget {
  const HigherRateDriverList({
    Key? key,
    required this.controller,
  }) : super(key: key);
  final ScrollController controller;

  @override
  HigherRateDriverListState createState() => HigherRateDriverListState();
}

class HigherRateDriverListState extends State<HigherRateDriverList> {
  Widget _handleDataView(List<QueryDocumentSnapshot<dynamic>> driversDocs,
      int index, BuildContext context) {
    final driver = driversDocs[index].data();
    return DriverRateItem(
      index: index + 1,
      driver: driver,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RatingController>(
      builder: (rateProv) {
        return FirestoreQueryBuilder<DriverRatingModel>(
          pageSize: 5,
          query: rateProv.getFilteredHigherRateDriver,
          builder: (ctx, snapshot, _) {
            if (snapshot.isFetching) {
              return const CustomLeaderBoardLoading();
            } else if (snapshot.hasError) {
              return SnapshotError(
                error: snapshot.error,
                onPressed: () {
                  rateProv.refershHigherRate();
                },
              );
            }
            return ShowAnyListView(
              noDataFoundTitle: 'لم يتم تقييم سائقين بعد !',
              noMoreDataTitle: 'لم يعد هناك سائقين آخرين!',
              snapshot: snapshot,
              scrollController: widget.controller,
              refershQuery: () {
                rateProv.refershHigherRate();
              },
              handelDataView: _handleDataView,
            );
          },
        );
      },
    );

    // ListView.separated(
    //   primary: false,
    //   shrinkWrap: true,
    //   itemCount: 20,
    //   separatorBuilder: (BuildContext context, int index) {
    //     return const Divider();
    //   },
    //   itemBuilder: (BuildContext context, int index) {
    //     return DriverRateItem(
    //       index: index + 1,
    //       driver: DriverRatingModel.testRate,
    //     );
    //   },
    // );
  }
}
