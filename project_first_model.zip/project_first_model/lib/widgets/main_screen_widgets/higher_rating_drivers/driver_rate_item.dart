import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/models/rating_model.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/offer_items_v2.dart';
import 'package:project_first_model/widgets/utiles/custom_modal_bottom_sheet.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class DriverRateItem extends StatelessWidget {
  const DriverRateItem({
    Key? key,
    required this.index,
    required this.driver,
  }) : super(key: key);
  final int index;
  final DriverRatingModel driver;

  Row buildRating(double starRatio, int peoCount) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          ' ( ${Utiles.getCountString(peoCount)} ) ',
          style: TextStyle(
            fontSize: 33.sp,
          ),
        ),
        const HorizantalSizedBox(12),
        ShowRating(
          ratingRatio: starRatio,
          itemSize: 40,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      margin: const EdgeInsets.only(
        // top: 12.0,
        left: 12.0, //45.0,
        right: 12.0,
        bottom: 6.0,
      ),
      // elevation: 4,
      child: SizedBox(
        height: 295.h,
        child: InkWell(
          onTap: () {
            final prov = Get.find<TripController>();
            CustomModalBottomSheet.buildTripDetailsModalSheet(
              context,
              fetchedID: driver.driverID,
              getTripData: prov.findByUserId,
            );
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              const HorizantalSizedBox(25),
              SizedBox(
                width: 85.w,
                height: 130.h,
                child: FittedBox(
                  child: Text(
                    '#$index',
                    style: TextStyle(
                      fontSize: 46.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Row(
                // mainAxisAlignment: MainAxisAlignment.spaceAround,
                mainAxisSize: MainAxisSize.max,
                children: [
                  const HorizantalSizedBox(25),
                  // const HorizantalSizedBox(30),
                  //driver pic
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (index < 4)
                        Icon(
                          FontAwesomeIcons.crown,
                          color: index == 1
                              ? Colors.amber
                              : index == 2
                                  ? const Color.fromARGB(255, 190, 190, 190)
                                  : const Color(0xffcd7f32),
                        ),
                      CircleSqureImage(
                        pic: driver.driverPic,
                        width: 210,
                        height: 210,
                        radius: 105,
                        id: driver.driverPic,
                      ),
                      if (index < 4) const VerticalSizedBox(10),
                    ],
                  ),
                  const HorizantalSizedBox(20),
                  //trip info
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const VerticalSizedBox(24),
                      //driverName
                      Text(
                        driver.driverName,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 48.sp,
                        ),
                      ),
                      //Loaction
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Icon(
                            Icons.location_pin,
                            size: 38.0.sp,
                          ),
                          const HorizantalSizedBox(7),
                          Text(
                            driver.region,
                            style: TextStyle(
                              fontSize: 40.0.sp,
                            ),
                          ),
                        ],
                      ),
                      //rating
                      buildRating(
                        driver.starsRatio,
                        driver.ratingPeopleCount,
                      ),

                      const VerticalSizedBox(7),
                    ],
                  ),
                ],
              ),
              const Expanded(
                child: HorizantalSizedBox(double.infinity),
              ),
              const HorizantalSizedBox(10),
              InkWell(
                child: Tooltip(
                  message: 'عدد الرحلات',
                  child: SizedBox(
                    width: 60.w,
                    height: 90.h,
                    child: FittedBox(
                      child: Text(
                        Utiles.getCountString(driver.tripsCount),
                        style: TextStyle(
                          fontSize: 44.sp,
                          // fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const HorizantalSizedBox(25),
            ],
          ),
        ),
      ),
    );
  }
}
