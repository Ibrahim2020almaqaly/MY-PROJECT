import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/models/rating_model.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/offer_items.dart';
import 'package:project_first_model/widgets/utiles/custom_modal_bottom_sheet.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

///This Widget Is just For Main Screen
///And when We tab the button It Will show Another Screen
///With Another widgets
class HigherRateDrivers extends StatelessWidget {
  const HigherRateDrivers({
    Key? key,
    required this.driverRate,
  }) : super(key: key);
  final DriverRatingModel driverRate;

  Row buildRating(double starRatio, int peoCount) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          ' ( ${Utiles.getCountString(peoCount)} ) ',
          style: TextStyle(
            fontSize: 33.sp,
          ),
        ),
        const HorizantalSizedBox(12),
        ShowRating(
          ratingRatio: starRatio,
          itemSize: 15,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 430.h,
      width: 450.w,
      child: Card(
        // color: Theme.of(context).scaffoldBackgroundColor,
        // elevation: 6,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0.r),
        ),
        margin: CustomEdgeInsets.all(10),
        child: InkWell(
          onTap: () {
            final prov = Get.find<TripController>();
            CustomModalBottomSheet.buildTripDetailsModalSheet(
              context,
              fetchedID: driverRate.driverID,
              getTripData: prov.findByUserId,
            );
          },
          child: Padding(
            padding: EdgeInsets.only(right: 5.0.w, top: 5.0.h, bottom: 5.0.h),
            child: Stack(
              fit: StackFit.expand,
              children: [
                //picture
                Align(
                  alignment: Alignment.topCenter,
                  child: SizedBox(
                    // width: 200.0.w,
                    height: 350.0.h,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        const VerticalSizedBox(20),
                        CircleSqureImage(
                          pic: driverRate.driverPic,
                          width: 210.0,
                          height: 210.0,
                          radius: 105.0,
                          isCircle: true,
                          id: driverRate.driverPic,
                          decoration: ShapeDecoration(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(12.0.r),
                                  topRight: Radius.circular(12.0.r)),
                            ),
                          ),
                        ),
                        const VerticalSizedBox(30),
                        SizedBox(
                          height: 60.h,
                          width: 445.w,
                          child: FittedBox(
                            fit: BoxFit.contain,
                            child: Padding(
                              padding: CustomEdgeInsets.horizontal(8.0),
                              child: Text(
                                driverRate.driverName,
                                style: const TextStyle(
                                  // fontSize: 30.0.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                                overflow: TextOverflow.fade,
                                maxLines: 2,
                                softWrap: false,
                              ),
                            ),
                          ),
                        ),
                        const VerticalSizedBox(20),
                      ],
                    ),
                  ),
                ),
                //rating
                Positioned(
                  bottom: 10,
                  right: 5,
                  child: SizedBox(
                    width: 235.w,
                    child: FittedBox(
                      child: buildRating(
                        driverRate.starsRatio,
                        driverRate.ratingPeopleCount,
                      ),
                    ),
                  ),
                ),
                //origin
                Positioned(
                  bottom: 6,
                  left: 10,
                  child: Row(
                    children: [
                      Icon(
                        Icons.location_on,
                        size: 40.sp,
                      ),
                      SizedBox(
                        height: 50.h,
                        width: 100.w,
                        child: FittedBox(
                          fit: BoxFit.contain,
                          child: Text(
                            driverRate.region,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
