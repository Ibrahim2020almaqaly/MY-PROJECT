import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class NoConnection extends StatelessWidget {
  const NoConnection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            ImageHelpers.getLottieAssetImage(
              800.0,
              800.0,
              Assets.lottieIcons.animationIcon02Nowifi,
            ),
            const VerticalSizedBox(10),
            const Text('لا يتوفر إتصال بالإنترنت!'),
            const VerticalSizedBox(10),
            CustomElevatedButton(
              onPressed: () {
                final conProv = Get.find<ConnectionController>();
                conProv.reset();
                conProv.listen();
              },
              title: 'إعادة المحاولة',
              allowRegisterOnly: false,
              allowOnlineOnly: false,
            ),
          ],
        ),
      ),
    );
  }
}
