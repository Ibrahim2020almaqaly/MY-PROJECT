import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/no_connection.dart';
import 'package:project_first_model/widgets/main_screen_widgets/main_screen_body.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_scaffold_scroll.dart';

@RoutePage()
class HandelConnection extends StatefulWidget {
  const HandelConnection({
    Key? key,
    this.showAppBar = true,
    this.mainWidget,
  }) : super(key: key);

  final Widget? mainWidget;
  final bool showAppBar;

  @override
  State<HandelConnection> createState() => _HandelConnectionState();
}

class _HandelConnectionState extends State<HandelConnection> {
  final controller = ScrollController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // final connProv = Provider.of<ConnectionProvider>(context, listen: false);
    return CustomScaffoldScroll(
      controller: controller,
      appBar: !widget.showAppBar
          ? null
          : AppBar(
              title: Text(
                appNAME,
                style: TextStyle(
                  fontSize: 44.sp,
                  // color: Theme.of(context).appBarTheme.actionsIconTheme?.color,
                ),
              ),
              // centerTitle: true,
              elevation: 0,
              actions: [
                CustomIconButton(
                  iconData: Icons.notifications_outlined,
                  tooltip: 'الإشعارات',
                  iconSize: 84.0,
                  allowRegisterOnly: false,
                  onPressed: () {
                    // Get.toNamed(Routes.notificationsScreen);
                    Get.find<AppRouter>().push(const NotificationsRoute());
                  },
                ),
              ],
            ),
      body: SafeArea(
        child: GetBuilder<ConnectionController>(
          builder: (conState) {
            final online = conState.isOnline;
            Future.delayed(Duration.zero, () {
              // ShowAnyMessages.showSimpleNotificationMessage(online);
            });
            if (online) {
              return widget.mainWidget ??
                  MainScreenBody(controller: controller);
            } else {
              //   // Provider.of<TripProvider>(context, listen: false).resetAll();
              return const NoConnection();
              // connProv.isOnline
              //     ? mainWidget ?? const MainScreenBody()
              //     : NoConnection(
              //         onPressed: () {
              //           connProv.reset();
              //           connProv.listen();
              //         },
              //       ),
            }
          },
        ),
      ),
    );
    // Scaffold(
    //   appBar: !widget.showAppBar
    //       ? null
    //       : AppBar(
    //           // title: const Text('قائمة الرحلات'),
    //           // centerTitle: true,
    //           elevation: 0,
    //           actions: [
    //             IconButton(
    //               onPressed: () {},
    //               icon: const Icon(Icons.notifications),
    //             ),
    //           ],
    //         ),
    //   body: SafeArea(
    //     child: Consumer<ConnectionProvider>(
    //       builder: (ctx, conState, _) {
    //         final online = conState.isOnline;
    //         Future.delayed(Duration.zero, () {
    //           // ShowAnyMessages.showSimpleNotificationMessage(online);
    //         });
    //         if (online) {
    //           return widget.mainWidget ?? const MainScreenBody();
    //         } else {
    //           //   // Provider.of<TripProvider>(context, listen: false).resetAll();
    //           return const NoConnection();
    //           // connProv.isOnline
    //           //     ? mainWidget ?? const MainScreenBody()
    //           //     : NoConnection(
    //           //         onPressed: () {
    //           //           connProv.reset();
    //           //           connProv.listen();
    //           //         },
    //           //       ),
    //         }
    //       },
    //     ),
    //   ),
    // );
  }
}
