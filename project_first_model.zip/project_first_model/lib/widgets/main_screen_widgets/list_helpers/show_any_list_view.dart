import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_ui_firestore/firebase_ui_firestore.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/services/app_settings.dart';
import 'package:project_first_model/widgets/custom_loadings/custom_loading.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/no_connection.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/no_more_data.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';

class ShowAnyListView extends StatefulWidget {
  const ShowAnyListView({
    Key? key,
    required this.snapshot,
    required this.scrollController,
    required this.refershQuery,
    required this.handelDataView,
    this.scrollDirection = Axis.vertical,
    this.noDataFoundTitle = 'لا توجد بيانات بعد!',
    this.noMoreDataTitle = 'لم يعد هناك بيانات أخرى!',
    this.showIcon = true,
  }) : super(key: key);
  final FirestoreQueryBuilderSnapshot<dynamic> snapshot;
  final ScrollController scrollController;
  final Axis scrollDirection;
  final void Function() refershQuery;
  final String noDataFoundTitle;
  final String noMoreDataTitle;
  final bool showIcon;
  final Widget Function(
    List<QueryDocumentSnapshot<dynamic>> docs,
    int index,
    BuildContext context,
  ) handelDataView;

  @override
  State<ShowAnyListView> createState() => _ShowAnyListViewState();
}

class _ShowAnyListViewState extends State<ShowAnyListView> {
  @override
  void initState() {
    super.initState();
    final saverOn =
        AppSettings.getSettingValue(AppSettings.isDataSaverOnKey, false);
    if (!saverOn) {
      widget.scrollController.addListener(_handelRequestMore);
    }
  }

  @override
  void dispose() {
    super.dispose();
    widget.scrollController.removeListener(_handelRequestMore);
  }

  void _handelFetchMore() {
    final isonline = Get.find<ConnectionController>().isOnline;
    final hasEndReached =
        widget.snapshot.hasMore && !widget.snapshot.isFetchingMore;
    if (hasEndReached && isonline) {
      widget.snapshot.fetchMore();
    }
  }

  void _handelRequestMore() {
    if (widget.scrollController.offset >=
            (widget.scrollController.position.maxScrollExtent / 2) &&
        !widget.scrollController.position.outOfRange) {
      _handelFetchMore();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.snapshot.docs.isEmpty) {
      return Center(
        child: NoMoreData(
          title: widget.noDataFoundTitle,
          showIcon: widget.showIcon,
          onPressed: () {
            setState(() {
              widget.refershQuery;
            });
          },
        ),
      );
    }
    return ListView.separated(
      physics: const ClampingScrollPhysics(),
      shrinkWrap: true,
      primary: false,
      scrollDirection: widget.scrollDirection,
      separatorBuilder: (ct, index) {
        // if (index % 5 == 0) {
        //   return Column(
        //     children: [
        //       AdsHelper(
        //         bannerUnitID: GoogleMobAds.getInlineTripUnitID(),
        //       ),
        //       const Divider(),
        //     ],
        //   );
        // }
        return const Divider();
      },
      itemCount: widget.snapshot.docs.length + 1,
      padding: CustomEdgeInsets.only(bottom: 5.0, top: 5.0),
      itemBuilder: (ctx, index) {
        final tripsDocs = widget.snapshot.docs;
        if (index < tripsDocs.length) {
          return widget.handelDataView(tripsDocs, index, context);
        } else if (widget.snapshot.hasMore) {
          final connProv = Get.find<ConnectionController>();
          final dataSaverOn =
              AppSettings.getSettingValue(AppSettings.isDataSaverOnKey, false);
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (connProv.isOnline)
                Padding(
                  padding: CustomEdgeInsets.all(32.0),
                  child: dataSaverOn
                      ? CustomElevatedButton(
                          title: 'تحميل المزيد',
                          allowRegisterOnly: false,
                          onPressed: _handelFetchMore,
                        )
                      : GestureDetector(
                          onTap: _handelFetchMore,
                          child: const CustomLoading(
                            showSemanticLabal: false,
                          ),
                        ),
                ),
              if (!connProv.isOnline) const NoConnection(),
            ],
          );
        } else {
          return NoMoreData(
            title: widget.noMoreDataTitle,
            showIcon: false,
            showBtn: false,
            onPressed: () {
              widget.refershQuery;
            },
          );
        }
      },
    );
    //);
  }
}
