import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lottie/lottie.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class SnapshotError extends StatelessWidget {
  const SnapshotError({
    Key? key,
    required this.onPressed,
    this.btnText = "إعادة المحاولة",
    this.showIcon = true,
    this.error,
  }) : super(key: key);
  final void Function() onPressed;
  final bool showIcon;
  final String btnText;
  final Object? error;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: CustomEdgeInsets.all(28.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (showIcon)
                LottieBuilder.asset(
                  Assets.lottieIcons.errorOccurred,
                  height: 800.0.h,
                  width: 800.0.w,
                ),
              const VerticalSizedBox(10),
              const Text('هناك خطأ حدث يرجى المحاولة مرة أخرى'),
              const VerticalSizedBox(10),
              CustomElevatedButton(
                allowRegisterOnly: false,
                onPressed: () {
                  Utiles.email(
                    Utiles.suppurtEmail,
                    subject: 'خطأ غير متوقع',
                    body: error.toString(),
                  );
                  // ShowAnyMessages.showDialogMessage(
                  //   context,
                  //   error.toString(),
                  //   'خطأ',
                  //   icon: Assets.lottieIcons.failedTask,
                  // );
                },
                title: 'أرسل الخطأ لفريق الدعم',
              ),
              const VerticalSizedBox(10),
              CustomElevatedButton(
                allowRegisterOnly: false,
                onPressed: onPressed,
                title: btnText,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
