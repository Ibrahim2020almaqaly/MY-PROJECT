import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lottie/lottie.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

class NoMoreData extends StatelessWidget {
  const NoMoreData({
    Key? key,
    required this.onPressed,
    required this.title,
    required this.showIcon,
    this.btnTitle = 'تحديث',
    this.showBtn = true,
  }) : super(key: key);
  final void Function() onPressed;
  final String title;
  final bool showIcon;
  final String btnTitle;
  final bool showBtn;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: CustomEdgeInsets.all(32.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            children: [
              if (showIcon)
                LottieBuilder.asset(
                  Assets.lottieIcons.noDataFound,
                  height: 800.0.h,
                  width: 800.0.w,
                ),
              const VerticalSizedBox(20),
              Text(title),
              const VerticalSizedBox(10),
              if (showBtn)
                CustomElevatedButton(
                  onPressed: onPressed,
                  allowRegisterOnly: false,
                  title: btnTitle,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
