import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_ink_well.dart';

class SectionHeader extends StatelessWidget {
  const SectionHeader({
    Key? key,
    required this.title,
    required this.onTap,
    this.showArrowIcon = true,
  }) : super(key: key);
  final String title;
  final void Function() onTap;
  final bool showArrowIcon;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 24.0.w),
      child: CustomInkWell(
        allowRegisterOnly: false,
        onTap: showArrowIcon ? onTap : null,
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 65.0.sp,
                color: Theme.of(context).iconTheme.color,
              ),
            ),
            if (showArrowIcon)
              Padding(
                padding: CustomEdgeInsets.all(16.0),
                child: const Icon(Icons.arrow_back_ios_new_outlined),
              ),
          ],
        ),
      ),
    );
  }
}
