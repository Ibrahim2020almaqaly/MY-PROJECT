import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';

class AccountSettingsItems extends StatelessWidget {
  const AccountSettingsItems({
    Key? key,
    required this.iconData,
    required this.title,
    this.subtitle,
    this.onTab,
    this.allowOnlineOnly = true,
    this.allowRegisterOnly = true,
    this.trailing = const Icon(Icons.arrow_forward_ios_outlined),
  }) : super(key: key);
  final IconData iconData;
  final String title;
  final String? subtitle;
  final void Function()? onTab;
  final bool allowOnlineOnly;
  final bool allowRegisterOnly;
  final Widget trailing;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GetBuilder<ConnectionController>(
      builder: (connProv) {
        return ListTile(
          key: key,
          leading: Icon(
            iconData,
            // color: theme.iconTheme.color,
          ),
          title: Text(
            title,
          ),
          subtitle: subtitle == null
              ? null
              : Text(
                  subtitle!,
                  style: TextStyle(
                    fontSize: 28.sp,
                  ),
                ),
          onTap: onTab == null
              ? null
              : () async {
                  if (allowOnlineOnly) {
                    if (!connProv.isOnline) {
                      ShowAnyMessages.noConnMsg(context);
                      return;
                    }
                  }
                  if (allowRegisterOnly) {
                    final user =
                        Get.find<FirebaseAuthController>().getCurrentUser !=
                            null;
                    if (!user) {
                      ShowCustomDialog.notLoggedInUserWithNavigation(context);
                      return;
                    }
                  }
                  onTab!();
                },
          iconColor: theme.iconTheme.color,
          trailing: trailing,
        );
      },
    );
  }
}
