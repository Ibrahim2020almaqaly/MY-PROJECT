import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/models/regions_model.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_image_viewer.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_field.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

class MiniProfile extends StatefulWidget {
  final void Function(int index, File? image) imageHandeler;
  final void Function(String? value) onUsernameSaved;
  // final void Function(String? value) onRegionSaved;
  final File? image;
  final TextEditingController driverNameController;
  final TextEditingController regionNameController;

  const MiniProfile({
    Key? key,
    required this.imageHandeler,
    required this.driverNameController,
    required this.regionNameController,
    required this.onUsernameSaved,
    // required this.onRegionSaved,
    this.image,
  }) : super(key: key);

  @override
  MiniProfileState createState() => MiniProfileState();
}

class MiniProfileState extends State<MiniProfile> {
  @override
  Widget build(BuildContext context) {
    final id = Get.find<UserController>().getUserData.userPic;
    return Column(
      children: [
        SizedBox(
          width: 370.w,
          height: 370.h,
          child: Hero(
            tag: 'UserPic',
            transitionOnUserGestures: true,
            child: CustomImageViewer(
              index: 0,
              imageHandeler: widget.imageHandeler,
              height: 370,
              width: 370,
              enableRadius: true,
              image: widget.image,
              id: id,
            ),
          ),
        ),
        const VerticalSizedBox(35),
        CustomTextFormField(
          label: 'الإسم',
          controller: widget.driverNameController,
          textInputAction: TextInputAction.next,
          textInputType: TextInputType.text,
          maxLength: 30,
          validator: Validators.validateNameField,
          onSaved: widget.onUsernameSaved,
        ),
        const VerticalSizedBox(35),
        CustomTextField(
          title: 'المحافظة',
          textController: widget.regionNameController,
          suggestionCallback: RegionModel.regionsSuggestions,
          isTheLast: true,
          typeName: 'المحافظة',
          fieldList: RegionModel.regionsList,
        ),
      ],
    );
  }
}
