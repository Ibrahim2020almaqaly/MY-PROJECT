import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/theme_controller.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';

class AppIconTheme extends StatelessWidget {
  const AppIconTheme({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(
      builder: (themeProv) {
        return CustomIconButton(
          iconData: Icons.light_mode_outlined,
          tooltip: 'الوضع العادي',
          iconSize: 80,
          onPressed: () {
            // var mode = themeProv.themeMode.index;
            // final isDark = themeProv.isDarkMode;
            // if (mode == 0 && isDark) {
            //   mode = 1;
            // } else if (mode == 0 && !isDark) {
            //   mode = 2;
            // } else {
            //   mode = isDark ? 1 : 2;
            // }
            // AppSettings.setSettingValue<int>(AppSettings.themeKey, mode);
            // themeProv.toggleTheme(mode);
          },
          allowOnlineOnly: false,
          allowRegisterOnly: false,
        );
      },
    );
  }
}
