import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/models/rating_model.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';

// class RateDialog {
//   static Future<void> rateDriver({
//     required BuildContext context,
//     required String driverID,
//     required String tripID,
//     required String userID,
//   }) async {
//     await showDialog(
//       context: context,
//       useSafeArea: true,
//       // barrierDismissible: false,
//       barrierLabel: 'تقييم',
//       builder: (ctx) {
//         return Dialog(
//           child: GestureDetector(
//             onTap: () {
//               FocusManager.instance.primaryFocus?.unfocus();
//             },
//             child: RateDriver(
//               userID: userID,
//               driverID: driverID,
//               tripID: tripID,
//               scrollController: ScrollController(),
//             ),
//           ),
//         );
//       },
//     );
//   }
// }

class RateDriver extends StatefulWidget {
  const RateDriver({
    Key? key,
    required this.userID,
    required this.driverID,
    required this.driverName,
    required this.driverPic,
    required this.tripID,
    required this.scrollController,
  }) : super(key: key);
  final String userID;
  final String driverID;
  final String driverName;
  final String driverPic;
  final String tripID;
  final ScrollController scrollController;

  @override
  State<RateDriver> createState() => _RateDriverState();
}

class _RateDriverState extends State<RateDriver> {
  var rate = 0.0;
  CustomerRatingModel custRate = CustomerRatingModel.defaultCustomerRate;

  var _enableBtn = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () async {
      await _getData();
    });
  }

  Future<void> _getData() async {
    CustomOverlayLoading.showOverlayLoading();
    try {
      var custRateTemp = await Get.find<RatingController>()
          .getCustomerRating(widget.driverID, widget.tripID, widget.userID);
      if (custRateTemp.isDefault) {
        // if (!mounted) return;
        CustomOverlayLoading.hideOverlayLoading();
        return;
      }
      setState(() {
        custRate = custRateTemp;
      });
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        isError: true,
        floating: false,
      );
      // Navigator.of(context).pop();
      Get.find<AppRouter>().pop();
    } on Exception catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(
        context,
        e.toString(),
        isError: true,
        floating: false,
      );
      // Navigator.of(context).pop();
      Get.find<AppRouter>().pop();
    }
    // if (!mounted) return;
    CustomOverlayLoading.hideOverlayLoading();
  }

  Future<void> _save() async {
    if (widget.userID == '') {
      throw CustomException('حدث خطأ يرجى المحاولة لاحقاً');
    }

    CustomOverlayLoading.showOverlayLoading();
    try {
      final prov = Get.find<RatingController>();
      if (custRate.isDefault) {
        custRate = custRate.copyWith(
          customerID: widget.userID,
          starNumber: rate.toInt(),
        );

        await prov.addCustomerRate(
          widget.driverID,
          widget.tripID,
          custRate,
        );
      } else {
        final old = custRate.starNumber;
        await prov.updateCustomerRate(
          widget.driverID,
          widget.tripID,
          custRate.copyWith(starNumber: rate.toInt()),
          old,
        );
      }
      CustomOverlayLoading.hideOverlayLoading();
      if (!mounted) return;
      ShowAnyMessages.showSnackBar(
        context,
        'تم التقييم بنجاح! ',
        isSuccess: true,
      );
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        isError: true,
        floating: false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(25),
        ),
      ),
      padding: CustomEdgeInsets.only(
        top: 55.0,
        right: 32.0,
        left: 32.0,
      ),
      child: ListView(
        controller: widget.scrollController,
        // mainAxisAlignment: MainAxisAlignment.center,
        // mainAxisSize: MainAxisSize.min,
        padding: CustomEdgeInsets.only(right: 16.0),
        children: [
          Card(
            child: Padding(
              padding: CustomEdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomTextButton(
                    onPressed: !_enableBtn
                        ? null
                        : () async {
                            await _save();
                            // if (!mounted) return;
                            Get.find<AppRouter>().pop();
                            // Navigator.of(context).pop();
                          },
                    title: 'إرسال',
                    textStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 46.sp,
                    ),
                  ),
                  const Expanded(child: HorizantalSizedBox(20)),
                  SizedBox(
                    width: 400.w,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.driverName,
                          maxLines: 1,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 46.sp,
                          ),
                        ),
                        const VerticalSizedBox(12),
                        Text(
                          'قيم هذا السائق',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 40.sp,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const HorizantalSizedBox(5),
                  CircleSqureImage(
                    pic: widget.driverPic,
                    width: 500,
                    height: 500,
                    radius: 250.r,
                    id: widget.driverPic,
                  ),
                  const HorizantalSizedBox(20),
                  CustomIconButton(
                    iconData: Icons.close_outlined,
                    allowOnlineOnly: false,
                    allowRegisterOnly: false,
                    tooltip: 'إغلاق',
                    iconSize: 84,
                    onPressed: () {
                      // Navigator.of(context).pop();
                      Get.find<AppRouter>().pop();
                    },
                  ),
                ],
              ),
            ),
          ),
          const VerticalSizedBox(15),
          ListView(
            shrinkWrap: true,
            primary: false,
            padding: CustomEdgeInsets.all(16.0),
            children: [
              GetBuilder<UserController>(
                builder: (userProv) {
                  final user = userProv.getUserData;
                  return Row(
                    children: [
                      CircleSqureImage(
                        pic: user.userPic,
                        width: 500,
                        height: 500,
                        radius: 250.r,
                        id: user.userPic,
                      ),
                      const HorizantalSizedBox(20),
                      Text(
                        user.userName,
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 46.sp,
                        ),
                      ),
                    ],
                  );
                },
              ),
              const VerticalSizedBox(30),
              Text(
                'قم بإعطاء السائق تقييماَ',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 46.sp,
                ),
              ),
              const VerticalSizedBox(30),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const HorizantalSizedBox(20),
                  RatingBar(
                    onRatingUpdate: (val) {
                      rate = val;
                      if (rate.toInt() != custRate.starNumber) {
                        setState(() {
                          _enableBtn = true;
                        });
                      }
                    },
                    ratingWidget: RatingWidget(
                      empty: const Icon(
                        Icons.star_border,
                        color: Colors.grey,
                      ),
                      half: const Icon(
                        Icons.star,
                        color: Colors.amberAccent,
                      ),
                      full: const Icon(
                        Icons.star,
                        color: Colors.amber,
                      ),
                    ),
                    itemSize: 40,
                    itemCount: 5,
                    minRating: 1,
                    maxRating: 5,
                    initialRating: custRate.starNumber.toDouble(),
                    textDirection: TextDirection.ltr,
                    glowRadius: 1.5,
                    itemPadding: CustomEdgeInsets.only(left: 30, top: 20),
                    glowColor: Colors.amber.shade400,
                  ),
                ],
              ),
              const VerticalSizedBox(40),
            ],
          ),
        ],
      ),
    );
  }
}
