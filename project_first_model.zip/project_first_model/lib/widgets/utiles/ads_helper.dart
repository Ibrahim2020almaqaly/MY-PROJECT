// import 'package:flutter/material.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';
// import 'package:project_first_model/providers/banner_ad_provider.dart';

// class AdsHelper extends StatelessWidget {
//   const AdsHelper({
//     Key? key,
//     this.adSize = AdSize.mediumRectangle,
//     required this.bannerUnitID,
//     this.inlineAd = true,
//   }) : super(key: key);
//   final AdSize adSize;
//   final String bannerUnitID;
//   final bool inlineAd;

//   @override
//   Widget build(BuildContext context) {
//     return FutureBuilder<Widget>(
//       future: BannerAdProvider.buildBannerWidget(
//         context,
//         adSize,
//         bannerUnitID,
//         inlineAd,
//       ),
//       builder: (context, snapshot) {
//         if (!snapshot.hasData) return const SizedBox(height: 0);
//         return snapshot.data!;
//       },
//     );
//   }
// }
