import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/theme_controller.dart';

class CustomBackButton extends StatelessWidget {
  const CustomBackButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(
      builder: (themeProv) {
        return BackButton(
          color: themeProv.isDarkMode ? Colors.white : Colors.black,
        );
      },
    );
  }
}
