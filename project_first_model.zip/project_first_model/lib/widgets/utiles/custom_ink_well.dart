import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';

class CustomInkWell extends StatelessWidget {
  const CustomInkWell({
    Key? key,
    required this.onTap,
    required this.child,
    this.allowOnlineOnly = true,
    this.allowRegisterOnly = true,
  }) : super(key: key);
  final void Function()? onTap;
  final Widget child;
  final bool allowRegisterOnly;
  final bool allowOnlineOnly;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap == null
          ? null
          : () {
              if (allowOnlineOnly) {
                final online = Get.find<ConnectionController>().isOnline;
                if (!online) {
                  ShowAnyMessages.noConnMsg(context);
                  return;
                }
              }

              if (allowRegisterOnly) {
                final logged =
                    Get.find<FirebaseAuthController>().isThereAUserLoggedin;
                if (!logged) {
                  ShowCustomDialog.notLoggedInUserWithNavigation(context);
                  return;
                }
              }
              if (onTap != null) {
                onTap!();
              }
            },
      child: child,
    );
  }
}
