import 'dart:async';

import 'package:ensure_visible_when_focused/ensure_visible_when_focused.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/trip_controllers/secondary_city_controller.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';

import '../custom_loadings/custom_loading.dart';

class CustomTextField extends StatefulWidget {
  const CustomTextField({
    Key? key,
    required this.title,
    this.saveHandeler,
    this.autoValidate = false,
    this.allowNullValue = false,
    required this.textController,
    this.otherControlersValues,
    this.type,
    this.isTheLast = false,
    this.typeName = 'المدينة',
    required this.suggestionCallback,
    required this.fieldList,
    this.changeParentUi,
  }) : super(key: key);

  final String title;
  final String typeName;
  final void Function(dynamic value, DestType isFrom)? saveHandeler;
  final bool autoValidate;
  final bool allowNullValue;
  final TextEditingController textController;
  final List<TextEditingController>? otherControlersValues;
  final DestType? type;
  final bool isTheLast;
  final FutureOr<Iterable<dynamic>> Function(String val) suggestionCallback;
  final List<String> fieldList;
  final void Function(int index)? changeParentUi;

  @override
  CustomTextFieldState createState() => CustomTextFieldState();
}

class CustomTextFieldState extends State<CustomTextField> {
  final _focusNode = FocusNode();
  var showSuggestionsDown = true;
  var isError = false;

  void changeErrorTheme(bool error) {
    if (error != isError) {
      Future.delayed(
        Duration.zero,
        (() {
          setState(() {
            isError = error;
          });
        }),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(moveCursorAtTheEnd);
  }

  void moveCursorAtTheEnd() {
    widget.textController.selection =
        TextSelection.collapsed(offset: widget.textController.text.length);
  }

  @override
  void dispose() {
    super.dispose();
    _focusNode.removeListener(moveCursorAtTheEnd);
    _focusNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    return EnsureVisibleWhenFocused(
      focusNode: _focusNode,
      child: TypeAheadFormField<dynamic>(
        noItemsFoundBuilder: (context) {
          return SizedBox(
            height: 250.h,
            child: Center(
              child: Text('${widget.typeName} المكتوب غير موجود'),
            ),
          );
        },
        debounceDuration: const Duration(milliseconds: 500),
        textFieldConfiguration: TextFieldConfiguration(
          focusNode: _focusNode,
          controller: widget.textController,
          onSubmitted: (_) {
            if (widget.isTheLast) {
              FocusManager.instance.primaryFocus?.unfocus();
            } else {
              FocusScope.of(context).nextFocus();
            }
          },
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Colors.black12),
              borderRadius: BorderRadius.circular(10),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: themeColor.colorScheme.error,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: themeColor.focusColor,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            errorBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: themeColor.colorScheme.error,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            border: const OutlineInputBorder(),
            hintText: 'أُكتب إسم ${widget.typeName}',
            label: Text(
              widget.title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: isError
                    ? themeColor.colorScheme.error
                    : themeColor.iconTheme.color,
              ),
            ),
            suffixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // CustomIconButton(
                //   iconData: showSuggestionsDown
                //       ? Icons.arrow_upward_outlined
                //       : Icons.arrow_downward_outlined,
                //   allowOnlineOnly: false,
                //   allowRegisterOnly: false,
                //   makeTheme: true,
                //   tooltip:
                //       'إظهار في ${showSuggestionsDown ? 'الأعلى' : 'الأسفل'}',
                //   iconSize: 70.0,
                //   onPressed: () {
                //     setState(() {
                //       showSuggestionsDown = !showSuggestionsDown;
                //     });
                //   },
                // ),

                CustomIconButton(
                  iconData: Icons.clear_outlined,
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                  makeTheme: true,
                  isError: isError,
                  tooltip: 'مسح',
                  iconSize: 70.0,
                  onPressed: () {
                    widget.textController.text = '';
                  },
                ),
              ],
            ),
          ),
          textInputAction:
              widget.isTheLast ? TextInputAction.done : TextInputAction.next,
        ),
        suggestionsCallback: widget.suggestionCallback,
        // widget.isCar ? getCarSuggestions : getCitySuggestions,
        itemBuilder: (_, suggestion) {
          final sugg = suggestion!;

          return ListTile(
            title: Text(sugg.name),
          );
        },
        onSuggestionSelected: (dynamic suggestion) {
          final name = suggestion!.name;
          widget.textController.text = name;
          if (widget.changeParentUi != null) {
            final index =
                widget.fieldList.indexWhere((element) => element == name);
            widget.changeParentUi!(index);
          }
        },
        loadingBuilder: (ctx) {
          return SizedBox(
            height: 250.h,
            child: const CustomLoading(),
          );
        },
        autovalidateMode: widget.autoValidate
            ? AutovalidateMode.onUserInteraction
            : AutovalidateMode.disabled,
        validator: (value) {
          final error = Validators.validateListsField(
            value,
            widget.otherControlersValues,
            widget.typeName,
            widget.allowNullValue,
            widget.fieldList,
          );
          changeErrorTheme(error != null);

          return error;
        },
        onSaved: (value) {
          dynamic val = value;
          if (widget.type == DestType.secondary) {
            val = Get.find<SecondaryCityController>().cities;
          }
          if (widget.saveHandeler != null) {
            widget.saveHandeler!(val, widget.type!);
          }
        },
        direction: showSuggestionsDown ? AxisDirection.down : AxisDirection.up,
      ),
    );
  }
}
