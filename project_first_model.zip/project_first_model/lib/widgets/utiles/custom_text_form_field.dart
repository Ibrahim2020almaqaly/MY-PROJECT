import 'package:ensure_visible_when_focused/ensure_visible_when_focused.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';

class CustomTextFormField extends StatefulWidget {
  final TextEditingController controller;
  final int? maxLength;
  final String label;
  final void Function(String?)? onSaved;
  final String? Function(String?)? validator;
  final TextInputAction textInputAction;
  final TextInputType textInputType;
  final int? minLines;
  final int? maxLines;
  final TextDirection? textDirection;
  final TextAlign textAlign;
  // final IconData icon;
  final bool readOnly;
  final bool imprtantBorder;
  final bool autoFocus;
  final TextAlignVertical? textAlignVertical;
  final Widget? suffix;
  final AutovalidateMode autovalidateMode;
  final bool showIconButton;
  final IconData? icon;
  final void Function()? onIconPressed;
  final void Function()? onTap;
  final bool canDeleteText;
  final String? iconToolTip;
  final bool showClearIcon;
  const CustomTextFormField({
    Key? key,
    required this.label,
    required this.controller,
    this.maxLength,
    required this.textInputAction,
    required this.textInputType,
    this.maxLines,
    this.minLines,
    this.readOnly = false,
    this.imprtantBorder = false,
    this.autoFocus = false,
    this.textAlign = TextAlign.start,
    this.textAlignVertical,
    this.textDirection,
    this.suffix,
    this.autovalidateMode = AutovalidateMode.onUserInteraction,
    required this.validator,
    required this.onSaved,
    this.showIconButton = false,
    this.icon,
    this.onIconPressed,
    this.onTap,
    this.canDeleteText = true,
    this.iconToolTip,
    this.showClearIcon = true,
  }) : super(key: key);

  @override
  State<CustomTextFormField> createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  final _focusNode = FocusNode();
  var isError = false;

  void changeErrorTheme(bool error) {
    if (error != isError) {
      Future.delayed(
        Duration.zero,
        (() {
          setState(() {
            isError = error;
          });
        }),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(moveCursorAtTheEnd);
  }

  void moveCursorAtTheEnd() {
    widget.controller.selection =
        TextSelection.collapsed(offset: widget.controller.text.length);
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  void dispose() {
    super.dispose();
    _focusNode.removeListener(moveCursorAtTheEnd);
    _focusNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    return EnsureVisibleWhenFocused(
      focusNode: _focusNode,
      child: TextFormField(
        onTap: widget.onTap,
        focusNode: _focusNode,
        minLines: widget.minLines,
        maxLines: widget.maxLines,
        maxLength: widget.maxLength,
        keyboardType: widget.textInputType,
        textInputAction: widget.textInputAction,
        readOnly: widget.readOnly,
        textDirection: widget.textDirection,
        textAlign: widget.textAlign,
        textAlignVertical: widget.textAlignVertical,
        controller: widget.controller,
        autofocus: widget.autoFocus,
        autovalidateMode: widget.autovalidateMode,
        decoration: InputDecoration(
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: widget.imprtantBorder ? 2.0 : 1.0,
              color: Colors.black12,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: widget.imprtantBorder ? 2.0 : 1.0,
              color: themeColor.colorScheme.error, //Colors.black12,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: widget.imprtantBorder ? 2.0 : 1.0,
              color: themeColor.focusColor, //Colors.black12,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          errorBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: widget.imprtantBorder ? 2.0 : 1.0,
              color: themeColor.colorScheme.error, //Colors.black12,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          border: const OutlineInputBorder(),
          label: widget.label == '' || widget.label.isEmpty
              ? null
              : Text(
                  widget.label,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: widget.suffix != null ? 44.0.sp : 38.0.sp,
                    fontWeight: widget.suffix != null ? FontWeight.bold : null,
                    color: isError
                        ? themeColor.colorScheme.error
                        : themeColor.iconTheme.color,
                  ),
                ),
          suffix: widget.suffix,
          suffixIcon: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.showIconButton)
                CustomIconButton(
                  iconData: widget.icon,
                  tooltip: widget.iconToolTip,
                  iconSize: 70.0,
                  onPressed: widget.onIconPressed,
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                  makeTheme: true,
                  isError: isError,
                ),
              if (widget.showClearIcon)
                CustomIconButton(
                  iconData: Icons.clear_outlined,
                  tooltip: 'مسح',
                  iconSize: 70.0,
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                  makeTheme: true,
                  isError: isError,
                  onPressed: () {
                    if (widget.canDeleteText) {
                      widget.controller.text = '';
                    }
                  },
                ),
            ],
          ),
        ),
        style: TextStyle(
          color: themeColor.colorScheme.onSurface,
          fontSize: widget.imprtantBorder
              ? 54.0.sp
              : widget.suffix != null
                  ? 54.0.sp
                  : 36.0.sp,
          fontWeight: widget.imprtantBorder ? FontWeight.bold : null,
        ),
        onFieldSubmitted: (_) {
          FocusScope.of(context).nextFocus();
        },
        onChanged: (value) {
          if (widget.maxLength != null && value.length == widget.maxLength) {
            FocusScope.of(context).unfocus();
          }
        },
        validator: (value) {
          if (widget.validator != null) {
            final error = widget.validator!(value);
            changeErrorTheme(error != null);
            return error;
          }
          return null;
        },
        onSaved: widget.onSaved,
      ),
    );
  }
}
