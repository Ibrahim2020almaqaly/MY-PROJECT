import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';

class CustomTextButton extends StatelessWidget {
  const CustomTextButton({
    Key? key,
    required this.title,
    required this.onPressed,
    this.allowOnlineOnly = true,
    this.allowRegisterOnly = true,
    this.style,
    this.textStyle,
  }) : super(key: key);
  final String title;
  final void Function()? onPressed;
  final bool allowRegisterOnly;
  final bool allowOnlineOnly;
  final ButtonStyle? style;
  final TextStyle? textStyle;
  // final bool whiteColor;

  @override
  Widget build(BuildContext context) {
    return TextButton(
      style: null,
      onPressed: onPressed == null
          ? null
          : () async {
              if (allowOnlineOnly) {
                final online = Get.find<ConnectionController>().isOnline;
                if (!online) {
                  await ShowAnyMessages.noConnMsg(context);
                  return;
                }
              }
              if (allowRegisterOnly) {
                final logged =
                    Get.find<FirebaseAuthController>().isThereAUserLoggedin;
                if (!logged) {
                  await ShowCustomDialog.notLoggedInUserWithNavigation(context);
                  return;
                }
              }
              onPressed!();
            },
      child: Text(
        title,
        style: textStyle,
      ),
    );
  }
}

class CustomTextIconButton extends StatelessWidget {
  const CustomTextIconButton({
    Key? key,
    required this.iconData,
    required this.title,
    required this.onPressed,
    this.allowOnlineOnly = true,
    this.allowRegisterOnly = true,
  }) : super(key: key);
  final IconData iconData;
  final String title;
  final void Function()? onPressed;
  final bool allowRegisterOnly;
  final bool allowOnlineOnly;

  @override
  Widget build(BuildContext context) {
    return TextButton.icon(
      icon: Icon(iconData),
      label: Text(title),
      onPressed: onPressed == null
          ? null
          : () async {
              if (allowOnlineOnly) {
                final online = Get.find<ConnectionController>().isOnline;
                if (!online) {
                  await ShowAnyMessages.noConnMsg(context);
                  return;
                }
              }
              if (allowRegisterOnly) {
                final logged =
                    Get.find<FirebaseAuthController>().isThereAUserLoggedin;
                if (!logged) {
                  await ShowCustomDialog.notLoggedInUserWithNavigation(context);
                  return;
                }
              }
              onPressed!();
            },
    );
  }
}
