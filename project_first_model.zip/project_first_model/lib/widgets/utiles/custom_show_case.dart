// import 'package:flutter/material.dart';
// import 'package:showcaseview/showcaseview.dart';

// class CustomShowCase extends StatelessWidget {
//   const CustomShowCase({
//     Key? key,
//     required this.globalkey,
//     required this.child,
//     required this.description,
//   }) : super(key: key);
//   final GlobalKey globalkey;
//   final Widget child;
//   final String description;

//   @override
//   Widget build(BuildContext context) {
//     return Showcase(
//       key: globalkey,
//       description: description,
//       child: child,
//     );
//   }
// }
