import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';

class CustomElevatedButton extends StatelessWidget {
  const CustomElevatedButton({
    Key? key,
    required this.title,
    required this.onPressed,
    this.style,
    this.allowOnlineOnly = true,
    this.allowRegisterOnly = true,
    this.padding = 0.0,
    this.textStyle,
  }) : super(key: key);
  final String title;
  final void Function()? onPressed;
  final bool allowRegisterOnly;
  final bool allowOnlineOnly;
  final ButtonStyle? style;
  final double padding;
  final TextStyle? textStyle;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed == null
          ? null
          : () async {
              if (allowOnlineOnly) {
                final online = Get.find<ConnectionController>().isOnline;
                if (!online) {
                  await ShowAnyMessages.noConnMsg(context);
                  return;
                }
              }
              if (allowRegisterOnly) {
                final logged =
                    Get.find<FirebaseAuthController>().isThereAUserLoggedin;
                if (!logged) {
                  await ShowCustomDialog.notLoggedInUserWithNavigation(context);
                  return;
                }
              }
              onPressed!();
            },
      style: style,
      child: Padding(
        padding: CustomEdgeInsets.all(padding),
        child: Text(
          title,
          style: textStyle,
        ),
      ),
    );
  }
}

class CustomElevatedIconButton extends StatelessWidget {
  const CustomElevatedIconButton({
    Key? key,
    required this.iconData,
    required this.title,
    required this.onPressed,
    this.allowOnlineOnly = true,
    this.allowRegisterOnly = true,
    this.padding = 0.0,
    this.style,
  }) : super(key: key);
  final IconData iconData;
  final String title;
  final void Function()? onPressed;
  final bool allowRegisterOnly;
  final bool allowOnlineOnly;
  final double padding;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      label: Padding(
        padding: CustomEdgeInsets.all(padding),
        child: Text(
          title,
          style: style,
        ),
      ),
      icon: Icon(
        iconData,
        textDirection: TextDirection.ltr,
      ),
      onPressed: onPressed == null
          ? null
          : () async {
              if (allowOnlineOnly) {
                final online = Get.find<ConnectionController>().isOnline;
                if (!online) {
                  await ShowAnyMessages.noConnMsg(context);
                  return;
                }
              }
              if (allowRegisterOnly) {
                final logged =
                    Get.find<FirebaseAuthController>().isThereAUserLoggedin;
                if (!logged) {
                  await ShowCustomDialog.notLoggedInUserWithNavigation(context);
                  return;
                }
              }
              onPressed!();
            },
    );
  }
}
