import 'package:flutter/material.dart';

class CustomDropDownBtn extends StatefulWidget {
  const CustomDropDownBtn({
    Key? key,
    required this.items,
    required this.onChange,
    this.checkLast = true,
  }) : super(key: key);
  final List<dynamic> items;
  final void Function(String?) onChange;
  final bool checkLast;

  @override
  State<CustomDropDownBtn> createState() => _CustomDropDownBtnState();
}

class _CustomDropDownBtnState extends State<CustomDropDownBtn> {
  late String initVal;
  @override
  void initState() {
    initVal = '${widget.items.last}';

    super.initState();
  }

  List<DropdownMenuItem<String>>? _buildItems() {
    return widget.items.map(
      (item) {
        return DropdownMenuItem<String>(
          value: '$item',
          child: Text('$item'),
        );
      },
    ).toList();
  }

  @override
  Widget build(BuildContext context) {
    // final themeColor = Theme.of(context);
    return DropdownButton<String>(
      items: [...?_buildItems()],
      underline: null,
      // decoration: InputDecoration(
      //     enabledBorder: OutlineInputBorder(
      //       borderSide: const BorderSide(color: Colors.black12),
      //       borderRadius: BorderRadius.circular(10),
      //     ),
      //     focusedErrorBorder: OutlineInputBorder(
      //       borderSide: BorderSide(
      //         color: themeColor.errorColor,
      //       ),
      //       borderRadius: BorderRadius.circular(10),
      //     ),
      //     focusedBorder: OutlineInputBorder(
      //       borderSide: BorderSide(
      //         color: themeColor.focusColor,
      //       ),
      //       borderRadius: BorderRadius.circular(10),
      //     ),
      //     errorBorder: OutlineInputBorder(
      //       borderSide: BorderSide(
      //         color: themeColor.errorColor,
      //       ),
      //       borderRadius: BorderRadius.circular(10),
      //     ),
      //     border: const OutlineInputBorder(),
      //     ),

      onChanged: (value) {
        var val = value;

        if (widget.checkLast) {
          val = value != widget.items.last ? value : '';
        }

        widget.onChange(val);

        setState(() {
          initVal = value!;
        });
      },
      value: initVal,
    );
  }
}
