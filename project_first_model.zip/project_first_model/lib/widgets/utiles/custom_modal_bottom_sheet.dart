import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/driver_controllers/call_records_controller.dart';
import 'package:project_first_model/controllers/theme_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/trip_details.dart';
import 'package:project_first_model/widgets/rate_widget.dart';

class CustomModalBottomSheet {
  static Future<void> makeACall(
    String tripID,
    BuildContext context,
    String driverID,
  ) async {
    try {
      final authProv = Get.find<FirebaseAuthController>();
      final tripProv = Get.find<TripController>();

      final user = authProv.getCurrentUser;
      if (user == null) {
        await ShowCustomDialog.notLoggedInUserWithNavigation(context);
        return;
      }
      CustomOverlayLoading.showOverlayLoading();

      final valid = await authProv.validToken();
      if (!valid) return;

      final phoneNumber = await tripProv.getDriverPhoneNumber(driverID, tripID);
      if (phoneNumber == '') {
        throw CustomException('number-not-found');
      }
      await Get.find<CallRecordController>().callAndRegister(
        phoneNumber,
        user.uid,
        driverID,
      );
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        isError: true,
        floating: false,
      );
    } catch (e) {
      CustomOverlayLoading.hideOverlayLoading();

      ShowAnyMessages.showSnackBar(
        context,
        e.toString(),
        isError: true,
        floating: false,
      );
    } finally {
      CustomOverlayLoading.hideOverlayLoading();
    }
  }

  static Widget _makeDissmisable({
    required Widget child,
    required BuildContext context,
  }) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        // Navigator.of(context).pop();
        Get.find<AppRouter>().pop();
      },
      child: GestureDetector(
        onTap: () {},
        child: child,
      ),
    );
  }

  static Widget buildHandle() {
    return GetBuilder<ThemeController>(
      builder: (prov) {
        return Center(
          child: Container(
            width: 50,
            height: 5,
            decoration: BoxDecoration(
              color: prov.isDarkMode
                  ? const Color.fromARGB(255, 94, 94, 94)
                  : const Color.fromARGB(255, 226, 226, 226),
              borderRadius: BorderRadius.circular(99),
            ),
          ),
        );
      },
    );
  }

  static void _showCustomModalSheet(
    BuildContext context,
    Widget child, {
    bool isScrollControlled = true,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: isScrollControlled,
      elevation: 0.1,
      builder: (ctx) {
        return _makeDissmisable(
          context: context,
          child: child,
        );
      },
    );
  }

  static void buildCustomModalSheet(
    BuildContext context,
    Widget child, {
    // double minChildSize = 0.4,
    // double maxChildSize = 0.9,
    bool showTopIcon = true,
    bool isScrollControlled = true,
  }) {
    _showCustomModalSheet(
      context,
      isScrollControlled: isScrollControlled,
      child,
    );
  }

  static Widget buildStack(Widget child, {bool showTopIcon = true}) {
    return Stack(
      children: [
        child,
        if (showTopIcon)
          Positioned(
            top: 2,
            right: 20,
            left: 20,
            child: buildHandle(),
            // Icon(
            //   Icons.more_horiz_outlined,
            //   size: 110.0.sp,
            //   color: Colors.grey,
            // ),
          ),
      ],
    );
  }

  static void buildTripDetailsModalSheet(
    BuildContext context, {
    String fetchedID = '',
    Future<TripModel?> Function(String)? getTripData,
    TripModel? tripModel,
    bool showBtns = true,
    double minChildSize = 0.4,
    double maxChildSize = 0.9,
  }) {
    // final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    _showCustomModalSheet(
      context,
      DraggableScrollableSheet(
        initialChildSize: maxChildSize,
        minChildSize: minChildSize,
        maxChildSize: maxChildSize,
        // expand: true,
        builder: (modalCtx, scrollController) {
          // int counter = 1;
          return buildStack(
            TripDetails(
              showBelowBtns: showBtns,
              scrollController: scrollController,
              tripID: fetchedID,
              makeACall: (phoneNumber, driverID) {
                makeACall(tripModel?.tripId ?? '', context, driverID);
              },
              getTripData: getTripData,
              tripModel: tripModel,
            ),
          );
        },
      ),
    );
  }

  static void buildDriverRateModalSheet(
      // BuildContext context,
      {
    required String driverID,
    required String driverName,
    required String driverPic,
    required String tripID,
    required String userID,
  }) {
    final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    _showCustomModalSheet(
      context,
      DraggableScrollableSheet(
        initialChildSize: 0.5,
        minChildSize: 0.3,
        maxChildSize: 0.9,
        expand: true,
        builder: (modalCtx, scrollController) {
          // int counter = 1;
          return buildStack(
            RateDriver(
              userID: userID,
              driverID: driverID,
              driverName: driverName,
              driverPic: driverPic,
              tripID: tripID,
              scrollController: scrollController,
            ),
          );
        },
      ),
    );
  }
}
