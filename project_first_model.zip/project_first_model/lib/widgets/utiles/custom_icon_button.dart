// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';

class CustomIconButton extends StatelessWidget {
  const CustomIconButton({
    Key? key,
    required this.iconData,
    required this.tooltip,
    required this.iconSize,
    required this.onPressed,
    this.allowOnlineOnly = true,
    this.allowRegisterOnly = true,
    this.makeTheme = true,
    this.iconColor,
    this.isError = false,
  }) : super(key: key);
  final IconData? iconData;
  final Color? iconColor;
  final String? tooltip;
  final void Function()? onPressed;
  final bool allowRegisterOnly;
  final bool allowOnlineOnly;
  final double iconSize;
  final bool makeTheme;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    return IconButton(
      icon: Icon(
        iconData,
        size: iconSize.sp,
      ),
      tooltip: tooltip,
      color: isError
          ? themeColor.colorScheme.error
          : makeTheme
              ? themeColor.iconTheme.color
              : iconColor,
      onPressed: onPressed == null
          ? null
          : () async {
              if (allowOnlineOnly) {
                final online = Get.find<ConnectionController>().isOnline;
                if (!online) {
                  await ShowAnyMessages.noConnMsg(context);
                  return;
                }
              }
              if (allowRegisterOnly) {
                final logged =
                    Get.find<FirebaseAuthController>().isThereAUserLoggedin;
                if (!logged) {
                  await ShowCustomDialog.notLoggedInUserWithNavigation(context);
                  return;
                }
              }
              onPressed!();
            },
    );
  }
}
