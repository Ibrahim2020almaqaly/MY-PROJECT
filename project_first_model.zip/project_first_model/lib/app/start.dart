import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:project_first_model/bindings/main_binding.dart';
import 'package:project_first_model/controllers/theme_controller.dart';

import 'package:project_first_model/l10n/l10n.dart';
import 'package:project_first_model/router/router.dart';

class Start extends StatelessWidget {
  // final _auth = FirebaseAuth.instance;
  final AppRouter appRouter;

  const Start({
    super.key,
    required this.appRouter,
  });

  @override
  Widget build(BuildContext context) {
    MyThemes.textTheme = Theme.of(context).textTheme;
    return GlobalLoaderOverlay(
      child: GetMaterialApp.router(
        routerDelegate: appRouter.delegate(),
        routeInformationParser: appRouter.defaultRouteParser(),
        builder: (mCtx, child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
            child: child!,
          );
        },
        routeInformationProvider: appRouter.routeInfoProvider(),
        title: 'على الطريق',
        themeMode: Get.find<ThemeController>().themeMode,
        // getPages: Routes.pages,
        theme: MyThemes.lightTheme,
        initialBinding: MainBinding(),
        locale: const Locale('ar'),
        localizationsDelegates: const [
          // AppLocalizations.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
        ],
        supportedLocales: L10n.all,
        debugShowCheckedModeBanner: false,
        useInheritedMediaQuery: true,

        navigatorObservers: [
          GetObserver(),
          RouteObserver(),
        ],
      ),
    );
  }
}
