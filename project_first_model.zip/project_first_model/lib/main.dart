import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/app/start.dart';
import 'package:project_first_model/controllers/theme_controller.dart';
import 'package:project_first_model/firebase_options.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/services/app_info.dart';
import 'package:project_first_model/services/app_settings.dart';
import 'package:project_first_model/widgets/app_error.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // final res =
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // print(
  //     'name: ${res.name} enabled: ${res.isAutomaticDataCollectionEnabled} client: ${res.options.androidClientId} project: ${res.options.projectId} appId: ${res.options.appId} key: ${res.options.apiKey} dburl: ${res.options.databaseURL} storage: ${res.options.reactive}');

  await FirebaseAppCheck.instance.activate(
    webRecaptchaSiteKey: 'recaptcha-v3-site-key',
    androidProvider: AndroidProvider.debug,
  );
  FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;

  PlatformDispatcher.instance.onError = (exception, stackTrace) {
    FirebaseCrashlytics.instance.recordError(
      exception,
      stackTrace,
      fatal: true,
    );
    return true;
  };

  ErrorWidget.builder = (details) {
    return AppError(details: details);
  };
  await AppSettings.initializeSettings();
  // await GoogleMobAds.adsInitialize();
  await AppInfo.getPackageInfo();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  final appRouter = AppRouter();

  Get.put(appRouter);
  Get.lazyPut(() => ThemeController(), fenix: true);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({
    Key? key,
  }) : super(key: key);

  // final _authService = FirebaseAuthProvider();
  @override
  Widget build(BuildContext context) {
    // MyThemes.textTheme = Theme.of(context).textTheme;
    // final textTheme = Theme.of(context).textTheme;
    return ScreenUtilInit(
      builder: (context, _) {
        return Start(appRouter: Get.find());
      },
      designSize: const Size(1080, 1920),
      minTextAdapt: true,
      splitScreenMode: true,
    );
  }
}// 10:58, 11:02
