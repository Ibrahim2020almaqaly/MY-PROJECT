// import 'dart:io';

// import 'package:google_mobile_ads/google_mobile_ads.dart';

// class GoogleMobAds {
//   static final _ads = MobileAds.instance;

//   static Future<void> adsInitialize() async {
//     await _ads.updateRequestConfiguration(
//       RequestConfiguration(
//         testDeviceIds: [
//           'B9940413A17189F70174596FF77A5154',
//         ],
//       ),
//     ); //initialize();
//   }

//   static String getBottomUnitID() {
//     if (Platform.isAndroid) {
//       return 'ca-app-pub-3218733207473585/1969094156';
//       //ca-app-pub-3218733207473585/1969094156   //BottomUnitID
//     } else {
//       throw UnsupportedError('Paltform Is Unsupported');
//     }
//   }

//   static String getInlineTripUnitID() {
//     if (Platform.isAndroid) {
//       return 'ca-app-pub-3218733207473585/2304970222';
//       //ca-app-pub-3218733207473585/1969094156   //BottomUnitID
//     } else {
//       throw UnsupportedError('Paltform Is Unsupported');
//     }
//   } //trip_search_banner_ad //ca-app-pub-3218733207473585/4292801320

//   static String getTripSearchUnitID() {
//     if (Platform.isAndroid) {
//       return 'ca-app-pub-3218733207473585/4292801320';
//       //ca-app-pub-3218733207473585/1969094156   //BottomUnitID
//     } else {
//       throw UnsupportedError('Paltform Is Unsupported');
//     }
//   }

//   static BannerAd createBannerAd(AdSize adSize, String bannerUnitID) {
//     return BannerAd(
//       size: adSize,
//       adUnitId: bannerUnitID,
//       listener: BannerAdListener(
//         onAdLoaded: (ad) {
//           //
//         },
//         onAdFailedToLoad: (ad, error) {
//           ad.dispose();
//         },
//       ),
//       request: const AdRequest(),
//     );
//     // return bannerAd;
//     // bannerAd.load();
//   }
// }
