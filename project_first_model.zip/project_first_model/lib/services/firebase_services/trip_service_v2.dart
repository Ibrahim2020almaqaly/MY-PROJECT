import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/filter_model.dart';

import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class TripServiceV2 extends MasterService {
  late CollectionReference<TripModel> _tripsCollectionRef;
  late CollectionReference<TripModel> _tripsHistoryCollectionRef;
  late Query<TripModel> _filteredQuery;
  var filteredByTripDateOnly = false;
  static const _tripsCollectionName = 'trips';
  static const _tripsHistoryCollectionName = 'driverTripsHistory';
  final List<Map<String, String>> _driversPhones = [{}];

  TripServiceV2() {
    _tripsCollectionRef = _initializeTrips(_tripsCollectionName);
    _filteredQuery = _initializeTrips(_tripsCollectionName);
  }

  CollectionReference<TripModel> _initializeTrips(String collectionName) {
    return FirebaseFirestore.instance
        .collection(collectionName)
        .withConverter<TripModel>(
      fromFirestore: (snapshot, _) {
        return TripModel.fromMap(
          trip: snapshot.data()!,
          id: snapshot.id,
        );
      },
      toFirestore: (trip, _) {
        return trip.toMap();
      },
    );
  }

  CollectionReference<TripModel> _initializeTripsHistory(
      String collectionName) {
    return FirebaseFirestore.instance
        .collection(collectionName)
        .doc(userID)
        .collection('userTripsHistory')
        .withConverter<TripModel>(
      fromFirestore: (snapshot, _) {
        return TripModel.fromMap(
          trip: snapshot.data()!,
          id: snapshot.id,
        );
      },
      toFirestore: (trip, _) {
        return trip.toMap();
      },
    );
  }

  Query<TripModel> get tripQuery {
    return _tripsCollectionRef.orderBy('fullDateTime', descending: true);
  }

  Query<TripModel> get tripHistoryQuery {
    if (userID.isEmpty) {
      throw FirebaseException(
        plugin: 'not Logged in',
        message: 'Not-logged-in',
      );
    }
    _tripsHistoryCollectionRef =
        _initializeTripsHistory(_tripsHistoryCollectionName);

    return _tripsHistoryCollectionRef
        .where('userId', isEqualTo: userID)
        .orderBy('fullDateTime', descending: true);
  }

  Query<TripModel> get higherRateTripQuery {
    return _tripsCollectionRef.orderBy('ratingRatio', descending: true);
  }

  Query<TripModel> get filteredTripQuery {
    return _filteredQuery.orderBy(
        filteredByTripDateOnly ? 'fullDateTime' : 'tripDate',
        descending: true);
  }

  void refershTripQuery() {
    _tripsCollectionRef = _initializeTrips(_tripsCollectionName);
  }

  void refershTripHistoryQuery() {
    _tripsCollectionRef = _initializeTripsHistory(_tripsHistoryCollectionName);
  }

  void refershFilteredTripQuery(FiltersModel filtersModel) {
    _tripsCollectionRef = _initializeTrips(_tripsCollectionName);
    requestFilterTrips(filtersModel);
  }

  Query<TripModel> requestFilterTrips(FiltersModel filtersModel) {
    Query<TripModel> tripQuery = _initializeTrips(_tripsCollectionName);
    var entered = false;

    if (filtersModel.from.isNotEmpty && filtersModel.from != '') {
      tripQuery =
          tripQuery.where('fromSecond', arrayContains: filtersModel.from);
      entered = true;
    }

    if (filtersModel.to.isNotEmpty && filtersModel.to != '') {
      tripQuery = tripQuery.where('to', isEqualTo: filtersModel.to);
      entered = true;
    }

    if (filtersModel.date != null) {
      if (filtersModel.searchForBigger) {
        tripQuery = tripQuery.where('fullDateTime',
            isGreaterThanOrEqualTo:
                filtersModel.fullDateTime!.millisecondsSinceEpoch);
        filteredByTripDateOnly = true;
      } else {
        tripQuery = tripQuery.where('tripDate',
            isEqualTo: filtersModel.date!.millisecondsSinceEpoch);
        filteredByTripDateOnly = true;
      }
      entered = true;
    }

    if (entered) {
      _filteredQuery = tripQuery;
    }
    return _filteredQuery;
  }

  Future<String> getDriverPhoneNumber(String driverID, String tripID) async {
    try {
      if (driverID.isEmpty || driverID == '' || tripID == '') {
        throw CustomException('error-occur');
      }
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      var phoneNumber = '';
      final isThere =
          _driversPhones.indexWhere((phone) => phone.keys.contains(tripID));
      if (isThere >= 0) {
        phoneNumber = _driversPhones[isThere][tripID]!;
        return phoneNumber;
      }

      final snapshot = await _tripsCollectionRef
          .doc(tripID)
          .collection('driverPhone')
          .doc(driverID)
          .get();

      if (snapshot.data() != null) {
        phoneNumber = snapshot.data()!['phoneNumber'];
        _driversPhones.add({tripID: phoneNumber});
      }

      return phoneNumber;
    } on CustomException catch (_) {
      rethrow;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<TripModel?> findByUserId(String userId) async {
    try {
      final snapshot = await _tripsCollectionRef
          .where('userId', isEqualTo: userId)
          .orderBy('fullDateTime', descending: true)
          .limit(1)
          .get();

      if (snapshot.docs.isNotEmpty) {
        final snapShotData = snapshot.docs[0];
        final trip = snapShotData.data().copyWith(tripId: snapShotData.id);

        return trip; //TripModel.fromMap(trip: snapShotData, id: snapshot.id);
      }
      return null;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<TripModel?> findTripById(String tripId) async {
    try {
      final trip = await _getTripByID(_tripsCollectionRef, tripId);
      return trip;
    } on CustomException catch (_) {
      rethrow;
    }
  }

  Future<TripModel?> findTripHistoryById(String tripId) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      _tripsHistoryCollectionRef =
          _initializeTripsHistory(_tripsHistoryCollectionName);

      final trip = await _getTripByID(_tripsHistoryCollectionRef, tripId);
      return trip;
    } on CustomException catch (_) {
      rethrow;
    }
  }

  Future<TripModel?> _getTripByID(
      CollectionReference<TripModel> collection, String tripID) async {
    try {
      final snapshot = await collection.doc(tripID).get();

      if (snapshot.data() != null) {
        final snapShotData = snapshot.data()!;
        final trip = snapShotData.copyWith(tripId: snapshot.id);

        return trip; //TripModel.fromMap(trip: snapShotData, id: snapshot.id);
      }
      return null;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<String> addTrip(TripModel trip) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      final docId = await _tripsCollectionRef.add(trip);

      return docId.id;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> updateTrip(TripModel trip, String id) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _tripsCollectionRef.doc(id).set(trip, SetOptions(merge: true));
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteTrip(String tripId) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _tripsCollectionRef.doc(tripId).delete();
    } on FirebaseException catch (e) {
      throw CustomException(e.message ?? '');
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteTripHistory(String tripId) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      _tripsHistoryCollectionRef =
          _initializeTripsHistory(_tripsHistoryCollectionName);

      await _tripsHistoryCollectionRef.doc(tripId).delete();
    } on FirebaseException catch (e) {
      throw CustomException(e.message ?? '');
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() {
    //
    super.dispose();
  }
}
