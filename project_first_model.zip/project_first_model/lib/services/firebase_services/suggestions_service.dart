import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/suggestion_model.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class SuggestionsService extends MasterService {
  late CollectionReference<SuggestionModel> _suggestionCollectionRef;

  SuggestionsService() {
    _suggestionCollectionRef = suggestionInit();
  }

  CollectionReference<SuggestionModel> suggestionInit() {
    return FirebaseFirestore.instance
        .collection('usersSuggestions')
        .withConverter<SuggestionModel>(
      fromFirestore: (snapshot, _) {
        return SuggestionModel.fromMap(
          suggestion: snapshot.data()!,
          userID: snapshot.id,
        );
      },
      toFirestore: (report, _) {
        return report.toMap();
      },
    );
  }

  Future<SuggestionModel?> getUserSuggestions(String userID) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      final snapshot = await _suggestionCollectionRef.doc(userID).get();

      final snapshotData = snapshot.data();
      if (snapshotData != null) {
        return snapshotData;
      }
      return null;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  ///for admin get all suggestions
  Future<List<SuggestionModel>?> getAllSuggestions() async {
    return null;
  }

  Future<void> addUserSuggestion(SuggestionModel suggestionModel) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      await _suggestionCollectionRef.doc(userID).set(suggestionModel);
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> updateUserSuggestion(SuggestionModel suggestionModel) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      await _suggestionCollectionRef
          .doc(userID)
          .set(suggestionModel, SetOptions(merge: true));
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteUserSuggestion(String userID) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      await _suggestionCollectionRef.doc(userID).delete();
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() {
    //
    super.dispose();
  }
}
