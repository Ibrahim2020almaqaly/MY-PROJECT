import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/rating_model.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class RatingService extends MasterService {
  late CollectionReference<DriverRatingModel> _ratingRef;
  StreamSubscription<DocumentSnapshot<DriverRatingModel>>?
      _driverRateSubscribtion;
  final _driverRateListener = StreamController<DriverRatingModel>.broadcast();
  var login = false;

  RatingService() {
    _ratingRef = _initialize;

    driverSubscribe();
  }

  void driverSubscribe() {
    if (isThereUser) {
      if (!login) {
        _driverRateSubscribtion = _ratingRef
            .doc(userID)
            .snapshots(includeMetadataChanges: true)
            .listen((rate) {
          if (rate.data() != null) {
            final model = rate.data()!;
            _driverRateListener.add(model);
          }
        });
        login = true;
      }
    } else {
      if (login) {
        _driverRateSubscribtion?.cancel();
      }
    }
  }

  CollectionReference<DriverRatingModel> get _initialize {
    return FirebaseFirestore.instance
        .collection('ratings')
        .withConverter<DriverRatingModel>(
      fromFirestore: (snapshot, _) {
        return DriverRatingModel.fromMap(
          driverID: snapshot.id,
          rating: snapshot.data()!,
        );
      },
      toFirestore: (rating, _) {
        return rating.toMap();
      },
    );
  }

  Query<DriverRatingModel> higherRateQuery(String region) {
    final query = _ratingRef.orderBy('starsRatio', descending: true).where(
          'starsRatio',
          isGreaterThan: 0,
        );
    if (region == '' && region.isEmpty) {
      return query;
    } else {
      return query.where('region', isEqualTo: region);
    }
  }

  void refershHigherDriverRate() {
    _ratingRef = _initialize;
  }

  Stream<DriverRatingModel> listernToRatingChnages() {
    driverSubscribe();
    return _driverRateListener.stream;
  }

  ///this only gives us the how many stars driver has
  ///and how many people rated him
  Future<DriverRatingModel?> getDriverRate(String driverID) async {
    try {
      if (driverID == '') {
        return null;
      }
      final ratingSnapshot = await _ratingRef.doc(driverID).get();

      final ratingSnapshotData = ratingSnapshot.data();

      if (ratingSnapshotData == null) {
        return null;
      }
      // final user = userSnapshotData; //.copyWith(userId: userSnapshot.id);
      return ratingSnapshotData;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> addDriverRate(String driverID, DriverRatingModel rate) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _ratingRef.doc(driverID).set(rate);
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> updateDriverRate(String driverID, DriverRatingModel rate) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _ratingRef.doc(driverID).set(rate, SetOptions(merge: true));
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteDriverRate(String? driverID) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _ratingRef.doc(driverID).delete();
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<TripRatingModel?> getTripRate(String driverID, String tripID) async {
    try {
      if (driverID == '' || tripID == '') {
        return null;
      }
      final snapshot = await _ratingRef
          .doc(driverID)
          .collection('tripsRate')
          .doc(tripID)
          .get();

      final snapshotData = snapshot.data();
      if (snapshotData != null) {
        final tripRate = TripRatingModel.fromMap(
          tripRate: snapshotData,
          tripID: snapshot.id,
        );

        return tripRate;
      }
      return null;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> addTripRate(
    String driverID,
    String tripID,
    TripRatingModel tripRate,
  ) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _ratingRef
          .doc(driverID)
          .collection('tripsRate')
          .doc(tripID)
          .set(tripRate.toMap());

      //note if we have firebase Functions we don't need this anymore
      // var driverRate =
      //     await getDriverRate(driverID) ?? DriverRatingModel.defaultRate;
      // if (driverRate != DriverRatingModel.defaultRate) {
      //   driverRate = driverRate.copyWith(
      //     tripsCount: driverRate.tripsCount + 1,
      //   );
      //   await updateDriverRate(driverID, driverRate);
      // } else {
      //   driverRate = driverRate.copyWith(
      //     tripsCount: driverRate.tripsCount + 1,
      //   );
      //   await addDriverRate(driverID, driverRate);
      // }
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> updateTripRate(
    String driverID,
    String tripID,
    TripRatingModel tripRate,
  ) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _ratingRef
          .doc(driverID)
          .collection('tripsRate')
          .doc(tripID)
          .set(tripRate.toMap(), SetOptions(merge: true));
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteTripRate(
    String driverID,
    String tripID,
  ) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (tripID == '') {
        throw Exception('tripID-not-Found');
      }
      final query =
          _ratingRef.doc(driverID).collection('tripsRate').doc(tripID);
      await query.delete();

      // final tripRatesnapshot = await query.get();
      // if (tripRatesnapshot.data() != null) {
      //   final tripRate = TripRatingModel.fromMap(
      //     tripRate: tripRatesnapshot.data()!,
      //     tripID: tripRatesnapshot.id,
      //   );
      //   await query.delete();
      //   final driverRate = await getDriverRate(driverID);
      //   if (driverRate != null) {
      //     final starsCount = driverRate.starsCount - tripRate.starsCount;
      //     final peopleCount =
      //         driverRate.ratingPeopleCount - tripRate.ratingPeopleCount;
      //     var ratio = 0.0;
      //     final tripCount = driverRate.tripsCount - 1;
      //     if (peopleCount != 0) {
      //       ratio = starsCount / peopleCount;
      //     }
      //     await updateDriverRate(
      //         driverID,
      //         driverRate.copyWith(
      //           ratingPeopleCount: peopleCount > 0 ? 0 : peopleCount,
      //           starsCount: starsCount > 0 ? 0 : starsCount,
      //           starsRatio: ratio > 0 ? 0 : ratio,
      //           tripsCount: tripCount > 0 ? 0 : tripCount,
      //         ));
      //     return;
      //   }
      //   throw CustomException('ID Not Found');
      // }
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<CustomerRatingModel?> getCustomerRating(
      String driverID, String tripID, String customerID) async {
    try {
      if (driverID == '' || customerID == '' || tripID == '') {
        return null;
      }
      final ratingSnapshot = await _ratingRef
          .doc(driverID)
          .collection('tripsRate')
          .doc(tripID)
          .collection('customersRate')
          .doc(customerID)
          .get();

      final ratingSnapshotData = ratingSnapshot.data();

      if (ratingSnapshotData == null) {
        return null;
      }
      final custRate = CustomerRatingModel.fromMap(
        map: ratingSnapshotData,
        custID: ratingSnapshot.id,
      );
      // final user = userSnapshotData; //.copyWith(userId: userSnapshot.id);
      return custRate;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> addCustomerRate(
    String driverID,
    String tripID,
    CustomerRatingModel customerRating,
  ) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _ratingRef
          .doc(driverID)
          .collection('tripsRate')
          .doc(tripID)
          .collection('customersRate')
          .doc(customerRating.customerID)
          .set(customerRating.toMap());

      // //note if we have firebase Functions we don't need this anymore
      // var driverRate = await getDriverRate(driverID);
      // if (driverRate != null) {
      //   final count = driverRate.starsCount + customerRating.starNumber;
      //   final peoCount = driverRate.ratingPeopleCount + 1;
      //   var ratio = 0.0;
      //   if (peoCount != 0) {
      //     ratio = (count / peoCount);
      //   }
      //   driverRate = driverRate.copyWith(
      //     ratingPeopleCount: peoCount,
      //     starsCount: count,
      //     starsRatio: ratio,
      //   );
      //   await updateDriverRate(driverID, driverRate);
      // }

      // var tripRate = await getTripRate(driverID, tripID);
      // if (tripRate != null) {
      //   final count = tripRate.starsCount + customerRating.starNumber;
      //   final peoCount = tripRate.ratingPeopleCount + 1;
      //   var ratio = 0.0;
      //   if (peoCount != 0) {
      //     ratio = (count / peoCount);
      //   }
      //   tripRate = tripRate.copyWith(
      //     ratingPeopleCount: peoCount,
      //     starsCount: count,
      //     starsRatio: ratio,
      //   );
      //   await updateTripRate(driverID, tripID, tripRate);
      // }
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> updateCustomerRate(
    String driverID,
    String tripID,
    CustomerRatingModel customerRating,
    int oldRating,
  ) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _ratingRef
          .doc(driverID)
          .collection('tripsRate')
          .doc(tripID)
          .collection('customersRate')
          .doc(customerRating.customerID)
          .set(customerRating.toMap(), SetOptions(merge: true));

      // //note if we have firebase Functions we don't need this anymore
      // var driverRate = await getDriverRate(driverID);
      // if (driverRate != null) {
      //   final count = driverRate.starsCount + customerRating.starNumber;
      //   final peoCount = driverRate.ratingPeopleCount + 1;
      //   var ratio = 0.0;
      //   if (peoCount != 0) {
      //     ratio = (count / peoCount);
      //   }
      //   driverRate = driverRate.copyWith(
      //     ratingPeopleCount: peoCount,
      //     starsCount: count,
      //     starsRatio: ratio,
      //   );
      //   await updateDriverRate(driverID, driverRate);
      // }

      // var tripRate = await getTripRate(driverID, tripID);
      // if (tripRate != null) {
      //   final count = tripRate.starsCount + customerRating.starNumber;
      //   final peoCount = tripRate.ratingPeopleCount + 1;
      //   var ratio = 0.0;
      //   if (peoCount != 0) {
      //     ratio = (count / peoCount);
      //   }
      //   tripRate = tripRate.copyWith(
      //     ratingPeopleCount: peoCount,
      //     starsCount: count,
      //     starsRatio: ratio,
      //   );
      //   await updateTripRate(driverID, tripID, tripRate);
      // }
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() async {
    if (!_driverRateListener.isClosed) {
      await _driverRateListener.close();
    }
    await _driverRateSubscribtion?.cancel();
    super.dispose();
  }
}
