import 'dart:async';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:project_first_model/models/filter_model.dart';
import 'package:project_first_model/models/trip_model.dart';

class TripService {
  var _tripModelList = StreamController<List<TripModel>>.broadcast();
  final List<List<TripModel>> _allTripsResults = [];
  DocumentSnapshot? _lastDocument;
  bool _hasMoreDocs = true;
  DocumentSnapshot? _lastFilteredDocument;
  bool _hasMoreFilteredDocs = true;
  final List<List<TripModel>> _allFilteredTripsResults = [];
  // FiltersModel _model = const FiltersModel();
  // var _filterTripModelList = StreamController<List<TripModel>>.broadcast();
  // final List<List<TripModel>> _allFilterTripsResults = [];
  // DocumentSnapshot? _lastFilterDocument;
  // bool _hasMoreFilterDocs = true;
  final _tripsCollectionRef = FirebaseFirestore.instance.collection('trips');
  // var _isFiltered = false;

  // set setCurrentFilter(FiltersModel model) {
  //   _model = model;
  // }

  Stream<List<TripModel>> listenToTripRealTime(
      // {bool filter = false, required FiltersModel filterModel}
      ) {
    try {
      _requestNonFilterTrips();
      return _tripModelList.stream;
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  // Stream<List<TripModel>> listenToFilteredTripRealTime() {
  //   // if (_isFiltered) {
  //   //   _isFiltered = true;
  //   //   _resetStream();
  //   // }
  //   _requestFilterTrips(_model);
  //   return _tripModelList.stream;
  // }

  void resetStream() {
    _tripModelList = StreamController<List<TripModel>>.broadcast();
    _allTripsResults.clear();
    _lastDocument = null;
    _hasMoreDocs = true;
  }

  void resetFilteredStream() {
    _allFilteredTripsResults.clear();
    _lastFilteredDocument = null;
    _hasMoreFilteredDocs = true;
  }

  void _requestTrips(Query<Map<String, dynamic>> tripQuery) {
    if (_lastDocument != null) {
      tripQuery = tripQuery.startAfterDocument(_lastDocument!);
    }

    if (!_hasMoreDocs) return;

    final currentRequestIndex = _allTripsResults.length;

    tripQuery.snapshots(includeMetadataChanges: true).listen((tripsSnapshot) {
      if (tripsSnapshot.docs.isNotEmpty) {
        final trips = tripsSnapshot.docs.map((snapshot) {
          return TripModel.fromMap(trip: snapshot.data(), id: snapshot.id);
        }).toList();

        final tripExist = currentRequestIndex < _allTripsResults.length;

        //if the trip exist update the values to the new trips
        if (tripExist) {
          _allTripsResults[currentRequestIndex] = trips;
        } //if the trip doesn't exist add new trips
        else {
          _allTripsResults.add(trips);
        }

        final alltrips = _allTripsResults.fold<List<TripModel>>(
          [],
          (initialValues, tripItems) => initialValues..addAll(tripItems),
        );

        //broadcast all Trips in the trip structure
        _tripModelList.add(alltrips);

        if (currentRequestIndex == _allTripsResults.length - 1) {
          _lastDocument = tripsSnapshot.docs.last;
        }

        //determin if there's more trips to requset
        _hasMoreDocs = trips.length == 10;
      }
    });
  }

  ///this Function Return Filtered Trips
  /// if the requset from (requestMoreData) function the clear will
  /// set to false but if we filter new FILTER we will set it to true
  /// for restart from the begining
  Future<List<TripModel>> requestFilterTrips(
      FiltersModel filtersModel, bool clear) async {
    try {
      Query<Map<String, dynamic>>? tripQuery;

      if (clear) {
        resetFilteredStream();
      }

      switch (FiltersModel.priority) {
        case FilterPriority.from:
          tripQuery = _tripsCollectionRef.where('fromSecond',
              arrayContains: filtersModel.from);
          break;

        case FilterPriority.to:
          tripQuery =
              _tripsCollectionRef.where('to', isEqualTo: filtersModel.to);
          break;

        case FilterPriority.date:
          if (filtersModel.searchForBigger) {
            tripQuery = _tripsCollectionRef.where('fullDateTime',
                isGreaterThanOrEqualTo:
                    filtersModel.fullDateTime!.millisecondsSinceEpoch);
          } else {
            tripQuery = _tripsCollectionRef.where('tripDate',
                isEqualTo: filtersModel.date!.millisecondsSinceEpoch);
            // print(TripModel.fromMap(trip: tripQuery));
          }
          break;

        default:
      }

      if (tripQuery != null) {
        tripQuery = tripQuery.limit(10);
        QuerySnapshot<Map<String, dynamic>> data;

        if (!_hasMoreFilteredDocs) return [];

        final currentRequestIndex = _allFilteredTripsResults.length;

        if (_lastFilteredDocument != null) {
          tripQuery = tripQuery.startAfterDocument(_lastFilteredDocument!);
        }

        data = await tripQuery.get();

        final trips = data.docs.map((snapshot) {
          return TripModel.fromMap(trip: snapshot.data(), id: snapshot.id);
        }).toList();

        _allFilteredTripsResults.add(trips);

        final allTrips = _allFilteredTripsResults.fold<List<TripModel>>(
          [],
          (allValues, tripItems) => allValues..addAll(tripItems),
        );

        if (currentRequestIndex == _allFilteredTripsResults.length - 1) {
          if (data.docs.isNotEmpty) {
            _lastFilteredDocument = data.docs.last;
          }
        }

        _hasMoreFilteredDocs = trips.length == 10;

        return allTrips;
      }

      return [];
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  void _requestNonFilterTrips() {
    var tripQuery = _tripsCollectionRef
        .orderBy(
          'tripDate',
          descending: true,
        )
        .limit(10);
    _requestTrips(tripQuery);
  }

  Future<TripModel?> findById(String tripID) async {
    try {
      final snapshot = await _tripsCollectionRef.doc(tripID).get();

      final snapShotData = snapshot.data();
      if (snapShotData == null) {
        return null;
      }

      return TripModel.fromMap(trip: snapShotData, id: snapshot.id);
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  Future<String> saveImage(String id, File image, String type) async {
    try {
      final ref = FirebaseStorage.instance
          .ref()
          .child('trips-users-pics')
          .child(id)
          .child('$id${type.trim()}.jpg');
      String imageUrl = '';
      await ref.putFile(image).whenComplete(() => null);
      imageUrl = await ref.getDownloadURL();
      return imageUrl;
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  Future<void> deleteImage(String id) async {
    try {
      final ref =
          FirebaseStorage.instance.ref().child('trips-users-pics').child(id);
      await ref.delete().whenComplete(() => null);
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  Future<String> updateImage(String id, File image, String type) async {
    try {
      // await deleteImage(id);

      return await saveImage(id, image, type);
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  Future<String> addTrip(TripModel trip) async {
    try {
      final docId = await _tripsCollectionRef.add(trip.toMap());

      return docId.id;
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  Future<void> updateTrip(TripModel trip, String id) async {
    try {
      await _tripsCollectionRef.doc(id).update(trip.toMap());
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  Future<void> deleteTrip(String tripId) async {
    try {
      await _tripsCollectionRef.doc(tripId).delete();
    } on Exception catch (e) {
      throw Exception(e);
    }
  }

  void requestMoreData({FiltersModel? filter}) => filter == null
      ? _requestNonFilterTrips()
      : requestFilterTrips(filter, false);

  void dispose() {
    _tripModelList.close();
    _allTripsResults.clear();
    _lastDocument = null;
  }
}
