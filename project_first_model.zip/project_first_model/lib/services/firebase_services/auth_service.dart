import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/services/app_settings.dart';
import 'package:project_first_model/services/firebase_services/disabled_user_service.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

enum VerificationState {
  none,
  completed,
  failed,
  codeSent,
  timeOut,
}

class AuthService extends MasterService {
  final _auth = FirebaseAuth.instance;
  var _verificationId = '';
  int? _resendToken;
  var _smsCode = '';
  // String _currentUserID = '';
  StreamController<VerificationState>? _verificationState;
  late StreamController<User?> _listenUserIdChanges;
  late StreamSubscription<User?> _listenToAuthChanges;
  late DisabledUserService _disabledUserService;
  bool _isDisabled = false;
  // String? errorMsg;

  AuthService() {
    _auth.setSettings(forceRecaptchaFlow: true);
    _disabledUserService = DisabledUserService();
    _isDisabled =
        AppSettings.getSettingValue<bool>(AppSettings.isDisabledKey, false);
    if (isOnline && _auth.currentUser != null) {
      _checkToken();
    }
    _listenUserIdChanges = StreamController<User?>.broadcast();
    _listenToAuthChanges = _auth.authStateChanges().listen((user) {
      if (user == null) {
        _listenUserIdChanges.add(null);
      } else {
        _listenUserIdChanges.add(user);
        // setCurrentUserID = user.uid;
      }
    });
    _auth.setLanguageCode('ar');
  }

  Future<bool> _checkToken() async {
    try {
      final res = await _auth.currentUser?.getIdToken();
      return res != null;
    } on Exception catch (err) {
      if (err.toString().contains('user-disabled')) {
        _isDisabled = true;
        userLogOut();
        ShowAnyMessages.showToastMSG(
          'يبدو أن هذا الحساب معطل',
          // floating: false,
          // isError: true,
        );
      } else if (err.toString().contains('uid-already-exists')) {
        ShowAnyMessages.showToastMSG(
          'يبدو أن هذا الحساب معطل',
          // floating: false,
          // isError: true,
        );
        userLogOut();
      } else if (err.toString().contains('user-not-found')) {
        ShowAnyMessages.showToastMSG(
          'هذا المستخدم غير موجود',
          // floating: false,
          // isError: true,
        );
        userLogOut();
      } else if (err.toString().contains('missing-uid')) {
        ShowAnyMessages.showToastMSG(
          'حدث خطأ يرجى تسجيل الدخول مرة أخرى',
          // floating: false,
          // isError: true,
        );
        userLogOut();
      } else if (err.toString().contains('invalid-uid')) {
        ShowAnyMessages.showToastMSG(
          'حدث خطأ يرجى تسجيل الدخول مرة أخرى',
          // floating: false,
          // isError: true,
        );
        userLogOut();
      } else if (err.toString().contains('id-token-expired')) {
        ShowAnyMessages.showToastMSG(
          'حدث خطأ يرجى تسجيل الدخول مرة أخرى',
          // floating: false,
          // isError: true,
        );
        userLogOut();
      } else {
        ShowAnyMessages.showToastMSG(
          err.toString(),
          // floating: false,
          // isError: true,
        );
        // ShowAnyMessages.showToastMSG(
        //     'else $err' 'حدث خطأ يرجى تسجيل الدخول مرة أخرى');
        // userLogOut();
      }
      return false;
    }
  }

  Future<bool> validToken() async {
    final valid = await _checkToken();
    return valid;
  }

  String get getVerificationID {
    return _verificationId;
  }

  String get getSMSCode {
    return _smsCode;
  }

  bool get idDisabled {
    return _isDisabled;
  }

  Future<bool> checkFromDBIfDisabled(String phoneNumber) async {
    try {
      final res = await _disabledUserService.isTheNumberDisabled(phoneNumber);
      AppSettings.setSettingValue<bool>(AppSettings.isDisabledKey, res);
      return res;
    } on CustomException catch (_) {
      rethrow;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Stream<VerificationState> listenToVerificationState() {
    return _verificationState!.stream;
  }

  Stream<User?> listenToUserIDChnages() {
    return _listenUserIdChanges.stream;
  }

  User? get getCurrentUser {
    return _auth.currentUser;
  }

  // set setCurrentUserID(String userID) {
  //   _currentUserID = userID;
  // }

  void _verificationCompleted(PhoneAuthCredential phoneAuthCredential) async {
    try {
      _verificationState?.add(VerificationState.completed);
      _smsCode = phoneAuthCredential.smsCode ?? '';
      await signInWithPhoneAuthCredential(phoneAuthCredential);
    } on CustomException catch (_) {
      // ShowAnyMessages.showSnackBar(_.errorMessage,
      //     floating: false, isError: true);
      rethrow;
    } on Exception catch (e) {
      // ShowAnyMessages.showSnackBar(e.toString(),
      //     floating: false, isError: true);
      throw CustomException(e.toString());
    }
  }

  void _verificationFailed(FirebaseAuthException authException) {
    _verificationId = '';
    _smsCode = '';
    _resendToken = null;
    _verificationState?.add(VerificationState.failed);
    ShowAnyMessages.showToastMSG(
      authException.message ?? authException.code,
      // floating: false,
      // isError: true,
    );

    FirebaseCrashlytics.instance.recordError(
      authException,
      authException.stackTrace,
    );

    if (authException.message?.contains('user-disabled') ?? false) {
      throw CustomException('user-disabled');
    }
    if (authException.code.contains('invalid-phone-number')) {
      throw CustomException('phone-error');
    }
    if (authException.code.contains('invalid-verification-code')) {
      throw CustomException('invalid-code');
    }
    if (authException.message != null) {
      throw CustomException(authException.message ?? '');
    }
    throw CustomException(authException.message ?? 'Error');
  }

  void _codeSent(String verificationId, [int? forceResendingToken]) async {
    _verificationState?.add(VerificationState.codeSent);
    _verificationId = verificationId;
    _resendToken = forceResendingToken;
  }

  void _codeAutoRetrievalTimeout(String verificationId) {
    verificationId = verificationId;
    _verificationState?.add(VerificationState.timeOut);
  }

  Stream<User?> listenToAuthStateChanges() {
    return _auth.authStateChanges();
  }

  Future<void> beginToVerifyUser(String phoneNumber) async {
    try {
      await _auth
          .verifyPhoneNumber(
            phoneNumber: phoneNumber,
            timeout: const Duration(seconds: 100),
            verificationCompleted: _verificationCompleted,
            verificationFailed: _verificationFailed,
            codeSent: _codeSent,
            codeAutoRetrievalTimeout: _codeAutoRetrievalTimeout,
            forceResendingToken: _resendToken,
          )
          .onError(
            (error, stackTrace) => ShowAnyMessages.showToastMSG(
              error.toString(),
              // floating: false,
              // isError: true,
            ),
          );
    } on FirebaseAuthException catch (e) {
      // ShowAnyMessages.showSnackBar(e.message ?? e.code);
      if (e.code.contains('invalid-verification-code')) {
        throw CustomException('invalid-code');
      }
      throw CustomException(e.message ?? '');
    } on CustomException catch (_) {
      // ShowAnyMessages.showSnackBar(_.errorMessage,
      //     floating: false, isError: true);
      rethrow;
    } on Exception catch (e) {
      // ShowAnyMessages.showSnackBar(e.toString(),
      //     floating: false, isError: true);
      throw CustomException(e.toString());
    }
  }

  Future<void> confirmUser(String otbCode) async {
    try {
      if (getVerificationID.isEmpty) {
        throw CustomException('code-not-received');
      }

      PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.credential(
        verificationId: _verificationId,
        smsCode: otbCode,
      );

      await signInWithPhoneAuthCredential(phoneAuthCredential);
    } on FirebaseAuthException catch (e) {
      if (e.code.contains('invalid-verification-code')) {
        throw CustomException('invalid-code');
      }
      throw CustomException(e.toString());
    } on CustomException catch (_) {
      rethrow;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> signInWithPhoneAuthCredential(
      PhoneAuthCredential phoneAuthCredential) async {
    try {
      // final authCredential =
      await _auth.signInWithCredential(phoneAuthCredential);

      // if (authCredential.user != null) {
      //   _currentUserID = authCredential.user!.uid;
      //   // return _currentUserID;
      // }
      // return '';
    } on FirebaseAuthException catch (e) {
      // ShowAnyMessages.showSnackBar(
      //   e.message ?? e.code,
      //   floating: false,
      //   isError: true,
      // );
      if (e.code.contains('user-disabled')) {
        throw CustomException('user-disabled');
      }
      if (e.code.contains('invalid-verification-code')) {
        throw CustomException('invalid-code');
      }
      throw CustomException(e.message ?? '');
    }
  }

  Future<void> userLogOut() async {
    try {
      if (_auth.currentUser == null) return;
      await _auth.signOut();
      await AppSettings.removeSettingValue<bool>(AppSettings.enteredTheDataKey);
    } on FirebaseAuthException catch (e) {
      throw CustomException(e.message ?? '');
    }
  }

  void closeStream() async {
    if (_verificationState != null && !_verificationState!.isClosed) {
      await _verificationState!.close();
      _verificationState = null;
    }
    _verificationId = '';
    _smsCode = '';
    _resendToken = null;
  }

  void initializeStream() {
    _verificationState ??= StreamController<VerificationState>.broadcast();
  }

  @override
  void dispose() async {
    closeStream();
    await _listenUserIdChanges.close();
    await _listenToAuthChanges.cancel();
    super.dispose();
  }
}
