import 'package:get/get.dart';
import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';

class MasterService extends GetxService {
  MasterService();
  var _onLineStream = false;
  var _userStream = false;

  bool get isThereUser {
    final userID = Get.find<FirebaseAuthController>().getCurrentUser?.uid ?? '';
    return userID != '' && userID.isNotEmpty;
  }

  RxBool get isThereUserStream {
    _userStream = true;
    return isThereUser.obs;
  }

  static bool get isThereUserStatic {
    final userID = Get.find<FirebaseAuthController>().getCurrentUser?.uid ?? '';
    return userID != '' && userID.isNotEmpty;
  }

  String get userID {
    final userID = Get.find<FirebaseAuthController>().getCurrentUser?.uid ?? '';
    return userID;
  }

  bool get isOnline {
    return Get.find<ConnectionController>().isOnline;
  }

  RxBool get onlineStream {
    _onLineStream = true;
    return isOnline.obs;
  }

  static bool get isOnlineStatic {
    return Get.find<ConnectionController>().isOnline;
  }

  void dispose() {
    if (_userStream) {
      isThereUserStream.close();
      _userStream = false;
    }

    if (_onLineStream) {
      isThereUserStream.close();
      _onLineStream = false;
    }
  }
}
