import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/user_modelv2.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class UserService extends MasterService {
  late CollectionReference<UserModelV2> _userCollectionRef;
  late Reference _userStorageRef;

  UserService() {
    _userCollectionRef = FirebaseFirestore.instance
        .collection('users')
        .withConverter<UserModelV2>(
      fromFirestore: (snapshot, _) {
        return UserModelV2.fromMap(
          user: snapshot.data()!,
          id: snapshot.id,
        );
      },
      toFirestore: (user, _) {
        return user.toMap();
      },
    );
    _userStorageRef = FirebaseStorage.instance.ref().child('users-pics/');
  }

  /// Note: when We get The user we Get it With Id
  Future<UserModelV2> getMyData() async {
    try {
      if (!isThereUser) {
        return UserModelV2.defaultUser;
      }
      final userSnapshot = await _userCollectionRef.doc(userID).get();

      final userSnapshotData = userSnapshot.data();

      if (userSnapshotData == null) {
        return UserModelV2.defaultUser;
      }
      // final user = userSnapshotData; //.copyWith(userId: userSnapshot.id);
      return userSnapshotData;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  /// Note: when We get The user we Get it With Id
  Future<UserModelV2?> getUserWithPhone(String phoneNumber) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }

      final userSnapshot = await _userCollectionRef
          .where(
            'userPhoneNumber',
            isEqualTo: phoneNumber,
          )
          .limit(1)
          .get();

      if (userSnapshot.docs.isNotEmpty) {
        final snapShotData = userSnapshot.docs[0];
        final user = snapShotData.data().copyWith(userId: snapShotData.id);

        return user;
      }
      return null;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<String> saveImage(File image, String type) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }

      final userRef = _userStorageRef
          .child('$userID/')
          .child('${userID}_${type.trim()}.jpg');
      final task = userRef.putFile(image);
      var imageUrl = '';
      final snapshot = await task.whenComplete(() => null);
      // await ref.putFile(image).whenComplete(() => null);
      imageUrl = await snapshot.ref.getDownloadURL();
      return imageUrl;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteImageFile() async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }

      final userRef = _userStorageRef.child('$userID/');
      userRef.getDownloadURL().then((value) async {
        await userRef.delete().whenComplete(() => null);
      }).onError((error, stackTrace) => null);
    } on Exception catch (e) {
      // if (e.toString().toLowerCase().contains('not-found')) {
      //   return;
      // }
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteImage(String type) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }

      final userRef =
          _userStorageRef.child('$userID/').child('$userID${type.trim()}.jpg');
      userRef.getDownloadURL().then((value) async {
        await userRef.delete().whenComplete(() => null);
      }).onError((error, stackTrace) => null);
      // await ref.delete().whenComplete(() => null);
    } on Exception catch (e) {
      // if (e.toString().toLowerCase().contains('not-found.')) {
      //   return;
      // }
      throw CustomException(e.toString());
    }
  }

  Future<String> updateImage(File image, String type) async {
    try {
      return await saveImage(image, type);
    } catch (e) {
      rethrow;
    }
  }

  /// Note: when We Save The user we Save it Without Id
  Future<void> addUser(UserModelV2 user) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }

      await _userCollectionRef.doc(userID).set(user);
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> updateUser(UserModelV2 user) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }

      await _userCollectionRef.doc(userID).set(user, SetOptions(merge: true));
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteUser(String? userId) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }

      await _userCollectionRef.doc(userId).delete();
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() {
    //
    super.dispose();
  }
}
