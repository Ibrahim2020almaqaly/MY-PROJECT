import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/disabled_user_model.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class DisabledUserService extends MasterService {
  late CollectionReference<DisabledUserModel> _disabledCollectionRef;
  final _collectionName = 'disabledUsers';

  DisabledUserService() {
    _disabledCollectionRef = FirebaseFirestore.instance
        .collection(_collectionName)
        .withConverter<DisabledUserModel>(
      fromFirestore: (snapshot, _) {
        return DisabledUserModel.fromMap(
          user: snapshot.data()!,
          userId: snapshot.id,
        );
      },
      toFirestore: (user, _) {
        return user.toMap();
      },
    );
  }

  Future<void> disableUser(
      String userID, DisabledUserModel disabledUser) async {
    // try {
    await _disabledCollectionRef
        // FirebaseFirestore.instance
        //     .collection(_collectionName)
        .doc(userID)
        .set(disabledUser);
    // AppSettings.setSettingValue<bool>(AppSettings.isDisabledKey, true);
    // } on Exception catch (_) {}
  }

  Future<bool> isTheNumberDisabled(String phoneNumber) async {
    try {
      if (!isOnline) {
        throw CustomException("not-online");
      }
      final snapshot = await _disabledCollectionRef
          .where('phoneNumber', isEqualTo: phoneNumber)
          .limit(1)
          .get();

      if (snapshot.docs.isNotEmpty) {
        final data = snapshot.docs[0].data();
        return data.disable;
      }

      return false;

      // AppSettings.setSettingValue<bool>(AppSettings.isDisabledKey, isDataFound);

      // if (isDataFound) {
      //   return true;
      // }
      // return false;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> unDisabledUser(String phoneNumber) async {
    try {
      if (!isOnline) {
        throw CustomException("not-online");
      }

      final snapshot = await _disabledCollectionRef
          .where('phoneNumber', isEqualTo: phoneNumber)
          .limit(1)
          .get();

      if (snapshot.docs.isNotEmpty) {
        final user = snapshot.docs[0];
        await _disabledCollectionRef.doc(user.id).delete();
        // AppSettings.setSettingValue<bool>(AppSettings.isDisabledKey, true);
      }
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() {
    //
    super.dispose();
  }
}
