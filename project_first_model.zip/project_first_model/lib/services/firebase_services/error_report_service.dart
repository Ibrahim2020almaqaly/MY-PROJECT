import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/error_report_model.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class ErrorReportService extends MasterService {
  late CollectionReference<ErrorReportModel> _errorReportCollectionRef;
  late Reference _errorReportStorageRef;

  ErrorReportService() {
    _errorReportStorageRef =
        FirebaseStorage.instance.ref().child('errorReport-pics');
  }

  CollectionReference<ErrorReportModel> get errorReportInit {
    return FirebaseFirestore.instance
        .collection('usersErrorReports')
        .withConverter<ErrorReportModel>(
      fromFirestore: (snapshot, _) {
        return ErrorReportModel.fromMap(
          error: snapshot.data()!,
          userID: snapshot.id,
        );
      },
      toFirestore: (report, _) {
        return report.toMap();
      },
    );
  }

  Future<ErrorReportModel?> getUserErrorReport(String userID) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      _errorReportCollectionRef = errorReportInit;

      final snapshot = await _errorReportCollectionRef.doc(userID).get();

      final snapshotData = snapshot.data();
      if (snapshotData != null) {
        return snapshotData;
      }
      return null;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  ///for admin get all suggestions
  Future<List<ErrorReportModel>?> getAllErrorReports() async {
    return null;
  }

  Future<String> saveImage(File image) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }

      final ref =
          _errorReportStorageRef.child('$userID/').child('${userID}_err.jpg');
      String imageUrl = '';
      await ref.putFile(image).whenComplete(() => null);
      imageUrl = await ref.getDownloadURL();
      return imageUrl;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  // Future<void> deleteImageFile(String userId) async {
  //   try {
  //     final ref = _errorReportStorageRef.child(userId);
  //     ref.getDownloadURL().then((value) async {
  //       await ref.delete().whenComplete(() => null);
  //     }).onError((error, stackTrace) => null);
  //   } on Exception catch (e) {
  //     throw CustomException(e.toString());
  //   }
  // }

  Future<void> deleteImage() async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      final ref =
          _errorReportStorageRef.child('$userID/').child('${userID}_err.jpg');
      ref.getDownloadURL().then((value) async {
        await ref.delete().whenComplete(() => null);
      }).onError((error, stackTrace) => null);
      // await ref.delete().whenComplete(() => null);
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<String> updateImage(File image) async {
    try {
      return await saveImage(image);
    } catch (e) {
      rethrow;
    }
  }

  Future<void> addUserErrorReport(ErrorReportModel errorReportModel) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      _errorReportCollectionRef = errorReportInit;

      await _errorReportCollectionRef.doc(userID).set(errorReportModel);
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> updateUserErrorReport(ErrorReportModel errorReportModel) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      _errorReportCollectionRef = errorReportInit;

      await _errorReportCollectionRef
          .doc(userID)
          .set(errorReportModel, SetOptions(merge: true));
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteUserErrorReport(String userID) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      _errorReportCollectionRef = errorReportInit;

      await _errorReportCollectionRef.doc(userID).delete();
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() {
    //
    super.dispose();
  }
}
