import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/call_record_model.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class CallRecordService extends MasterService {
  CallRecordService();

  static final _recordsCollectionRef =
      FirebaseFirestore.instance.collection('callRecords');

  Future<bool> didICallTheDriver(String userID, String driverID) async {
    try {
      if (userID == '' || driverID == '') {
        return false;
      }
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      final data = await _recordsCollectionRef
          .doc(userID)
          .collection('calledPeople')
          .where(
            'driverID',
            isEqualTo: driverID,
          )
          .limit(1)
          .get();
      if (data.docs.isEmpty) return false;

      return data.docs[0].exists;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<List<CallRecordModel>?> getMyCallRecord(String userID) async {
    try {
      if (userID == '') {
        return null;
      }
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      final recordSnapshot = await _recordsCollectionRef
          .doc(userID)
          .collection('calledPeople')
          .get();

      final recordSnapshotData = recordSnapshot.docs;

      if (recordSnapshotData.isEmpty) {
        return null;
      }
      final List<CallRecordModel> userRecords = [];
      for (var record in recordSnapshotData) {
        userRecords.add(
          CallRecordModel.fromMap(
            callRecord: record.data(),
            userID: userID,
          ),
        );
      }
      return userRecords;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  /// for admin get all records
  Future<List<List<CallRecordModel>>?> getAllCallRrecords() async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      final List<List<CallRecordModel>> records = [[]];
      final recordSnapshot = await _recordsCollectionRef.get();

      final recordSnapshotData = recordSnapshot.docs;

      if (recordSnapshotData.isEmpty) {
        return null;
      }

      for (var record in recordSnapshotData) {
        //the id here is the userID we put when we added the records
        final userRecord = await getMyCallRecord(record.id);
        if (userRecord != null && userRecord.isNotEmpty) {
          records.add(userRecord);
        }
      }

      return records;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> addCallRecord(String userID, CallRecordModel record) async {
    try {
      // await _recordsCollectionRef
      //     .doc(userID)
      //     .collection('calledPeople')
      //     .add(record.toMap());
      // print(isThereUser);
      // if (!isThereUser) {
      //   throw Exception('not-logged-in');
      // }
      if (!isOnline) {
        // throw CustomException("You Are Not Online");
        return;
      }
      await addCallRecord2(userID, record);
    } catch (_) {
      rethrow;
    }
  }

  static Future<void> addCallRecord2(
      String userID, CallRecordModel record) async {
    try {
      // if (!MasterService.isOnlineStatic) {
      //   // throw CustomException("You Are Not Online");
      //   return;
      // }
      // if (MasterService.isThereUserStatic) {
      //   throw Exception('not-logged-in');
      // }
      await _recordsCollectionRef
          .doc(userID)
          .collection('calledPeople')
          .add(record.toMap());
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteCallRecord(String userID) async {
    try {
      if (!isOnline) {
        // throw CustomException("You Are Not Online");
        return;
      }
      // if (MasterService.isThereUserStatic) {
      //   throw Exception('not-logged-in');
      // }
      await _recordsCollectionRef.doc(userID).delete();
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() {
    //
    super.dispose();
  }
}
