import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/privacy_model.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class PrivacyService extends MasterService {
  late CollectionReference<PrivacyModel> _privacyCollectionRef;

  PrivacyService() {
    _privacyCollectionRef = FirebaseFirestore.instance
        .collection('privacy')
        .withConverter<PrivacyModel>(
      fromFirestore: (snapshot, _) {
        return PrivacyModel.fromMap(snapshot.data()!);
      },
      toFirestore: (privacy, _) {
        return privacy.toMap();
      },
    );
  }

  Future<PrivacyModel> getPrivacy() async {
    try {
      if (!isOnline) {
        throw CustomException("not-online");
      }
      final snapshot = await _privacyCollectionRef.doc('privacy_Id').get();
      if (snapshot.data() != null) {
        return snapshot.data()!;
      }
      return PrivacyModel.defaultPrivacy;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> addPrivacy(PrivacyModel privacy) async {
    try {
      if (!isOnline) {
        throw CustomException("not-online");
      }
      await _privacyCollectionRef.doc('privacy_Id').set(
            privacy,
            SetOptions(merge: true),
          );
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() {
    //
    super.dispose();
  }
}
