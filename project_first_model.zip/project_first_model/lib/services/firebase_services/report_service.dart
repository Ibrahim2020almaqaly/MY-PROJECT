import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/report_model.dart';
import 'package:project_first_model/services/firebase_services/master_service.dart';

class ReportService extends MasterService {
  late CollectionReference<ReportsModel> _reportsCollectionRef;

  ReportService() {
    _reportsCollectionRef = FirebaseFirestore.instance
        .collection('driversReports')
        .withConverter<ReportsModel>(
      fromFirestore: (snapshot, _) {
        return ReportsModel.fromMap(
          driver: snapshot.data()!,
          driverID: snapshot.id,
        );
      },
      toFirestore: (report, _) {
        return report.toMap();
      },
    );
  }

  Future<ReportsModel?> getDriverReport(String driverID) async {
    try {
      if (driverID == '') {
        return null;
      }
      final reportSnapshot = await _reportsCollectionRef.doc(driverID).get();

      final reportSnapshotData = reportSnapshot.data();

      if (reportSnapshotData == null) {
        return null;
      }
      // final user = userSnapshotData; //.copyWith(userId: userSnapshot.id);
      return reportSnapshotData;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  ///for admin get all reports
  Future<List<ReportsModel>?> getAllReports() async {
    return null;
  }

  Future<void> addDriverReport(String driverID, ReportsModel report) async {
    try {
      if (!isOnline) {
        throw CustomException("not-online");
      }
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _reportsCollectionRef.doc(driverID).set(report);
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> updateDriverReport(String driverID, ReportsModel report) async {
    try {
      if (!isOnline) {
        throw CustomException("not-online");
      }
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _reportsCollectionRef
          .doc(driverID)
          .set(report, SetOptions(merge: true));
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> deleteDriverReport(String driverID) async {
    try {
      if (!isOnline) {
        throw CustomException("not-online");
      }
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      await _reportsCollectionRef.doc(driverID).delete();
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<CustomersReport?> getCustomerReport(
      String driverID, String customerID) async {
    try {
      if (driverID == '' || customerID == '') {
        return null;
      }
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      final reportSnapshot = await _reportsCollectionRef
          .doc(driverID)
          .collection('customersReports')
          .doc(customerID)
          .get();

      final reportSnapshotData = reportSnapshot.data();

      if (reportSnapshotData == null) {
        return null;
      }
      final custReport = CustomersReport.fromMap(
        customer: reportSnapshotData,
        customerID: reportSnapshot.id,
      );
      // final user = userSnapshotData; //.copyWith(userId: userSnapshot.id);
      return custReport;
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  Future<void> addCustomerReport(
      String driverID, CustomersReport customerReport) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      await _reportsCollectionRef
          .doc(driverID)
          .collection('customersReports')
          .doc(customerReport.customerID)
          .set(customerReport.toMap());

      var report = await getDriverReport(driverID);
      if (report != null) {
        final peoCount = report.reportersPeopleCount + 1;
        report = report.copyWith(
          driverID: driverID,
          reportersPeopleCount: peoCount,
        );

        await updateDriverReport(driverID, report);
      }
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  ///we may not need this method but 'JIC'
  Future<void> updateCustomerReport(
      String driverID, CustomersReport customerReport) async {
    try {
      if (!isThereUser) {
        throw Exception('not-logged-in');
      }
      if (!isOnline) {
        throw CustomException("not-online");
      }
      await _reportsCollectionRef
          .doc(driverID)
          .collection('customersReports')
          .doc(customerReport.customerID)
          .set(customerReport.toMap(), SetOptions(merge: true));
    } on Exception catch (e) {
      throw CustomException(e.toString());
    }
  }

  @override
  void dispose() {
    //
    super.dispose();
  }
}
