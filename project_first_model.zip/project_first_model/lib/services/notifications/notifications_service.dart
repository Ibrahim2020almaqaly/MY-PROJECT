// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:flutter_native_timezone/flutter_native_timezone.dart';
// import 'package:rxdart/rxdart.dart';
// import 'package:timezone/data/latest.dart' as tz;
// import 'package:timezone/timezone.dart' as tz;

// class NotificationService {
//   static final _notification = FlutterLocalNotificationsPlugin();
//   static final onNotificationt = BehaviorSubject<String?>();

//   static Future<void> init({bool initScheduled = false}) async {
//     const iosSettings = IOSInitializationSettings();
//     const androidSettings =
//         AndroidInitializationSettings('@mipmap/ic_launcher');

//     const settings =
//         InitializationSettings(android: androidSettings, iOS: iosSettings);
//     // when app is closed
//     final details = await _notification.getNotificationAppLaunchDetails();

//     if (details != null && details.didNotificationLaunchApp) {
//       onNotificationt.add(details.payload);
//     }

//     await _notification.initialize(
//       settings,
//       onSelectNotification: (payload) {
//         onNotificationt.add(payload);
//       },
//     );

//     if (initScheduled) {
//       tz.initializeTimeZones();
//       final locationName = await FlutterNativeTimezone.getLocalTimezone();
//       tz.setLocalLocation(tz.getLocation(locationName));
//     }
//   }

//   static NotificationDetails _notificationDetails({String text = ''}) {
//     // const styleInformation = BigPictureStyleInformation(
//     //   FilePathAndroidBitmap(''),
//     //   largeIcon: FilePathAndroidBitmap(''),
//     // );

//     // const sound = 'soundName.ext';
//     //note when changing the NotificationDetails we need to uninstall the app
//     //or change the channel id
//     final bigTextStyleInformation = BigTextStyleInformation(text);
//     return NotificationDetails(
//       android: AndroidNotificationDetails(
//         'Alarm',
//         'Trip Alarm',
//         channelDescription: 'This notifies the user of the trip time',
//         // styleInformation: styleInformation,
//         importance: Importance.high,
//         priority: Priority.high,
//         playSound: true,
//         enableVibration: true,
//         styleInformation: bigTextStyleInformation,
//         channelShowBadge: true,
//         // sound: RawResourceAndroidNotificationSound(sound.split('.').first),
//         // enableVibration: true,
//         // playSound: false,
//       ),
//       iOS: const IOSNotificationDetails(/*presentSound: false, sound: sound*/),
//     );
//   }

//   static Future<void> showNotification({
//     required int id,
//     required String title,
//     required String body,
//     required String payload,
//   }) async {
//     return _notification.show(
//       id,
//       title,
//       body,
//       _notificationDetails(text: body),
//       payload: payload,
//     );
//   }

//   static Future<void> showScheduledNotification({
//     required int id,
//     required String title,
//     required String body,
//     required String payload,
//     required DateTime scheduledDate,
//   }) async {
//     return await _notification.zonedSchedule(
//       id,
//       title,
//       body,
//       _scheduledDate(scheduledDate),
//       _notificationDetails(text: body),
//       payload: payload,
//       androidAllowWhileIdle: true,
//       uiLocalNotificationDateInterpretation:
//           UILocalNotificationDateInterpretation.absoluteTime,
//       matchDateTimeComponents: DateTimeComponents.dateAndTime,
//     );
//   }

//   // static tz.TZDateTime _scheduledWeekly(Time time, {required List<int> days}) {
//   //   var scheduledDate = _scheduledDaily(time);
//   //   while (!days.contains(scheduledDate.weekday)) {
//   //     scheduledDate = scheduledDate.add(const Duration(days: 1));
//   //   }
//   //   return scheduledDate;
//   // }

//   static tz.TZDateTime _scheduledDate(DateTime dateTime) {
//     final now = tz.TZDateTime.now(tz.local);

//     final scheduledDate = tz.TZDateTime(
//       tz.local,
//       dateTime.year,
//       dateTime.month,
//       dateTime.day,
//       dateTime.hour,
//       dateTime.minute,
//       dateTime.second,
//     );

//     return scheduledDate.isBefore(now)
//         ? scheduledDate.add(const Duration(days: 1))
//         : scheduledDate;
//   }

//   // static tz.TZDateTime _scheduledDaily(Time time) {
//   //   final now = tz.TZDateTime.now(tz.local);
//   //   final scheduledDate = tz.TZDateTime(
//   //     tz.local,
//   //     now.year,
//   //     now.month,
//   //     now.day,
//   //     time.hour,
//   //     time.minute,
//   //     time.second,
//   //   );
//   //   return scheduledDate.isBefore(now)
//   //       ? scheduledDate.add(const Duration(days: 1))
//   //       : scheduledDate;
//   // }

//   static void cancel(int id) async {
//     await _notification.cancel(id);
//   }

//   static void cancelAll() async {
//     await _notification.cancelAll();
//   }
// }
