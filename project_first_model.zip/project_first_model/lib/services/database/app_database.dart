import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/models/alarm_model.dart';
import 'package:project_first_model/models/user_model.dart';

class AppDatabase {
  AppDatabase.ensureInitialized();

  static final AppDatabase instance = AppDatabase._init();
  static Database? _database;

  AppDatabase._init();

  AppDatabase();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('user.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(
      path,
      version: 2,
      onCreate: _createDB,
      onConfigure: _onConfigure,
      onUpgrade: _onUpgrade,
    );
  }

  ///Enable Foreign Key To The Database
  static Future _onConfigure(Database db) async {
    await db.execute('PRAGMA foreign_keys = ON');
  }

  static Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    for (var i = oldVersion + 1; i <= newVersion; i++) {
      await db.execute(AlarmModel.updateTableNotification);
    }
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute(UserModel.createTableUserModel);
    await db.execute(AlarmModel.createTableNotification);
  }

  /// Function to insert to table,
  /// first argument name of the table take from the Models,
  /// data have to be instance from class model
  /// followed with toMap() function
  Future<int> insertItem(String tableName, Map<String, dynamic> data) async {
    if (tableName.isEmpty) {
      throw CustomException('tableName can not be empty or null');
    }
    int id = -1;
    final db = await instance.database;
    try {
      id = await db.insert(tableName, data,
          conflictAlgorithm: ConflictAlgorithm.replace);
    } on DatabaseException catch (err) {
      // var isExist = await databaseExists(_database!.path);
      // if (!isExist) {
      // } else if (err.isNoSuchTableError(tableName)) {
      // } else if (err.isUniqueConstraintError()) {}
      throw CustomException(err.toString());
    }

    // notifyListeners();
    return id;
  }

  Future<List<Map<String, dynamic>>> getItems(String tableName) async {
    if (tableName.isEmpty) {
      throw 'Table Name can not be empty or null';
    }

    final db = await instance.database;
    List<Map<String, dynamic>> recordList = [];

    try {
      List<Map<String, dynamic>> maps = await db.query(tableName);
      recordList = maps;
    } on DatabaseException catch (err) {
      var isExist = await databaseExists(_database!.path);
      if (!isExist) {}
      if (err.isNoSuchTableError(tableName)) {}

      if (err.isOpenFailedError()) {}

      if (err.isDatabaseClosedError()) {}

      if (err.isReadOnlyError()) {}
    }

    return recordList;
  }

  Future<void> updateItem(
      String tableName, String columnNameId, Map<String, dynamic> data) async {
    if (tableName.isEmpty) {
      throw CustomException('tableName cant not be empty or null');
    }
    if (columnNameId.isEmpty) {
      throw CustomException('columnNameId cant not be empty or null');
    }

    final db = await instance.database;
    try {
      await db.update(tableName, data,
          where: '$columnNameId = ?',
          whereArgs: [data[columnNameId]],
          conflictAlgorithm: ConflictAlgorithm.replace);
    } on DatabaseException catch (err) {
      // var isExist = await databaseExists(_database!.path);
      // if (!isExist) {}
      // if (err.isNoSuchTableError(tableName)) {}
      // if (err.isUniqueConstraintError()) {}
      // if (err.isNotNullConstraintError()) {}
      throw CustomException(err.toString());
    }

    // notifyListeners();
  }

  Future<void> deleteItem(
      String tableName, String columnNameId, var idItem) async {
    if (tableName.isEmpty) {
      throw CustomException('tableName can not be empty or null');
    }

    if (columnNameId.isEmpty) {
      throw CustomException('columnNameId can not be empty or null');
    }

    if (idItem == null) {
      throw CustomException('idItem can not be null');
    }

    final db = await instance.database;
    try {
      await db.delete(
        tableName,
        where: '$columnNameId = ?',
        whereArgs: [idItem],
      );
    } on DatabaseException catch (err) {
      // if (err.isNoSuchTableError()) {}
      throw CustomException(err.toString());
    }
  }

  /// used to retrieve custom data and rows
  Future<List<Map<String, dynamic>>> getItemsFiltered(
    String tableName, {
    List<String>? columnName,
    required String whereColumnName,
    required var filter,
  }) async {
    if (tableName.isEmpty) {
      throw CustomException('tableName can not be empty or null');
    }

    if (filter == null) {
      throw CustomException('filter can not be null');
    }

    if (whereColumnName.isEmpty) {
      throw CustomException('whereColumnName can not be empty or null');
    }

    final db = await instance.database;
    List<Map<String, dynamic>> recordList = [];

    try {
      List<Map<String, dynamic>> maps = await db.query(tableName,
          columns: columnName,
          where: '$whereColumnName = ?',
          whereArgs: [filter]);
      recordList = maps;
    } on DatabaseException catch (err) {
      // var isExist = await databaseExists(_database!.path);
      // if (!isExist) {}
      // if (err.isNoSuchTableError(tableName)) {}

      // if (err.isOpenFailedError()) {}

      // if (err.isDatabaseClosedError()) {}

      // if (err.isReadOnlyError()) {}
      throw CustomException(err.toString());
    }
    return recordList;
  }

  ///
  Future<List<Map<String, dynamic>>> getItemsByQuery(String query) async {
    if (query.isEmpty) {
      throw CustomException('query can not be empty or null');
    }
    final db = await instance.database;
    List<Map<String, dynamic>> list = [{}];
    try {
      final record = await db.rawQuery(query);
      list = record;
    } on DatabaseException catch (err) {
      // if (err.isSyntaxError()) {}
      throw CustomException(err.toString());
    }
    return list;
  }
}
