class RegionModel {
  final String name;

  static final _regions = {
    {
      'name': 'عمران',
    },
    {
      'name': 'الضالع',
    },
    {
      'name': 'البيضاء',
    },
    {
      'name': 'الحديدة',
    },
    {
      'name': 'الجوف',
    },
    {
      'name': 'المحويت',
    },
    {
      'name': 'أمانة العاصمة',
    },
    {
      'name': 'ذمار',
    },
    {
      'name': 'حجة',
    },
    {
      'name': 'إب',
    },
    {
      'name': 'مأرب',
    },
    {
      'name': 'ريمة',
    },
    {
      'name': 'صعدة',
    },
    {
      'name': 'صنعاء',
    },
    {
      'name': 'تعز',
    },
    {
      'name': 'عدن',
    },
    {
      'name': 'أبين',
    },
    {
      'name': 'المهرة',
    },
    {
      'name': 'حضرموت',
    },
    {
      'name': 'أرخبيل سقطرى',
    },
    {
      'name': 'لحج',
    },
    {
      'name': 'شبوة',
    },
  };

  static final regionsList =
      _regions.map((item) => RegionModel.fromJson(item).name).toList();

  RegionModel(this.name);

  static Future<List<RegionModel>> regionsSuggestions(String query) async {
    return _regions.map((item) => RegionModel.fromJson(item)).where((city) {
      final cityLowerCase = city.name.toLowerCase();
      final queryLowerCase = query.toLowerCase();

      return cityLowerCase.contains(queryLowerCase);
    }).toList();
  }

  static RegionModel fromJson(Map<String, dynamic> json) {
    return RegionModel(
      json['name'],
    );
  }
}
