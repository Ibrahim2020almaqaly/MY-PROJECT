import 'dart:convert';

import 'package:equatable/equatable.dart';

class TripRatingModel extends Equatable {
  final String tripID;
  final int ratingPeopleCount;
  final int starsCount;
  final double starsRatio;

  const TripRatingModel({
    required this.tripID,
    required this.ratingPeopleCount,
    required this.starsCount,
    required this.starsRatio,
  });

  static TripRatingModel get defaultRate {
    return const TripRatingModel(
      tripID: '',
      ratingPeopleCount: 0,
      starsCount: 0,
      starsRatio: 0.0,
    );
  }

  TripRatingModel copyWith({
    String? tripID,
    int? ratingPeopleCount,
    int? starsCount,
    double? starsRatio,
  }) {
    return TripRatingModel(
      tripID: tripID ?? this.tripID,
      ratingPeopleCount: ratingPeopleCount ?? this.ratingPeopleCount,
      starsCount: starsCount ?? this.starsCount,
      starsRatio: starsRatio ?? this.starsRatio,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'tripID': tripID,
      'ratingPeopleCount': ratingPeopleCount,
      'starsCount': starsCount,
      'starsRatio': starsRatio,
    };
  }

  factory TripRatingModel.fromMap({
    required Map<String, dynamic> tripRate,
    String? tripID,
  }) {
    return TripRatingModel(
      tripID: tripID ?? '',
      ratingPeopleCount:
          int.tryParse(tripRate['ratingPeopleCount'].toString()) ?? 0,
      starsCount: int.tryParse(tripRate['starsCount'].toString()) ?? 0,
      starsRatio: double.tryParse(tripRate['starsRatio'].toString()) ?? 0.0,
    );
  }

  String toJson() => json.encode(toMap());

  factory TripRatingModel.fromJson(String source) =>
      TripRatingModel.fromMap(tripRate: json.decode(source));

  @override
  String toString() {
    return 'TripRatingModel(tripID: $tripID, ratingPeopleCount: $ratingPeopleCount, starsCount: $starsCount, starsRatio: $starsRatio)';
  }

  @override
  List<Object> get props => [
        tripID,
        ratingPeopleCount,
        starsCount,
        starsRatio,
      ];
}

class DriverRatingModel extends Equatable {
  final String driverID;
  final String driverName;
  final String driverPic;
  final String region;
  // final CustomerRating driverRates;
  final int ratingPeopleCount;
  final int starsCount;
  final double starsRatio;
  final int tripsCount;

  const DriverRatingModel({
    required this.driverID,
    required this.driverName,
    required this.driverPic,
    required this.region,
    required this.ratingPeopleCount,
    required this.starsCount,
    required this.starsRatio,
    required this.tripsCount,
  });

  static DriverRatingModel get defaultRate {
    return const DriverRatingModel(
      driverID: '',
      driverName: '',
      driverPic: '',
      region: '',
      ratingPeopleCount: 0,
      starsCount: 0,
      starsRatio: 0.0,
      tripsCount: 0,
    );
  }

  static DriverRatingModel get testRate {
    return const DriverRatingModel(
      driverID: '',
      driverName: '',
      driverPic: '',
      region: '',
      ratingPeopleCount: 300,
      starsCount: 500,
      starsRatio: 4.8,
      tripsCount: 300,
    );
  }

  DriverRatingModel copyWith({
    String? driverID,
    String? driverName,
    String? driverPic,
    String? region,
    int? ratingPeopleCount,
    int? starsCount,
    double? starsRatio,
    int? tripsCount,
  }) {
    return DriverRatingModel(
      driverID: driverID ?? this.driverID,
      driverName: driverName ?? this.driverName,
      driverPic: driverPic ?? this.driverPic,
      region: region ?? this.region,
      ratingPeopleCount: ratingPeopleCount ?? this.ratingPeopleCount,
      starsCount: starsCount ?? this.starsCount,
      starsRatio: starsRatio ?? this.starsRatio,
      tripsCount: tripsCount ?? this.tripsCount,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'driverID': driverID,
      'driverName': driverName,
      'driverPic': driverPic,
      'region': region,
      'ratingPeopleCount': ratingPeopleCount,
      'starsCount': starsCount,
      'starsRatio': starsRatio,
      'tripsCount': tripsCount,
    };
  }

  factory DriverRatingModel.fromMap({
    required Map<String, dynamic> rating,
    required String driverID,
  }) {
    final ratio = double.tryParse(rating['starsRatio'].toString()) ?? 0.0;
    return DriverRatingModel(
      driverID: driverID, //rating['driverID'] ?? '',
      driverName: rating['driverName'] ?? '',
      driverPic: rating['driverPic'] ?? '',
      region: rating['region'] ?? '',
      ratingPeopleCount:
          int.tryParse(rating['ratingPeopleCount'].toString()) ?? 0,
      starsCount: int.tryParse(rating['starsCount'].toString()) ?? 0,
      starsRatio: ratio.isNaN ? 0.0 : ratio,
      tripsCount: int.tryParse(rating['tripsCount'].toString()) ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory DriverRatingModel.fromJson(String source) =>
      DriverRatingModel.fromMap(
        rating: json.decode(source),
        driverID: '',
      );

  @override
  String toString() {
    return 'DriverRatingModel(driverID: $driverID, driverName: $driverName, driverPic: $driverPic, region: $region, ratingPeopleCount: $ratingPeopleCount, starsCount: $starsCount, starsRatio: $starsRatio, tripsCount: $tripsCount)';
  }

  @override
  List<Object> get props {
    return [
      driverID,
      driverName,
      driverPic,
      region,
      ratingPeopleCount,
      starsCount,
      starsRatio,
      tripsCount,
    ];
  }
}

class CustomerRatingModel extends Equatable {
  final String customerID;
  final int starNumber;

  const CustomerRatingModel({
    required this.customerID,
    required this.starNumber,
  });

  static CustomerRatingModel get defaultCustomerRate {
    return const CustomerRatingModel(
      customerID: '',
      starNumber: -1,
    );
  }

  bool get isDefault {
    return starNumber == -1 || customerID == '';
  }

  CustomerRatingModel copyWith({
    String? customerID,
    int? starNumber,
  }) {
    return CustomerRatingModel(
      customerID: customerID ?? this.customerID,
      starNumber: starNumber ?? this.starNumber,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'customerID': customerID,
      'starNumber': starNumber,
    };
  }

  factory CustomerRatingModel.fromMap(
      {required Map<String, dynamic> map, required String custID}) {
    return CustomerRatingModel(
      customerID: custID, //map['customerID'] ?? '',
      starNumber: int.tryParse(map['starNumber'].toString()) ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory CustomerRatingModel.fromJson(String source, String sourceID) =>
      CustomerRatingModel.fromMap(map: json.decode(source), custID: sourceID);

  @override
  String toString() =>
      'CustomerRating(customerID: $customerID, starNumber: $starNumber)';

  @override
  List<Object> get props => [customerID, starNumber];
}
