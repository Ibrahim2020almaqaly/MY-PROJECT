import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import 'package:project_first_model/helpers/convert_to_date_time.dart';

enum DestType {
  from,
  to,
  secondary,
}

// class MasterTrip extends Equatable {
//   final String tripId;
//   final String driverName;
//   final String driverPic;
//   // final String phoneNumber;
//   final DateTime fullDateTime;
//   final String from;
//   final String to;
//   final int ratingPeopleCount;
//   final double ratingRatio;
//   final String userId;
//   const MasterTrip({
//     this.tripId = '',
//     required this.driverName,
//     this.driverPic = '',
//     // required this.phoneNumber,
//     required this.fullDateTime,
//     required this.from,
//     required this.to,
//     required this.ratingPeopleCount,
//     required this.ratingRatio,
//     this.userId = '',
//   });
//   static MasterTrip get defaultTrip {
//     return MasterTrip(
//       tripId: '',
//       driverName: 'Nour Addin',
//       // phoneNumber: '777853116',
//       fullDateTime: DateTime.now(),
//       from: '',
//       to: '',
//       driverPic: '',
//       ratingPeopleCount: -1,
//       ratingRatio: -1.0,
//     );
//   }
//   static MasterTrip get testTrip {
//     return MasterTrip(
//       tripId: '',
//       driverName: 'Nour Addin Hussien Ali',
//       // phoneNumber: '777853116',
//       fullDateTime: DateTime.now(),
//       from: 'الحديدة',
//       to: 'حضرموت',
//       driverPic: '',
//       ratingPeopleCount: -1,
//       ratingRatio: 4.1,
//     );
//   }
//   Map<String, dynamic> toMap() {
//     return {
//       'tripId': tripId,
//       'driverName': driverName,
//       'driverPic': driverPic,
//       // 'phoneNumber': phoneNumber,
//       'fullDateTime': fullDateTime.millisecondsSinceEpoch,
//       'from': from,
//       'to': to,
//       'ratingPeopleCount': ratingPeopleCount,
//       'ratingRatio': ratingRatio,
//       'userId': userId,
//     };
//   }
//   factory MasterTrip.fromMap(
//       {required Map<String, dynamic> trip, String id = ''}) {
//     return MasterTrip(
//       tripId: id,
//       driverName: trip['driverName'] ?? '',
//       driverPic: trip['driverPic'],
//       // phoneNumber: trip['phoneNumber'] ?? '',
//       fullDateTime: DateTime.fromMillisecondsSinceEpoch(trip['fullDateTime']),
//       from: trip['from'] ?? '',
//       to: trip['to'] ?? '',
//       ratingPeopleCount: trip['ratingPeopleCount']?.toInt() ?? 0,
//       ratingRatio: trip['ratingRatio']?.toDouble() ?? 0.0,
//       userId: trip['userId'] ?? '',
//     );
//   }
//   String toJson() => json.encode(toMap());
//   factory MasterTrip.fromJson(String source) =>
//       MasterTrip.fromMap(trip: json.decode(source));
//   MasterTrip copyWith({
//     String? tripId,
//     String? driverName,
//     String? driverPic,
//     // String? phoneNumber,
//     DateTime? fullDateTime,
//     String? from,
//     String? to,
//     int? ratingPeopleCount,
//     double? ratingRatio,
//     String? userId,
//   }) {
//     return MasterTrip(
//       tripId: tripId ?? this.tripId,
//       driverName: driverName ?? this.driverName,
//       driverPic: driverPic ?? this.driverPic,
//       // phoneNumber: phoneNumber ?? this.phoneNumber,
//       fullDateTime: fullDateTime ?? this.fullDateTime,
//       from: from ?? this.from,
//       to: to ?? this.to,
//       ratingPeopleCount: ratingPeopleCount ?? this.ratingPeopleCount,
//       ratingRatio: ratingRatio ?? this.ratingRatio,
//       userId: userId ?? this.userId,
//     );
//   }
//   @override
//   String toString() {
//     return 'MasterTrip(tripId: $tripId, driverName: $driverName, driverPic: $driverPic, phoneNumber: "phoneNumber", fullDateTime: $fullDateTime, from: $from, to: $to, ratingPeopleCount: $ratingPeopleCount, ratingRatio: $ratingRatio, userId: $userId)';
//   }
//   @override
//   List<Object?> get props {
//     return [
//       tripId,
//       driverName,
//       driverPic,
//       // phoneNumber,
//       fullDateTime,
//       from,
//       to,
//       ratingPeopleCount,
//       ratingRatio,
//       userId,
//     ];
//   }
// }

class TripModel extends Equatable {
  final String tripId;
  final String driverName;
  final String driverPic;
  // final String phoneNumber;
  final DateTime fullDateTime;
  final String from;
  final String to;
  final int ratingPeopleCount;
  final double ratingRatio;
  final String userId;
  final DateTime tripDate;
  final TimeOfDay tripTime;
  final double tripPrice;
  final bool trusteeship;
  final List<String> secondaryDest;
  final List<String> fromSecond;
  final String notes;
  final String carPic1;
  final String carPic2;

  const TripModel({
    required this.tripId,
    required this.driverName,
    required this.driverPic,
    // phoneNumber,
    required this.tripDate,
    required this.tripTime,
    required this.tripPrice,
    required this.trusteeship,
    required this.fullDateTime,
    required this.from,
    required this.to,
    required this.secondaryDest,
    this.fromSecond = const [],
    this.notes = '',
    this.carPic1 = '',
    this.carPic2 = '',
    required this.userId,
    required this.ratingPeopleCount,
    required this.ratingRatio,
  });

  static TripModel get defaultTrip {
    return TripModel(
      tripId: '',
      driverName: '',
      // phoneNumber: '',
      tripDate: DateTime.now(),
      tripTime: TimeOfDay.now(),
      fullDateTime: DateTime.now(),
      tripPrice: 0.0,
      trusteeship: false,
      from: '',
      to: '',
      secondaryDest: const [],
      notes: '',
      driverPic: '',
      carPic1: '',
      carPic2: '',
      ratingPeopleCount: -1,
      ratingRatio: -1.0,
      userId: '',
      fromSecond: const [],
    );
  }

  static TripModel get testTrip {
    return TripModel(
      tripId: '',
      driverName: 'نور الدين خليل',
      // phoneNumber: '777853116',
      tripDate: DateTime.now(),
      tripTime: TimeOfDay.now(),
      fullDateTime: DateTime.now(),
      tripPrice: 3000.0,
      trusteeship: true,
      from: 'إب',
      to: 'حضرموت',
      secondaryDest: const [
        'Ibb',
        'Ibb',
        'Ibb',
        'Ibb',
        'Ibb',
        'Ibb',
        'Ibb',
        'Ibb',
        'Ibb',
      ],
      notes: 'ioeroigoeioiernknvaoihvoighioqhiqhhhfiohhhffbbiihwiofhoihwfohfhw',
      driverPic: '',
      carPic1: '',
      carPic2: '',
      ratingPeopleCount: 209990,
      ratingRatio: 4.1,
      userId: '',
      fromSecond: const ['Ibb'],
    );
  }

  List<String> _makeSearchField(String from, List<String> second) {
    List<String> secList = [];
    secList.add(from);
    if (second.isNotEmpty) {
      secList.addAll(second);
    }
    return secList;
  }

  Map<String, dynamic> toMap() {
    return {
      // 'tripId': tripId,
      'driverName': driverName,
      'driverPic': driverPic,
      // 'phoneNumber': phoneNumber,
      'tripDate': tripDate.millisecondsSinceEpoch,
      'fullDateTime': fullDateTime.millisecondsSinceEpoch,
      'tripTime': DateTimeHelpers.convertTimeOfDayToString(tripTime),
      'tripPrice': tripPrice,
      'trusteeship': trusteeship,
      'from': from,
      'to': to,
      'secondaryDest': secondaryDest,
      'fromSecond': _makeSearchField(from, secondaryDest),
      'notes': notes,
      'carPic1': carPic1,
      'carPic2': carPic2,
      'userId': userId,
      'ratingPeopleCount': ratingPeopleCount,
      'ratingRatio': ratingRatio,
    };
  }

  factory TripModel.fromMap(
      {required Map<String, dynamic> trip, String id = ''}) {
    return TripModel(
      tripId: id,
      driverName: trip['driverName'] ?? '',
      driverPic: trip['driverPic'] ?? '',
      // phoneNumber: trip['phoneNumber'],
      tripDate: DateTime.fromMillisecondsSinceEpoch((trip['tripDate'])),
      fullDateTime: DateTime.fromMillisecondsSinceEpoch((trip['fullDateTime'])),
      tripTime: DateTimeHelpers.convertToTimeOfDayV2(trip['tripTime']),
      tripPrice: trip['tripPrice']?.toDouble() ?? 0.0,
      trusteeship: trip['trusteeship'] ?? false,
      from: trip['from'] ?? '',
      to: trip['to'] ?? '',
      secondaryDest: List<String>.from(trip['secondaryDest'] ?? []),
      fromSecond: List<String>.from(trip['fromSecond'] ?? []),
      notes: trip['notes'] ?? '',
      carPic1: trip['carPic1'] ?? '',
      carPic2: trip['carPic2'] ?? '',
      userId: trip['userId'] ?? '',
      ratingPeopleCount: trip['ratingPeopleCount']?.toInt() ?? 0,
      ratingRatio: double.tryParse(trip['ratingRatio'].toString()) ?? 0.0,
    );
  }

  String toJson() => json.encode(toMap());

  factory TripModel.fromJson(String source, id) =>
      TripModel.fromMap(trip: json.decode(source), id: id);

  TripModel copyWith({
    String? tripId,
    String? driverName,
    String? driverPic,
    // String? phoneNumber,
    DateTime? fullDateTime,
    String? from,
    String? to,
    int? ratingPeopleCount,
    double? ratingRatio,
    String? userId,
    DateTime? tripDate,
    TimeOfDay? tripTime,
    double? tripPrice,
    bool? trusteeship,
    List<String>? secondaryDest,
    List<String>? fromSecond,
    String? notes,
    String? carPic1,
    String? carPic2,
  }) {
    return TripModel(
      tripId: tripId ?? this.tripId,
      userId: userId ?? this.userId,
      driverName: driverName ?? this.driverName,
      driverPic: driverPic ?? this.driverPic,
      from: from ?? this.from,
      fullDateTime: fullDateTime ?? this.fullDateTime,
      // phoneNumber: phoneNumber ?? this.phoneNumber,
      ratingPeopleCount: ratingPeopleCount ?? this.ratingPeopleCount,
      ratingRatio: ratingRatio ?? this.ratingRatio,
      to: to ?? this.to,
      tripDate: tripDate ?? this.tripDate,
      tripTime: tripTime ?? this.tripTime,
      tripPrice: tripPrice ?? this.tripPrice,
      trusteeship: trusteeship ?? this.trusteeship,
      secondaryDest: secondaryDest ?? this.secondaryDest,
      fromSecond: fromSecond ?? this.fromSecond,
      notes: notes ?? this.notes,
      carPic1: carPic1 ?? this.carPic1,
      carPic2: carPic2 ?? this.carPic2,
    );
  }

  @override
  bool get stringify => true;

  @override
  List<Object> get props {
    return [
      tripId,
      driverName,
      driverPic,
      fullDateTime,
      from,
      to,
      ratingPeopleCount,
      ratingRatio,
      userId,
      tripDate,
      tripTime,
      tripPrice,
      trusteeship,
      secondaryDest,
      fromSecond,
      notes,
      carPic1,
      carPic2,
    ];
  }
}
