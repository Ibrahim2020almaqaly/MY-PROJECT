import 'dart:convert';

import 'package:equatable/equatable.dart';

class DisabledUserModel extends Equatable {
  final String userId;
  final String phoneNumber;
  final bool disable;

  const DisabledUserModel({
    required this.userId,
    required this.phoneNumber,
    required this.disable,
  });

  DisabledUserModel copyWith({
    String? userId,
    String? phoneNumber,
    bool? disable,
  }) {
    return DisabledUserModel(
      userId: userId ?? this.userId,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      disable: disable ?? this.disable,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'userId': userId,
      'phoneNumber': phoneNumber,
      'disable': disable,
    };
  }

  factory DisabledUserModel.fromMap({
    required String userId,
    required Map<String, dynamic> user,
  }) {
    return DisabledUserModel(
      userId: userId, //user['userId'] ?? '',
      phoneNumber: user['phoneNumber'] ?? '',
      disable: user['disable'] ?? false,
    );
  }

  String toJson() => json.encode(toMap());

  factory DisabledUserModel.fromJson(String id, String source) =>
      DisabledUserModel.fromMap(userId: id, user: json.decode(source));

  @override
  String toString() =>
      'DisabledUserModel(userId: $userId, phoneNumber: $phoneNumber)';

  @override
  List<Object> get props => [userId, phoneNumber];
}
