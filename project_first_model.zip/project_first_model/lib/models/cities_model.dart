class CityModel {
  final String name;

  static final _citiesMap = {
    {
      "city": "صنعاء",
      "admin_name": "أمانة العاصمة",
      "capital": "primary",
    },
    {
      "city": "تعز",
      "admin_name": "تعز",
      "capital": "admin",
    },
    {
      "city": "الحديدة",
      "admin_name": "الحديدة",
      "capital": "admin",
    },
    {
      "city": "عدن",
      "admin_name": "عدن",
      "capital": "admin",
    },
    {
      "city": "إب",
      "admin_name": "إب",
      "capital": "admin",
    },
    {
      "city": "ذمار",
      "admin_name": "ذمار",
      "capital": "admin",
    },
    {
      "city": "المكلا",
      "admin_name": "حضرموت",
      "capital": "admin",
    },
    {
      "city": "تريم",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "الشيخ عثمان",
      "admin_name": "عدن",
      "capital": "minor",
    },
    {
      "city": "زنجبار",
      "admin_name": "أبين",
      "capital": "admin",
    },
    {
      "city": "صعدة",
      "admin_name": "صعدة",
      "capital": "admin",
    },
    {
      "city": "سيئون",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "الشحر",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "زبيد",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "حجة",
      "admin_name": "حجة",
      "capital": "admin",
    },
    {
      "city": "باجل",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "رداع",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "بيت الفقيه",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "القاعدة",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "البيضاء",
      "admin_name": "البيضاء",
      "capital": "admin",
    },
    {
      "city": "عتق",
      "admin_name": "شبوة",
      "capital": "admin",
    },
    {
      "city": "يريم",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "لحج",
      "admin_name": "لحج",
      "capital": "admin",
    },
    {
      "city": "جعِر",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "الغيضة",
      "admin_name": "المهرة",
      "capital": "admin",
    },
    {
      "city": "معبر",
      "admin_name": "ذمار",
      "capital": "minor",
    },
    {
      "city": "مأرب",
      "admin_name": "مأرب",
      "capital": "admin",
    },
    {
      "city": "الديس الشرقية",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "جبلة",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "خمير",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "المخا",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "ريده",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "حديبو",
      "admin_name": "أرخبيل سقطرى",
      "capital": "admin",
    },
    {
      "city": "المحويت",
      "admin_name": "المحويت",
      "capital": "admin",
    },
    {
      "city": "الروضة",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "ضوران الديدة",
      "admin_name": "ذمار",
      "capital": "minor",
    },
    {
      "city": "قلنسية",
      "admin_name": "أرخبيل سقطرى",
      "capital": "minor",
    },
    {
      "city": "مركز المديرية",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "سيحوت",
      "admin_name": "المهرة",
      "capital": "minor",
    },
    {
      "city": "كريتر",
      "admin_name": "عدن",
      "capital": "minor",
    },
    {
      "city": "التواهي",
      "admin_name": "عدن",
      "capital": "minor",
    },
    {
      "city": "المنصورة",
      "admin_name": "عدن",
      "capital": "minor",
    },
    {
      "city": "المعلا",
      "admin_name": "عدن",
      "capital": "minor",
    },
    {
      "city": "المسالية",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "عمران",
      "admin_name": "عمران",
      "capital": "admin",
    },
    {
      "city": "الجبين",
      "admin_name": "ريمة",
      "capital": "admin",
    },
    {
      "city": "الضالع",
      "admin_name": "الضالع",
      "capital": "admin",
    },
    {
      "city": "الحزم",
      "admin_name": "الجوف",
      "capital": "admin",
    },
    {
      "city": "المسراخ",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "خور مكسر",
      "admin_name": "عدن",
      "capital": "minor",
    },
    {
      "city": "بني النهاري",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "ذي سفال",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "قرية القبيل",
      "admin_name": "أمانة العاصمة",
      "capital": "minor",
    },
    {
      "city": "الروضة",
      "admin_name": "أمانة العاصمة",
      "capital": "minor",
    },
    {
      "city": "الحوراء",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "خيران",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "بني العوام",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "المحابشة",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "دار الناصر",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "الربوع",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "سوق شمار",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "العين",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "المخادر",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "الصلو",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "قرية الدعيس",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "السياني",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "وضرة",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "ظلمة العليا",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "المفتاح",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "حيفان",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "يفرس",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "العدين",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "الرونة",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "الشغدرية",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "السرير",
      "admin_name": "الضالع",
      "capital": "minor",
    },
    {
      "city": "كسمه",
      "admin_name": "ريمة",
      "capital": "minor",
    },
    {
      "city": "سوق الربوع",
      "admin_name": "ذمار",
      "capital": "minor",
    },
    {
      "city": "النشمة",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "وشحة",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "السادة",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "الشاهل",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "خولان ,عفار",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "بيت عذاقة",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "الرضائي",
      "admin_name": "إب",
      "capital": "minor",
    },
    {
      "city": "الجربة",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "الدن",
      "admin_name": "ذمار",
      "capital": "minor",
    },
    {
      "city": "رصد",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "مدينة لبعوس",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "الجميمة",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "بني حجاج",
      "admin_name": "المحويت",
      "capital": "minor",
    },
    {
      "city": "المرواح",
      "admin_name": "المحويت",
      "capital": "minor",
    },
    {
      "city": "حزم العدين",
      "admin_name": "إبّ",
      "capital": "minor",
    },
    {
      "city": "الرضمة",
      "admin_name": "إبّ",
      "capital": "minor",
    },
    {
      "city": "الصفقين",
      "admin_name": "المحويت",
      "capital": "minor",
    },
    {
      "city": "النادرة",
      "admin_name": "إبّ",
      "capital": "minor",
    },
    {
      "city": "شهارة القيس",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "المدان",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "التربة",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "الطويلة",
      "admin_name": "المحويت",
      "capital": "minor",
    },
    {
      "city": "صوير",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "الدمنة",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "الرمادي",
      "admin_name": "إبّ",
      "capital": "minor",
    },
    {
      "city": "بني بكر",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "حبابة",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "شبام",
      "admin_name": "المحويت",
      "capital": "minor",
    },
    {
      "city": "المغلاف",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "المنصورية",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "الحدية",
      "admin_name": "ريمة",
      "capital": "minor",
    },
    {
      "city": "سحب",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "المغاربة",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "الرجم",
      "admin_name": "المحويت",
      "capital": "minor",
    },
    {
      "city": "الضحي",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "رحاب",
      "admin_name": "إبّ",
      "capital": "minor",
    },
    {
      "city": "كشر",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "الحسين",
      "admin_name": "الضالع",
      "capital": "minor",
    },
    {
      "city": "شرس",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "نجد الجماعي",
      "admin_name": "إبّ",
      "capital": "minor",
    },
    {
      "city": "حبور",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "بيت السيد",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "متوح",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "الزيدية",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "الضلع",
      "admin_name": "ريمة",
      "capital": "minor",
    },
    {
      "city": "القناوص",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "رقاب",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "السودة",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "ماوية",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "الزهرة",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "العرة",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "المراوعة",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "الزاهر",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "حيس",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "السوق الجديد",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "ملاح",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "السوادية",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "الناصرة",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "الخراب",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "السخنة",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "حمام دمت",
      "admin_name": "الضالع",
      "capital": "minor",
    },
    {
      "city": "كعدينة",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "مغبنة",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "الجراحي",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "ذي ناعم",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "مستباء",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "الخانق",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "الروض",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "الزاهر",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "حدة",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "الجمعة",
      "admin_name": "ذمار",
      "capital": "minor",
    },
    {
      "city": "حمام علي",
      "admin_name": "ذمار",
      "capital": "minor",
    },
    {
      "city": "سيان",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "غيمان",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "قعطبة",
      "admin_name": "الضالع",
      "capital": "minor",
    },
    {
      "city": "ضوران",
      "admin_name": "الضالع",
      "capital": "minor",
    },
    {
      "city": "زخم",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "البريقة",
      "admin_name": "عدن",
      "capital": "minor",
    },
    {
      "city": "العقبة",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "العوبلي",
      "admin_name": "الضالع",
      "capital": "minor",
    },
    {
      "city": "سوق الخميس",
      "admin_name": "السدة",
      "capital": "minor",
    },
    {
      "city": "مناخة",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "الخميس",
      "admin_name": "المحويت",
      "capital": "minor",
    },
    {
      "city": "ذي جلال",
      "admin_name": "الضالع",
      "capital": "minor",
    },
    {
      "city": "بدبدة",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "حبيل الريدة",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "الميفعة",
      "admin_name": "ذمار",
      "capital": "minor",
    },
    {
      "city": "ساقين",
      "admin_name": "السدة",
      "capital": "minor",
    },
    {
      "city": "حرض",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "عبال",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "جحانة",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "كرش",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "ذيبين",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "متنه",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "زراجة",
      "admin_name": "ذمار",
      "capital": "minor",
    },
    {
      "city": "عبس",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "التهيته",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "اللحية",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "الدريهمي",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "وعلان",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "القفلة",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "النجد",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "رجوزة",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "الحبلين",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "الحيفة",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "بيت مران",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "الغيل",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "العشة",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "المتون",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "حبيل جبر",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "بيحان",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "الشرقية",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "الخوخة",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "حوث",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "السوادية",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "المنيرة",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "مكيراس",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "موزع",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "المسيمير",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "الحرجة",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "الصومعة",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "سهيل شبام",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "لودر",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "القريشية",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "حريب",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "الحميدات",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "الصليف",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "الغيلة",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "الوادي أبين",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "جبن",
      "admin_name": "الضالع",
      "capital": "minor",
    },
    {
      "city": "الحزم",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "طور البحاح",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "الحشوه",
      "admin_name": "السدة",
      "capital": "minor",
    },
    {
      "city": "مودية",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "حبان",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "المعوضة",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "الحجب",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "المصلوب",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "ميدي",
      "admin_name": "حجة",
      "capital": "minor",
    },
    {
      "city": "المديد",
      "admin_name": "صنعاء",
      "capital": "minor",
    },
    {
      "city": "غيل با وزير",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "القطن",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "مرباط",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "الأقطع",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "كمران",
      "admin_name": "الحديدة",
      "capital": "minor",
    },
    {
      "city": "الجديده",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "الملاح",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "جيشان",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "سرار",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "حريضه",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "عمد",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "نصاب",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "مدغل",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "الحرف",
      "admin_name": "عمران",
      "capital": "minor",
    },
    {
      "city": "العمود",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "الريدة",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "البثينة",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "الشط",
      "admin_name": "لحج",
      "capital": "minor",
    },
    {
      "city": "ذباب",
      "admin_name": "تعز",
      "capital": "minor",
    },
    {
      "city": "خورة",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "عسيلان",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "الحصون",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "المحفد",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "رحبه",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "ساه",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "مسورة",
      "admin_name": "البيضاء",
      "capital": "minor",
    },
    {
      "city": "مجزر",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "كتاف",
      "admin_name": "السدة",
      "capital": "minor",
    },
    {
      "city": "أسداس",
      "admin_name": "مأرب",
      "capital": "minor",
    },
    {
      "city": "مطرة",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "الضليعة",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "بروم",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "أحور",
      "admin_name": "أبين",
      "capital": "minor",
    },
    {
      "city": "حصوين",
      "admin_name": "المهرة",
      "capital": "minor",
    },
    {
      "city": "العليب",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "الشروج",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "ردوم",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "الطلح",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "حوف",
      "admin_name": "المهرة",
      "capital": "minor",
    },
    {
      "city": "قشن",
      "admin_name": "المهرة",
      "capital": "minor",
    },
    {
      "city": "المافود",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "جول المجمع",
      "admin_name": "شبوة",
      "capital": "minor",
    },
    {
      "city": "المحجل",
      "admin_name": "الجوف",
      "capital": "minor",
    },
    {
      "city": "دحسويس",
      "admin_name": "المهرة",
      "capital": "minor",
    },
    {
      "city": "العبر",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "شحن السفلى",
      "admin_name": "المهرة",
      "capital": "minor",
    },
    {
      "city": "ثمود",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "رماه",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "برهوت",
      "admin_name": "المهرة",
      "capital": "minor",
    },
    {
      "city": "السلاسل",
      "admin_name": "حضرموت",
      "capital": "minor",
    },
    {
      "city": "منوخ",
      "admin_name": "حضرموت",
      "capital": "minor",
    }
  };

  static final cityList =
      _citiesMap.map((item) => CityModel.fromJson(item).name).toList();

  static List<String> get getCities {
    return [...cityList];
  }

  CityModel(this.name);

  static Future<List<CityModel>> citySuggestions(String query) async {
    return _citiesMap.map((item) => CityModel.fromJson(item)).where((city) {
      final cityLowerCase = city.name.toLowerCase();
      final queryLowerCase = query.toLowerCase();

      return cityLowerCase.contains(queryLowerCase);
    }).toList();
  }

  // static Future<List<String>> citySuggestionsString(String query) async{
  //   return;
  // }

  static Future<List<String>> startWithCitySuggestionsString(
      String query) async {
    return cityList.where((city) {
      final cityLowerCase = city.toLowerCase();
      final queryLowerCase = query.toLowerCase();

      return cityLowerCase.startsWith(queryLowerCase);
    }).toList();
  }

  static CityModel fromJson(Map<String, dynamic> json) {
    return CityModel(
      json['city'],
    );
  }
}
