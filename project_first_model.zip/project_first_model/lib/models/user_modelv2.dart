import 'dart:convert';

import 'package:equatable/equatable.dart';

class UserModelV2 extends Equatable {
  final String userId;
  final String userName;
  final String userPic;
  final String region;
  final String userPhoneNumber;
  final String userCarPic1;
  final String userCarPic2;

  const UserModelV2({
    this.userId = '',
    required this.userName,
    this.userPic = '',
    required this.region,
    required this.userPhoneNumber,
    this.userCarPic1 = '',
    this.userCarPic2 = '',
  });

  static UserModelV2 get defaultUser {
    return const UserModelV2(
      userId: '',
      userName: '',
      userPic: '',
      region: '',
      userPhoneNumber: '',
      userCarPic1: '',
      userCarPic2: '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'userId': userId,
      'userName': userName,
      'userPic': userPic,
      'region': region,
      'userPhoneNumber': userPhoneNumber,
      'userCarPic1': userCarPic1,
      'userCarPic2': userCarPic2,
    };
  }

  factory UserModelV2.fromMap(
      {required Map<String, dynamic> user, String id = ''}) {
    return UserModelV2(
      userId: id,
      userName: user['userName'],
      userPic: user['userPic'],
      region: user['region'],
      userPhoneNumber: user['userPhoneNumber'],
      userCarPic1: user['userCarPic1'],
      userCarPic2: user['userCarPic2'],
    );
  }

  String toJson() => json.encode(toMap());

  factory UserModelV2.fromJson(String source) =>
      UserModelV2.fromMap(user: json.decode(source));

  UserModelV2 copyWith({
    String? userId,
    String? userName,
    String? userPic,
    String? region,
    String? userPhoneNumber,
    String? userCarPic1,
    String? userCarPic2,
  }) {
    return UserModelV2(
      userId: userId ?? this.userId,
      userName: userName ?? this.userName,
      userPic: userPic ?? this.userPic,
      region: region ?? this.region,
      userPhoneNumber: userPhoneNumber ?? this.userPhoneNumber,
      userCarPic1: userCarPic1 ?? this.userCarPic1,
      userCarPic2: userCarPic2 ?? this.userCarPic2,
    );
  }

  @override
  bool get stringify => true;

  @override
  List<Object?> get props {
    return [
      userId,
      userName,
      userPic,
      region,
      userPhoneNumber,
      userCarPic1,
      userCarPic2,
    ];
  }
}
