import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';

class AlarmModel extends Equatable {
  final int? alarmId;
  final String tripId;
  final DateTime tripTime;
  final int isEnabled;
  final String userId;
  final String driverId;
  final String driverName;
  final String driverPhone;
  final String destination;
  final int colorIndex;

  const AlarmModel({
    this.alarmId,
    required this.tripId,
    required this.tripTime,
    required this.isEnabled,
    required this.userId,
    required this.driverId,
    required this.driverName,
    required this.driverPhone,
    required this.destination,
    required this.colorIndex,
  });

  static const alarmsTableName = 'alarms';
  static const alarmIdCol = 'alarmId';
  static const tripIdCol = 'tripId';
  static const tripTimeCol = 'tripTime';
  static const isEnabledCol = 'isEnabled';
  static const userIdCol = 'userId';
  static const driverIdCol = 'driverId';
  static const driverNameCol = 'driverName';
  static const driverPhoneCol = 'driverPhone';
  static const destinationCol = 'destination';
  static const colorIndexCol = 'colorIndex';
  static String createTableNotification = '''
  CREATE TABLE $alarmsTableName 
  (
  $alarmIdCol INTEGER PRIMARY KEY AUTOINCREMENT,
  $tripIdCol TEXT,
  $tripTimeCol INTEGER,
  $isEnabledCol INTEGER,
  $userIdCol TEXT,
  $driverIdCol TEXT,
  $driverNameCol TEXT,
  $driverPhoneCol TEXT,
  $destinationCol TEXT,
  $colorIndexCol INTEGER
  )
  ''';

  static String updateTableNotification = '''
  ALTER TABLE $alarmsTableName 
  ADD $colorIndexCol INTEGER
  ''';

  static AlarmModel get defaultAlarm {
    return AlarmModel(
      tripId: 'tripId',
      tripTime: DateTime.now(),
      isEnabled: 1,
      userId: 'userId',
      driverId: 'driverId',
      driverName: 'driverName',
      driverPhone: 'driverPhone',
      destination: 'destination',
      colorIndex: 1,
    );
  }

  static int gradientColorIndex(DateTime date) {
    final time = DateTimeHelpers.convertToTimeOfDayV2(
      DateTimeHelpers.convertDateTimeToTimeString(date),
    );

    final hours = time.hour;

    if (hours >= 5 && hours < 9) {
      return 0;
    } else if (hours >= 9 && hours < 16) {
      return 1;
    } else if (hours >= 16 && hours < 19) {
      return 2;
    } else if (hours >= 19 || hours < 3) {
      return 3;
    } else {
      return 4;
    }
  }

  AlarmModel copyWith({
    int? alarmId,
    String? tripId,
    DateTime? tripTime,
    int? isEnabled,
    String? userId,
    String? driverId,
    String? driverName,
    String? driverPhone,
    String? destination,
    int? colorIndex,
  }) {
    return AlarmModel(
      alarmId: alarmId ?? this.alarmId,
      tripId: tripId ?? this.tripId,
      tripTime: tripTime ?? this.tripTime,
      isEnabled: isEnabled ?? this.isEnabled,
      userId: userId ?? this.userId,
      driverId: driverId ?? this.driverId,
      driverName: driverName ?? this.driverName,
      driverPhone: driverPhone ?? this.driverPhone,
      destination: destination ?? this.destination,
      colorIndex: colorIndex ?? this.colorIndex,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'alarmId': alarmId,
      'tripId': tripId,
      'tripTime': tripTime.millisecondsSinceEpoch,
      'isEnabled': isEnabled,
      'userId': userId,
      'driverId': driverId,
      'driverName': driverName,
      'driverPhone': driverPhone,
      'destination': destination,
      'colorIndex': colorIndex,
    };
  }

  factory AlarmModel.fromMap(Map<String, dynamic> map) {
    final date = DateTime.fromMillisecondsSinceEpoch(map['tripTime']);
    return AlarmModel(
      alarmId: map['alarmId']?.toInt(),
      tripId: map['tripId'] ?? '',
      tripTime: date,
      isEnabled: map['isEnabled']?.toInt() ?? 0,
      userId: map['userId'] ?? '',
      driverId: map['driverId'] ?? '',
      driverName: map['driverName'] ?? '',
      driverPhone: map['driverPhone'] ?? '',
      destination: map['destination'] ?? '',
      colorIndex: map['colorIndex'] ?? AlarmModel.gradientColorIndex(date),
    );
  }

  String toJson() => json.encode(toMap());

  factory AlarmModel.fromJson(String source) =>
      AlarmModel.fromMap(json.decode(source));

  @override
  String toString() {
    return 'AlarmModel(alarmId: $alarmId, tripId: $tripId, tripTime: $tripTime, isEnabled: $isEnabled, userId: $userId, driverId: $driverId, driverName: $driverName, driverPhone: $driverPhone, destination: $destination, colorIndex: $colorIndex)';
  }

  @override
  List<Object?> get props {
    return [
      alarmId,
      tripId,
      tripTime,
      isEnabled,
      userId,
      driverId,
      driverName,
      driverPhone,
      destination,
      colorIndex,
    ];
  }
}
