import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

enum FilterPriority {
  // driverName,
  // driverPhone,
  from,
  to,
  date,
  none,
}

class FiltersModel extends Equatable {
  // final String? driverName;
  final String from;
  final String to;
  // final String? phoneNumber;
  final DateTime? date;
  final DateTime? fullDateTime;
  final TimeOfDay? time;
  final bool searchForBigger;
  static FilterPriority priority = FilterPriority.none;

  const FiltersModel({
    // this.driverName = '',
    this.from = '',
    this.to = '',
    // this.phoneNumber = '',
    this.date,
    this.fullDateTime,
    this.time,
    this.searchForBigger = true,
  });

  static FiltersModel get defaultFilters {
    return const FiltersModel(
      from: '',
      to: '',
      date: null,
      fullDateTime: null,
      time: null,
      searchForBigger: true,
    );
  }

  ///return false if there is one value not null
  ///otherwies return true
  bool checkIfAllValuesNull() {
    priority = FilterPriority.none;

    // if (driverName!.isNotEmpty) {
    //   priority = FilterPriority.driverName;
    //   return false;
    // }

    // if (phoneNumber!.isNotEmpty) {
    //   priority = FilterPriority.driverPhone;
    //   return false;
    // }

    if (from.isNotEmpty || from != '') {
      priority = FilterPriority.from;
      return false;
    }

    if (to.isNotEmpty || to != '') {
      priority = FilterPriority.to;
      return false;
    }

    if (date != null) {
      priority = FilterPriority.date;
      return false;
    }

    return true;
  }

  @override
  List<Object?> get props {
    return [
      from,
      to,
      date,
      fullDateTime,
      time,
      searchForBigger,
    ];
  }

  FiltersModel copyWith({
    String? from,
    String? to,
    DateTime? date,
    DateTime? fullDateTime,
    TimeOfDay? time,
    bool? searchForBigger,
  }) {
    return FiltersModel(
      from: from ?? this.from,
      to: to ?? this.to,
      date: date ?? this.date,
      fullDateTime: fullDateTime ?? this.fullDateTime,
      time: time ?? this.time,
      searchForBigger: searchForBigger ?? this.searchForBigger,
    );
  }
}
