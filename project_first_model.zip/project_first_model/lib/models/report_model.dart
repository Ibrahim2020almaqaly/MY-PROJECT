import 'dart:convert';

import 'package:equatable/equatable.dart';

class ReportsModel extends Equatable {
  final String driverID;
  final int reportersPeopleCount;

  const ReportsModel({
    required this.driverID,
    required this.reportersPeopleCount,
  });

  static ReportsModel get defaultReport {
    return const ReportsModel(
      driverID: '',
      reportersPeopleCount: 0,
    );
  }

  ReportsModel copyWith({
    String? driverID,
    int? reportersPeopleCount,
  }) {
    return ReportsModel(
      driverID: driverID ?? this.driverID,
      reportersPeopleCount: reportersPeopleCount ?? this.reportersPeopleCount,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'driverID': driverID,
      'reportersPeopleCount': reportersPeopleCount,
    };
  }

  factory ReportsModel.fromMap(
      {required Map<String, dynamic> driver, required String driverID}) {
    return ReportsModel(
      driverID: driverID, //driver['driverID'] ?? '',
      reportersPeopleCount: driver['reportersPeopleCount']?.toInt() ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory ReportsModel.fromJson(String source, String sourceID) =>
      ReportsModel.fromMap(driver: json.decode(source), driverID: sourceID);

  @override
  String toString() =>
      'ReportsModel(driverID: $driverID, reportersPeopleCount: $reportersPeopleCount)';

  @override
  List<Object> get props => [driverID, reportersPeopleCount];
}

class CustomersReport extends Equatable {
  final String customerID;
  final String reason;

  const CustomersReport({
    required this.customerID,
    required this.reason,
  });

  CustomersReport copyWith({
    String? customerID,
    String? reason,
  }) {
    return CustomersReport(
      customerID: customerID ?? this.customerID,
      reason: reason ?? this.reason,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'customerID': customerID,
      'reason': reason,
    };
  }

  factory CustomersReport.fromMap(
      {required Map<String, dynamic> customer, required String customerID}) {
    return CustomersReport(
      customerID: customerID, //map['customerID'] ?? '',
      reason: customer['reason'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory CustomersReport.fromJson(String source, String sourceID) =>
      CustomersReport.fromMap(
          customer: json.decode(source), customerID: sourceID);

  @override
  String toString() =>
      'CustomersReport(customerID: $customerID, reason: $reason)';

  @override
  List<Object> get props => [customerID, reason];
}
