import 'dart:convert';

import 'package:equatable/equatable.dart';

class PrivacyModel extends Equatable {
  final String privacy;
  const PrivacyModel({
    required this.privacy,
  });

  PrivacyModel copyWith({
    String? privacy,
  }) {
    return PrivacyModel(
      privacy: privacy ?? this.privacy,
    );
  }

  static PrivacyModel get defaultPrivacy {
    return const PrivacyModel(
      privacy: 'privacy',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'privacy': privacy,
    };
  }

  factory PrivacyModel.fromMap(Map<String, dynamic> map) {
    return PrivacyModel(
      privacy: map['privacy'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory PrivacyModel.fromJson(String source) =>
      PrivacyModel.fromMap(json.decode(source));

  @override
  String toString() => 'PrivacyModel(privacy: $privacy)';

  @override
  List<Object> get props => [privacy];
}
