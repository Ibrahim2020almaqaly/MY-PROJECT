import 'dart:convert';

import 'package:equatable/equatable.dart';

class SuggestionModel extends Equatable {
  final String userID;
  final String suggestion;

  const SuggestionModel({
    required this.userID,
    required this.suggestion,
  });

  SuggestionModel copyWith({
    String? userID,
    String? suggestion,
  }) {
    return SuggestionModel(
      userID: userID ?? this.userID,
      suggestion: suggestion ?? this.suggestion,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'userID': userID,
      'suggestion': suggestion,
    };
  }

  factory SuggestionModel.fromMap({
    required Map<String, dynamic> suggestion,
    String userID = '',
  }) {
    return SuggestionModel(
      userID: userID, //suggestion['userID'] ?? '',
      suggestion: suggestion['suggestion'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory SuggestionModel.fromJson(String source) =>
      SuggestionModel.fromMap(suggestion: json.decode(source));

  @override
  String toString() =>
      'SuggestionModel(userID: $userID, suggestion: $suggestion)';

  @override
  List<Object> get props => [userID, suggestion];
}
