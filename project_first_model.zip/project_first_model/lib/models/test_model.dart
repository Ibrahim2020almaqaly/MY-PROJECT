import 'dart:convert';

import 'package:equatable/equatable.dart';

class TestModel extends Equatable {
  final bool ttt;
  const TestModel({
    required this.ttt,
  });

  TestModel copyWith({
    bool? ttt,
  }) {
    return TestModel(
      ttt: ttt ?? this.ttt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'ttt': ttt,
    };
  }

  factory TestModel.fromMap(Map<String, dynamic> map) {
    return TestModel(
      ttt: map['ttt'] ?? false,
    );
  }

  String toJson() => json.encode(toMap());

  factory TestModel.fromJson(String source) =>
      TestModel.fromMap(json.decode(source));

  @override
  String toString() => 'TestModel(ttt: $ttt)';

  @override
  List<Object> get props => [ttt];
}
