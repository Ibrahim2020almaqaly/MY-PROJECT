import 'dart:convert';

import 'package:equatable/equatable.dart';

class CallRecordModel extends Equatable {
  final String userID;
  final String driverID;
  final String driverNumber;
  final DateTime calltime;

  const CallRecordModel({
    required this.userID,
    required this.driverID,
    required this.driverNumber,
    required this.calltime,
  });

  CallRecordModel copyWith({
    String? userID,
    String? driverID,
    String? driverNumber,
    DateTime? calltime,
  }) {
    return CallRecordModel(
      userID: userID ?? this.userID,
      driverID: driverID ?? this.driverID,
      driverNumber: driverNumber ?? this.driverNumber,
      calltime: calltime ?? this.calltime,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'userID': userID,
      'driverID': driverID,
      'driverNumber': driverNumber,
      'calltime': calltime.millisecondsSinceEpoch,
    };
  }

  factory CallRecordModel.fromMap({
    required Map<String, dynamic> callRecord,
    required String userID,
  }) {
    return CallRecordModel(
      userID: userID, //callRecord['userID'] ?? '',
      driverID: callRecord['driverID'] ?? '',
      driverNumber: callRecord['driverNumber'] ?? '',
      calltime: DateTime.fromMillisecondsSinceEpoch(callRecord['calltime']),
    );
  }

  String toJson() => json.encode(toMap());

  factory CallRecordModel.fromJson(String source, String sourceID) =>
      CallRecordModel.fromMap(
        callRecord: json.decode(source),
        userID: sourceID,
      );

  @override
  String toString() =>
      'CallRecordModel(userID: $userID, driverID: $driverID, driverNumber: $driverNumber, calltime: $calltime)';

  @override
  List<Object> get props => [userID, driverID, driverNumber, calltime];
}
