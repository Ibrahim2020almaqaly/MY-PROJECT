import 'dart:convert';

import 'package:equatable/equatable.dart';

class ErrorReportModel extends Equatable {
  final String userID;
  final String error;
  final String? errorScreenImgURL;

  const ErrorReportModel({
    required this.userID,
    required this.error,
    this.errorScreenImgURL,
  });

  ErrorReportModel copyWith({
    String? userID,
    String? error,
    String? errorScreenImgURL,
  }) {
    return ErrorReportModel(
      userID: userID ?? this.userID,
      error: error ?? this.error,
      errorScreenImgURL: errorScreenImgURL ?? this.errorScreenImgURL,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      // 'userID': userID,
      'error': error,
      'errorScreenImgURL': errorScreenImgURL,
    };
  }

  factory ErrorReportModel.fromMap({
    required Map<String, dynamic> error,
    String userID = '',
  }) {
    return ErrorReportModel(
      userID: userID, //error['userID'] ?? '',
      error: error['error'] ?? '',
      errorScreenImgURL: error['errorScreenImgURL'],
    );
  }

  String toJson() => json.encode(toMap());

  factory ErrorReportModel.fromJson(String source) =>
      ErrorReportModel.fromMap(error: json.decode(source));

  @override
  String toString() =>
      'ErrorReportModel(userID: $userID, error: $error, errorScreenImgURL: $errorScreenImgURL)';

  @override
  List<Object?> get props => [userID, error, errorScreenImgURL];
}
