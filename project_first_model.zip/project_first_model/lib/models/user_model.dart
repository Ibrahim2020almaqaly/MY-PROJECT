import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:project_first_model/gen/assets.gen.dart';

class UserModel extends Equatable {
  final int? idUser;
  final String driverName;
  final String? driverPic;
  final String phoneNumber;
  final String tripId;
  final String? carPic1;
  final String? carPic2;

  static UserModel get defaultModel {
    return UserModel(
      idUser: -1,
      driverName: '',
      driverPic: Assets.images.noImageTemp.path,
      phoneNumber: '',
      tripId: '',
      carPic1: '',
      carPic2: '',
    );
  }

  const UserModel({
    this.idUser,
    required this.driverName,
    this.driverPic,
    required this.phoneNumber,
    required this.tripId,
    this.carPic1,
    this.carPic2,
  });

  static const userModelTableName = 'userModelTable';
  static const idUserCol = 'idTrip';
  static const driverNameCol = 'driverName';
  static const driverPicPathCol = 'driverPicPath';
  static const phoneNumberCol = 'phoneNumber';
  static const tripIdCol = 'tripId';
  static const carPic1Col = 'carPic1Path';
  static const carPic2Col = 'carPic2Path';

  static String createTableUserModel = '''
  CREATE TABLE $userModelTableName (
  $idUserCol INTEGER PRIMARY KEY AUTOINCREMENT,
  $driverNameCol TEXT,
  $driverPicPathCol TEXT,
  $phoneNumberCol TEXT,
  $tripIdCol TEXT,
  $carPic1Col TEXT,
  $carPic2Col TEXT
  )
  ''';

  @override
  List<Object?> get props => [
        idUser,
        driverName,
        driverPic,
        phoneNumber,
        tripId,
        carPic1,
        carPic2,
      ];

  Map<String, dynamic> toMap() {
    return {
      idUserCol: idUser,
      driverNameCol: driverName,
      driverPicPathCol: driverPic,
      phoneNumberCol: phoneNumber,
      tripIdCol: tripId,
      carPic1Col: carPic1,
      carPic2Col: carPic2,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      idUser: map[idUserCol] ?? -1,
      driverName: map[driverNameCol],
      driverPic: map[driverPicPathCol] ?? '',
      phoneNumber: map[phoneNumberCol],
      tripId: map[tripIdCol],
      carPic1: map[carPic1Col] ?? '',
      carPic2: map[carPic2Col] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory UserModel.fromJson(String source) =>
      UserModel.fromMap(json.decode(source));

  @override
  bool get stringify => true;

  UserModel copyWith({
    int? idUser,
    String? driverName,
    String? driverPic,
    String? phoneNumber,
    String? tripId,
    String? carPic1,
    String? carPic2,
  }) {
    return UserModel(
      idUser: idUser ?? this.idUser,
      driverName: driverName ?? this.driverName,
      driverPic: driverPic ?? this.driverPic,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      tripId: tripId ?? this.tripId,
      carPic1: carPic1 ?? this.carPic1,
      carPic2: carPic2 ?? this.carPic2,
    );
  }
}
