import 'package:auto_route/auto_route.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/router/auth_guard.dart';
import 'package:project_first_model/router/router.gr.dart';

class LoggedGuard extends AutoRouteGuard {
  LoggedGuard();
  // final BuildContext context;
  @override
  void onNavigation(NavigationResolver resolver, StackRouter router) {
    final isAuth = AuthGuard.isAuthenticated();
    if (isAuth) {
      resolver.next(true);
    } else {
      ShowAnyMessages.showToastMSG(
        'ليس لديك حساب بعد يرجى إضافة حساب',
        // floating: false,
      );
      router.push(const RegisterScreenRouter());
    }
  }
}
