import 'package:auto_route/auto_route.dart';

@RoutePage(name: 'MainScreenBodyRouter')
class MainScreenBodyScreen extends AutoRouter {
  const MainScreenBodyScreen({super.key});
}

@RoutePage(name: 'AccountSettingsScreenRouter')
class AccountSettingsScreen extends AutoRouter {
  const AccountSettingsScreen({super.key});
}

@RoutePage(name: 'SearchTripsRouter')
class SearchTripScreen extends AutoRouter {
  const SearchTripScreen({super.key});
}

@RoutePage(name: 'mainScreenRouter')
class MainRouterPage extends AutoRouter {
  const MainRouterPage({super.key});
}
