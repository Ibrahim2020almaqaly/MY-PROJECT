import 'package:auto_route/auto_route.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/helpers/show_messages.dart';

import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/services/app_settings.dart';

class AuthGuard extends AutoRouteGuard {
  AuthGuard();

  static bool isAuthenticated() {
    final user = Get.find<FirebaseAuthController>();
    final authenticated = user.getCurrentUser != null;
    if (authenticated) {
      Get.find<UserController>().requestMyData();
    }

    return authenticated;
  }

  // static bool isDisabled(BuildContext context) {
  //   final disabled =
  //       AppSettings.getSettingValue<bool>(AppSettings.isDisabledKey, false);
  //   print(disabled);

  //   return disabled;
  // }

  static bool isOnline() {
    final isOnline = Get.find<ConnectionController>().isOnline;

    return isOnline;
  }

  @override
  void onNavigation(NavigationResolver resolver, StackRouter router) async {
    final authenticated = isAuthenticated();
    // final disabled = isDisabled(context);

    if (router.isRoot) {
      // if (disabled) {
      //   router.pushAndPopUntil(
      //     const DisabledAccountScreenRoute(),
      //     predicate: (route) => false,
      //   );
      //   return;
      // }

      if (authenticated) {
        final enterd = AppSettings.getSettingValue<bool>(
            AppSettings.enteredTheDataKey, false);
        if (!enterd) {
          router.pushAndPopUntil(
            const ViewMiniProfileRoute(),
            predicate: (route) => false,
          );
        } else {
          router.pushAndPopUntil(
            const MainScreenRouter(),
            predicate: (route) => false,
          );
        }
        return;
      }

      // router.pushAndPopUntil(
      //   const TestScreenRoute(),
      //   predicate: (route) => false,
      // );
      // return;

      if (router.currentPath == '/') {
        resolver.next(true);
      } else {
        ShowAnyMessages.showToastMSG(
          // context,
          'ليس لديك حساب بعد يرجى إضافة حساب',
          // floating: false,
        );
        router.push(const RegisterScreenRouter());
      }

      return;
    }

    // if (disabled) {
    //   router.pushAndPopUntil(
    //     const DisabledAccountScreenRoute(),
    //     predicate: (route) => false,
    //   );
    //   return;
    // }

    if (authenticated) {
      resolver.next(true);
    } else {
      ShowAnyMessages.showToastMSG(
        'ليس لديك حساب بعد يرجى إضافة حساب',
        // floating: false,
      );
      router.push(const RegisterScreenRouter());
    }
  }
}
