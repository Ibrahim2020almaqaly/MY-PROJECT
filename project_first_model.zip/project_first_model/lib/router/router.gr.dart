// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i32;
import 'package:flutter/material.dart' as _i33;
import 'package:project_first_model/router/empty_routes.dart' as _i3;
import 'package:project_first_model/screens/alarms_screen.dart' as _i5;
import 'package:project_first_model/screens/dirver_pages/higher_rate_list_screen.dart'
    as _i9;
import 'package:project_first_model/screens/dirver_pages/report_screen.dart'
    as _i17;
import 'package:project_first_model/screens/dirver_pages/show_driver_profile_screen.dart'
    as _i20;
import 'package:project_first_model/screens/feedback_pages/about_screen.dart'
    as _i1;
import 'package:project_first_model/screens/feedback_pages/error_report_screen.dart'
    as _i7;
import 'package:project_first_model/screens/feedback_pages/privacy_policy_screen.dart'
    as _i14;
import 'package:project_first_model/screens/feedback_pages/suggestion_screen.dart'
    as _i25;
import 'package:project_first_model/screens/login_pages/disabled_account_screen.dart'
    as _i6;
import 'package:project_first_model/screens/login_pages/otp.dart' as _i12;
import 'package:project_first_model/screens/login_pages/register.dart' as _i16;
import 'package:project_first_model/screens/login_pages/welcome_screen.dart'
    as _i31;
import 'package:project_first_model/screens/main_screen.dart' as _i10;
import 'package:project_first_model/screens/notifications_screen.dart' as _i11;
import 'package:project_first_model/screens/overland_transport_pages/overland_transports_list_screen.dart'
    as _i13;
import 'package:project_first_model/screens/overland_transport_pages/show_transporter_profile_screen.dart'
    as _i22;
import 'package:project_first_model/screens/profile_pages/account_settings_screen.dart'
    as _i2;
import 'package:project_first_model/screens/profile_pages/profile_screen.dart'
    as _i15;
import 'package:project_first_model/screens/profile_pages/settings_screen.dart'
    as _i19;
import 'package:project_first_model/screens/profile_pages/view_mini_profile_screen.dart'
    as _i30;
import 'package:project_first_model/screens/test_screen.dart' as _i26;
import 'package:project_first_model/screens/testing_widget.dart' as _i27;
import 'package:project_first_model/screens/trip_pages/add_trip_screen.dart'
    as _i4;
import 'package:project_first_model/screens/trip_pages/search_trips.dart'
    as _i18;
import 'package:project_first_model/screens/trip_pages/show_filter_trips_page.dart'
    as _i21;
import 'package:project_first_model/screens/trip_pages/show_trip_data_screen.dart'
    as _i23;
import 'package:project_first_model/screens/trip_pages/trips_history_list_screen.dart'
    as _i28;
import 'package:project_first_model/screens/trip_pages/trips_list_screen.dart'
    as _i29;
import 'package:project_first_model/splash_screen.dart' as _i24;
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/handel_connection.dart'
    as _i8;

abstract class $AppRouter extends _i32.RootStackRouter {
  $AppRouter({super.navigatorKey});

  @override
  final Map<String, _i32.PageFactory> pagesMap = {
    AboutRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i1.AboutScreen(),
      );
    },
    AccountSettingsRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i2.AccountSettingsScreen(),
      );
    },
    AccountSettingsScreenRouter.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i3.AccountSettingsScreen(),
      );
    },
    AddTripRouter.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i4.AddTripScreen(),
      );
    },
    AlarmsRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i5.AlarmsScreen(),
      );
    },
    DisabledAccountRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i6.DisabledAccountScreen(),
      );
    },
    ErrorReportRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i7.ErrorReportScreen(),
      );
    },
    HandelConnection.name: (routeData) {
      final args = routeData.argsAs<HandelConnectionArgs>(
          orElse: () => const HandelConnectionArgs());
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i8.HandelConnection(
          key: args.key,
          showAppBar: args.showAppBar,
          mainWidget: args.mainWidget,
        ),
      );
    },
    HigherRateListRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i9.HigherRateListScreen(),
      );
    },
    MainScreenRouter.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i3.MainRouterPage(),
      );
    },
    MainRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i10.MainScreen(),
      );
    },
    MainScreenBodyRouter.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i3.MainScreenBodyScreen(),
      );
    },
    NotificationsRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i11.NotificationsScreen(),
      );
    },
    OtpScreenRouter.name: (routeData) {
      final args = routeData.argsAs<OtpScreenRouterArgs>();
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i12.Otp(
          key: args.key,
          phoneNumber: args.phoneNumber,
        ),
      );
    },
    OverlandTransportsListRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i13.OverlandTransportsListScreen(),
      );
    },
    PrivacyPolicyRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i14.PrivacyPolicyScreen(),
      );
    },
    ProfileRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i15.ProfileScreen(),
      );
    },
    RegisterScreenRouter.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i16.Register(),
      );
    },
    ReportRoute.name: (routeData) {
      final args = routeData.argsAs<ReportRouteArgs>();
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i17.ReportScreen(
          key: args.key,
          driverID: args.driverID,
        ),
      );
    },
    SearchTripsRouter.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i3.SearchTripScreen(),
      );
    },
    SearchTrips.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i18.SearchTrips(),
      );
    },
    SettingsRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i19.SettingsScreen(),
      );
    },
    ShowDriverProfileRoute.name: (routeData) {
      final pathParams = routeData.inheritedPathParams;
      final args = routeData.argsAs<ShowDriverProfileRouteArgs>(
          orElse: () => ShowDriverProfileRouteArgs(
              driverId: pathParams.getString('driverId')));
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i20.ShowDriverProfileScreen(
          key: args.key,
          driverId: args.driverId,
        ),
      );
    },
    ShowFilterTripsRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i21.ShowFilterTripsPage(),
      );
    },
    ShowTransporterProfileRoute.name: (routeData) {
      final pathParams = routeData.inheritedPathParams;
      final args = routeData.argsAs<ShowTransporterProfileRouteArgs>(
          orElse: () => ShowTransporterProfileRouteArgs(
              transporterId: pathParams.getString('transporterId')));
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i22.ShowTransporterProfileScreen(
          key: args.key,
          transporterId: args.transporterId,
        ),
      );
    },
    ShowTripDataRoute.name: (routeData) {
      final pathParams = routeData.inheritedPathParams;
      final args = routeData.argsAs<ShowTripDataRouteArgs>(
          orElse: () =>
              ShowTripDataRouteArgs(tripId: pathParams.getString('tripId')));
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i23.ShowTripDataScreen(
          key: args.key,
          tripId: args.tripId,
        ),
      );
    },
    SplashScreenRouter.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i24.SplashScreen(),
      );
    },
    SuggestionRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i25.SuggestionScreen(),
      );
    },
    TestScreenRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i26.TestScreen(),
      );
    },
    TestingWidget.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i27.TestingWidget(),
      );
    },
    TripsHistoryListRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i28.TripsHistoryListScreen(),
      );
    },
    TripsListRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i29.TripsListScreen(),
      );
    },
    ViewMiniProfileRoute.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i30.ViewMiniProfileScreen(),
      );
    },
    WelcomeScreenRouter.name: (routeData) {
      return _i32.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i31.WelcomeScreen(),
      );
    },
  };
}

/// generated route for
/// [_i1.AboutScreen]
class AboutRoute extends _i32.PageRouteInfo<void> {
  const AboutRoute({List<_i32.PageRouteInfo>? children})
      : super(
          AboutRoute.name,
          initialChildren: children,
        );

  static const String name = 'AboutRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i2.AccountSettingsScreen]
class AccountSettingsRoute extends _i32.PageRouteInfo<void> {
  const AccountSettingsRoute({List<_i32.PageRouteInfo>? children})
      : super(
          AccountSettingsRoute.name,
          initialChildren: children,
        );

  static const String name = 'AccountSettingsRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i3.AccountSettingsScreen]
class AccountSettingsScreenRouter extends _i32.PageRouteInfo<void> {
  const AccountSettingsScreenRouter({List<_i32.PageRouteInfo>? children})
      : super(
          AccountSettingsScreenRouter.name,
          initialChildren: children,
        );

  static const String name = 'AccountSettingsScreenRouter';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i4.AddTripScreen]
class AddTripRouter extends _i32.PageRouteInfo<void> {
  const AddTripRouter({List<_i32.PageRouteInfo>? children})
      : super(
          AddTripRouter.name,
          initialChildren: children,
        );

  static const String name = 'AddTripRouter';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i5.AlarmsScreen]
class AlarmsRoute extends _i32.PageRouteInfo<void> {
  const AlarmsRoute({List<_i32.PageRouteInfo>? children})
      : super(
          AlarmsRoute.name,
          initialChildren: children,
        );

  static const String name = 'AlarmsRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i6.DisabledAccountScreen]
class DisabledAccountRoute extends _i32.PageRouteInfo<void> {
  const DisabledAccountRoute({List<_i32.PageRouteInfo>? children})
      : super(
          DisabledAccountRoute.name,
          initialChildren: children,
        );

  static const String name = 'DisabledAccountRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i7.ErrorReportScreen]
class ErrorReportRoute extends _i32.PageRouteInfo<void> {
  const ErrorReportRoute({List<_i32.PageRouteInfo>? children})
      : super(
          ErrorReportRoute.name,
          initialChildren: children,
        );

  static const String name = 'ErrorReportRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i8.HandelConnection]
class HandelConnection extends _i32.PageRouteInfo<HandelConnectionArgs> {
  HandelConnection({
    _i33.Key? key,
    bool showAppBar = true,
    _i33.Widget? mainWidget,
    List<_i32.PageRouteInfo>? children,
  }) : super(
          HandelConnection.name,
          args: HandelConnectionArgs(
            key: key,
            showAppBar: showAppBar,
            mainWidget: mainWidget,
          ),
          initialChildren: children,
        );

  static const String name = 'HandelConnection';

  static const _i32.PageInfo<HandelConnectionArgs> page =
      _i32.PageInfo<HandelConnectionArgs>(name);
}

class HandelConnectionArgs {
  const HandelConnectionArgs({
    this.key,
    this.showAppBar = true,
    this.mainWidget,
  });

  final _i33.Key? key;

  final bool showAppBar;

  final _i33.Widget? mainWidget;

  @override
  String toString() {
    return 'HandelConnectionArgs{key: $key, showAppBar: $showAppBar, mainWidget: $mainWidget}';
  }
}

/// generated route for
/// [_i9.HigherRateListScreen]
class HigherRateListRoute extends _i32.PageRouteInfo<void> {
  const HigherRateListRoute({List<_i32.PageRouteInfo>? children})
      : super(
          HigherRateListRoute.name,
          initialChildren: children,
        );

  static const String name = 'HigherRateListRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i3.MainRouterPage]
class MainScreenRouter extends _i32.PageRouteInfo<void> {
  const MainScreenRouter({List<_i32.PageRouteInfo>? children})
      : super(
          MainScreenRouter.name,
          initialChildren: children,
        );

  static const String name = 'MainScreenRouter';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i10.MainScreen]
class MainRoute extends _i32.PageRouteInfo<void> {
  const MainRoute({List<_i32.PageRouteInfo>? children})
      : super(
          MainRoute.name,
          initialChildren: children,
        );

  static const String name = 'MainRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i3.MainScreenBodyScreen]
class MainScreenBodyRouter extends _i32.PageRouteInfo<void> {
  const MainScreenBodyRouter({List<_i32.PageRouteInfo>? children})
      : super(
          MainScreenBodyRouter.name,
          initialChildren: children,
        );

  static const String name = 'MainScreenBodyRouter';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i11.NotificationsScreen]
class NotificationsRoute extends _i32.PageRouteInfo<void> {
  const NotificationsRoute({List<_i32.PageRouteInfo>? children})
      : super(
          NotificationsRoute.name,
          initialChildren: children,
        );

  static const String name = 'NotificationsRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i12.Otp]
class OtpScreenRouter extends _i32.PageRouteInfo<OtpScreenRouterArgs> {
  OtpScreenRouter({
    _i33.Key? key,
    required String phoneNumber,
    List<_i32.PageRouteInfo>? children,
  }) : super(
          OtpScreenRouter.name,
          args: OtpScreenRouterArgs(
            key: key,
            phoneNumber: phoneNumber,
          ),
          initialChildren: children,
        );

  static const String name = 'OtpScreenRouter';

  static const _i32.PageInfo<OtpScreenRouterArgs> page =
      _i32.PageInfo<OtpScreenRouterArgs>(name);
}

class OtpScreenRouterArgs {
  const OtpScreenRouterArgs({
    this.key,
    required this.phoneNumber,
  });

  final _i33.Key? key;

  final String phoneNumber;

  @override
  String toString() {
    return 'OtpScreenRouterArgs{key: $key, phoneNumber: $phoneNumber}';
  }
}

/// generated route for
/// [_i13.OverlandTransportsListScreen]
class OverlandTransportsListRoute extends _i32.PageRouteInfo<void> {
  const OverlandTransportsListRoute({List<_i32.PageRouteInfo>? children})
      : super(
          OverlandTransportsListRoute.name,
          initialChildren: children,
        );

  static const String name = 'OverlandTransportsListRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i14.PrivacyPolicyScreen]
class PrivacyPolicyRoute extends _i32.PageRouteInfo<void> {
  const PrivacyPolicyRoute({List<_i32.PageRouteInfo>? children})
      : super(
          PrivacyPolicyRoute.name,
          initialChildren: children,
        );

  static const String name = 'PrivacyPolicyRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i15.ProfileScreen]
class ProfileRoute extends _i32.PageRouteInfo<void> {
  const ProfileRoute({List<_i32.PageRouteInfo>? children})
      : super(
          ProfileRoute.name,
          initialChildren: children,
        );

  static const String name = 'ProfileRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i16.Register]
class RegisterScreenRouter extends _i32.PageRouteInfo<void> {
  const RegisterScreenRouter({List<_i32.PageRouteInfo>? children})
      : super(
          RegisterScreenRouter.name,
          initialChildren: children,
        );

  static const String name = 'RegisterScreenRouter';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i17.ReportScreen]
class ReportRoute extends _i32.PageRouteInfo<ReportRouteArgs> {
  ReportRoute({
    _i33.Key? key,
    required String driverID,
    List<_i32.PageRouteInfo>? children,
  }) : super(
          ReportRoute.name,
          args: ReportRouteArgs(
            key: key,
            driverID: driverID,
          ),
          initialChildren: children,
        );

  static const String name = 'ReportRoute';

  static const _i32.PageInfo<ReportRouteArgs> page =
      _i32.PageInfo<ReportRouteArgs>(name);
}

class ReportRouteArgs {
  const ReportRouteArgs({
    this.key,
    required this.driverID,
  });

  final _i33.Key? key;

  final String driverID;

  @override
  String toString() {
    return 'ReportRouteArgs{key: $key, driverID: $driverID}';
  }
}

/// generated route for
/// [_i3.SearchTripScreen]
class SearchTripsRouter extends _i32.PageRouteInfo<void> {
  const SearchTripsRouter({List<_i32.PageRouteInfo>? children})
      : super(
          SearchTripsRouter.name,
          initialChildren: children,
        );

  static const String name = 'SearchTripsRouter';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i18.SearchTrips]
class SearchTrips extends _i32.PageRouteInfo<void> {
  const SearchTrips({List<_i32.PageRouteInfo>? children})
      : super(
          SearchTrips.name,
          initialChildren: children,
        );

  static const String name = 'SearchTrips';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i19.SettingsScreen]
class SettingsRoute extends _i32.PageRouteInfo<void> {
  const SettingsRoute({List<_i32.PageRouteInfo>? children})
      : super(
          SettingsRoute.name,
          initialChildren: children,
        );

  static const String name = 'SettingsRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i20.ShowDriverProfileScreen]
class ShowDriverProfileRoute
    extends _i32.PageRouteInfo<ShowDriverProfileRouteArgs> {
  ShowDriverProfileRoute({
    _i33.Key? key,
    required String driverId,
    List<_i32.PageRouteInfo>? children,
  }) : super(
          ShowDriverProfileRoute.name,
          args: ShowDriverProfileRouteArgs(
            key: key,
            driverId: driverId,
          ),
          rawPathParams: {'driverId': driverId},
          initialChildren: children,
        );

  static const String name = 'ShowDriverProfileRoute';

  static const _i32.PageInfo<ShowDriverProfileRouteArgs> page =
      _i32.PageInfo<ShowDriverProfileRouteArgs>(name);
}

class ShowDriverProfileRouteArgs {
  const ShowDriverProfileRouteArgs({
    this.key,
    required this.driverId,
  });

  final _i33.Key? key;

  final String driverId;

  @override
  String toString() {
    return 'ShowDriverProfileRouteArgs{key: $key, driverId: $driverId}';
  }
}

/// generated route for
/// [_i21.ShowFilterTripsPage]
class ShowFilterTripsRoute extends _i32.PageRouteInfo<void> {
  const ShowFilterTripsRoute({List<_i32.PageRouteInfo>? children})
      : super(
          ShowFilterTripsRoute.name,
          initialChildren: children,
        );

  static const String name = 'ShowFilterTripsRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i22.ShowTransporterProfileScreen]
class ShowTransporterProfileRoute
    extends _i32.PageRouteInfo<ShowTransporterProfileRouteArgs> {
  ShowTransporterProfileRoute({
    _i33.Key? key,
    required String transporterId,
    List<_i32.PageRouteInfo>? children,
  }) : super(
          ShowTransporterProfileRoute.name,
          args: ShowTransporterProfileRouteArgs(
            key: key,
            transporterId: transporterId,
          ),
          rawPathParams: {'transporterId': transporterId},
          initialChildren: children,
        );

  static const String name = 'ShowTransporterProfileRoute';

  static const _i32.PageInfo<ShowTransporterProfileRouteArgs> page =
      _i32.PageInfo<ShowTransporterProfileRouteArgs>(name);
}

class ShowTransporterProfileRouteArgs {
  const ShowTransporterProfileRouteArgs({
    this.key,
    required this.transporterId,
  });

  final _i33.Key? key;

  final String transporterId;

  @override
  String toString() {
    return 'ShowTransporterProfileRouteArgs{key: $key, transporterId: $transporterId}';
  }
}

/// generated route for
/// [_i23.ShowTripDataScreen]
class ShowTripDataRoute extends _i32.PageRouteInfo<ShowTripDataRouteArgs> {
  ShowTripDataRoute({
    _i33.Key? key,
    required String tripId,
    List<_i32.PageRouteInfo>? children,
  }) : super(
          ShowTripDataRoute.name,
          args: ShowTripDataRouteArgs(
            key: key,
            tripId: tripId,
          ),
          rawPathParams: {'tripId': tripId},
          initialChildren: children,
        );

  static const String name = 'ShowTripDataRoute';

  static const _i32.PageInfo<ShowTripDataRouteArgs> page =
      _i32.PageInfo<ShowTripDataRouteArgs>(name);
}

class ShowTripDataRouteArgs {
  const ShowTripDataRouteArgs({
    this.key,
    required this.tripId,
  });

  final _i33.Key? key;

  final String tripId;

  @override
  String toString() {
    return 'ShowTripDataRouteArgs{key: $key, tripId: $tripId}';
  }
}

/// generated route for
/// [_i24.SplashScreen]
class SplashScreenRouter extends _i32.PageRouteInfo<void> {
  const SplashScreenRouter({List<_i32.PageRouteInfo>? children})
      : super(
          SplashScreenRouter.name,
          initialChildren: children,
        );

  static const String name = 'SplashScreenRouter';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i25.SuggestionScreen]
class SuggestionRoute extends _i32.PageRouteInfo<void> {
  const SuggestionRoute({List<_i32.PageRouteInfo>? children})
      : super(
          SuggestionRoute.name,
          initialChildren: children,
        );

  static const String name = 'SuggestionRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i26.TestScreen]
class TestScreenRoute extends _i32.PageRouteInfo<void> {
  const TestScreenRoute({List<_i32.PageRouteInfo>? children})
      : super(
          TestScreenRoute.name,
          initialChildren: children,
        );

  static const String name = 'TestScreenRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i27.TestingWidget]
class TestingWidget extends _i32.PageRouteInfo<void> {
  const TestingWidget({List<_i32.PageRouteInfo>? children})
      : super(
          TestingWidget.name,
          initialChildren: children,
        );

  static const String name = 'TestingWidget';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i28.TripsHistoryListScreen]
class TripsHistoryListRoute extends _i32.PageRouteInfo<void> {
  const TripsHistoryListRoute({List<_i32.PageRouteInfo>? children})
      : super(
          TripsHistoryListRoute.name,
          initialChildren: children,
        );

  static const String name = 'TripsHistoryListRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i29.TripsListScreen]
class TripsListRoute extends _i32.PageRouteInfo<void> {
  const TripsListRoute({List<_i32.PageRouteInfo>? children})
      : super(
          TripsListRoute.name,
          initialChildren: children,
        );

  static const String name = 'TripsListRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i30.ViewMiniProfileScreen]
class ViewMiniProfileRoute extends _i32.PageRouteInfo<void> {
  const ViewMiniProfileRoute({List<_i32.PageRouteInfo>? children})
      : super(
          ViewMiniProfileRoute.name,
          initialChildren: children,
        );

  static const String name = 'ViewMiniProfileRoute';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}

/// generated route for
/// [_i31.WelcomeScreen]
class WelcomeScreenRouter extends _i32.PageRouteInfo<void> {
  const WelcomeScreenRouter({List<_i32.PageRouteInfo>? children})
      : super(
          WelcomeScreenRouter.name,
          initialChildren: children,
        );

  static const String name = 'WelcomeScreenRouter';

  static const _i32.PageInfo<void> page = _i32.PageInfo<void>(name);
}
