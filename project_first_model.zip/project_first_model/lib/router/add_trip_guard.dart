// import 'package:auto_route/auto_route.dart';
// import 'package:get/get.dart';

// import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
// import 'package:project_first_model/helpers/show_custom_dialog.dart';
// import 'package:project_first_model/helpers/show_messages.dart';
// import 'package:project_first_model/router/auth_guard.dart';
// import 'package:project_first_model/router/router.gr.dart';

// class AddTripGuard extends AutoRouteGuard {
//   AddTripGuard();

//   @override
//   void onNavigation(NavigationResolver resolver, StackRouter router) async {
//     final authenticated = AuthGuard.isAuthenticated();
//     // ShowAnyMessages.showDialogMessage(
//     //   context,
//     //   'يبدو أنه لا يوجد لديك إتصال بشبكة الإنترنت \n يرجى التحقق من الإتصال والمحاولة لاحقاً',
//     //   'على الماشي ',
//     // );
//     if (authenticated) {
//       final empty = Get.find<UserController>().checkIfNotEmpty();
//       if (empty == null) {
//         resolver.next(true);
//       } else {
//         await ShowAnyMessages.showDialogMessage(
//           // context,
//           empty,
//           'لا يمكنك إضافة رحلة',
//         );
//         return;
//       }
//     } else {
//       final log = await ShowCustomDialog.notLoggedInUser();
//       if (log) {
//         router.replace(const RegisterScreenRouter());
//       } else {
//         resolver.next(false);
//       }
//     }
//   }
// }
