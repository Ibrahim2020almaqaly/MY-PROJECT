import 'package:auto_route/auto_route.dart';
import 'package:project_first_model/router/auth_guard.dart';
import 'package:project_first_model/router/logged_guard.dart';
import 'package:project_first_model/router/router.gr.dart';

final _showDriverPorfile = AutoRoute(
  path: ':driverId',
  page: ShowDriverProfileRoute.page,
  // children: [
  //   _showTripDataScreen,
  // ],
);

final _showTripDataScreen = AutoRoute(
  path: ':tripId',
  page: ShowTripDataRoute.page,
);

final _showTransporterProfile = AutoRoute(
  path: ':transporterId',
  page: ShowTransporterProfileRoute.page,
  // children: [
  //   _showTripDataScreen,
  // ],
);

final _mainScreenBodyRouter = AutoRoute(
  path: 'mainScreenBody',
  // name: 'MainScreenBodyRouter',
  page: MainScreenBodyRouter.page,
  children: [
    AutoRoute(
      path: '',
      page: HandelConnection.page,
    ),
    _showTripDataScreen,
    _showDriverPorfile,
    _showTransporterProfile,
    AutoRoute(
      path: 'tripsList',
      page: TripsListRoute.page,
      // children: [
      //   _showTripDataScreen,
      // ],
    ),
    AutoRoute(
      path: 'overlandTransportersList',
      page: OverlandTransportsListRoute.page,
      // children: [
      //   _showTransporterProfile,
      // ],
    ),
    AutoRoute(
      path: 'higherRateList',
      page: HigherRateListRoute.page,
      // children: [
      //   _showDriverPorfile,
      // ],
    ),
    AutoRoute(
      path: 'reportScreen',
      page: ReportRoute.page,
    ),
  ],
);

final _accountSettingsRouter = AutoRoute(
  path: 'accountSettingsScreen',
  // name: 'AccountSettingsScreenRouter',
  page: AccountSettingsScreenRouter.page,
  guards: [AuthGuard()],
  children: [
    AutoRoute(
      path: '',
      page: AccountSettingsRoute.page,
    ),
  ],
);

final _addTripRoute = AutoRoute(
  path: 'addTrip',
  // name: 'AddTripRouter',
  page: AddTripRouter.page,
  guards: [LoggedGuard()],
  fullscreenDialog: true,
);

final _searchTripRouter = AutoRoute(
  path: 'searchTrips',
  // name: 'SearchTripsRouter',
  page: SearchTripsRouter.page,
  children: [
    AutoRoute(
      path: '',
      page: SearchTrips.page,
      maintainState: false,
    ),
    AutoRoute(
      path: 'showFilterTripsPage',
      page: ShowFilterTripsRoute.page,
    ),
  ],
);

@AutoRouterConfig()
class AppRouter extends $AppRouter {
  @override
  RouteType get defaultRouteType => const RouteType.material();
  @override
  List<AutoRoute> get routes => [
        //splashScreen
        AutoRoute(
          path: '/',
          page: SplashScreenRouter.page,
          // name: 'SplashScreenRouter',
        ),
        //welcomeScreen
        AutoRoute(
          path: '/welcomeScreen',
          page: WelcomeScreenRouter.page,
          guards: [AuthGuard()],
          // name: 'welcomeScreenRouter',
        ),
        //mainScreen
        AutoRoute(
          path: '/mainScreen',
          // name: 'mainScreenRouter',
          page: MainScreenRouter.page,
          children: [
            AutoRoute(
              path: '',
              page: MainRoute.page,
              children: [
                //MainScreen Routers
                //we set this with EmptyRouterPage because when you have nested
                //routes inside bottom navigation bar
                //then we set the first child path with empty string
                //because we want to show that screen when we click to
                //the button this route is for MainScreen Section
                //we specified all possible routes on it
                _mainScreenBodyRouter,
                _accountSettingsRouter,
                _addTripRoute,
                _searchTripRouter,
              ],
            ),
          ],
        ),
        //registerScreenRouter
        AutoRoute(
          path: '/registerScreenRouter',
          // name: 'registerScreenRouter',
          page: RegisterScreenRouter.page,
        ),
        //otpScreen
        AutoRoute(
          path: '/otpScreen',
          // name: 'otpScreenRouter',
          page: OtpScreenRouter.page,
        ),
        //tripsHistoryListScreen
        AutoRoute(
          path: '/tripsHistoryListScreen',
          page: TripsHistoryListRoute.page,
        ),
        //viewMiniProfile
        AutoRoute(
          path: '/viewMiniProfile',
          page: ViewMiniProfileRoute.page,
          guards: [LoggedGuard()],
        ),
        //testScreen
        AutoRoute(
          path: '/testScreen',
          page: TestScreenRoute.page,
        ),
        //profileScreen
        AutoRoute(
          path: '/profileScreen',
          page: ProfileRoute.page,
          guards: [LoggedGuard()],
        ),
        //settingsScreen
        AutoRoute(
          path: '/settingsScreen',
          page: SettingsRoute.page,
        ),
        //AlarmsScreen
        AutoRoute(
          path: '/alarmScreen',
          page: AlarmsRoute.page,
          guards: [LoggedGuard()],
        ),
        //SuggestionScreen
        AutoRoute(
          path: '/suggestionScreen',
          page: SuggestionRoute.page,
          // guards: [AuthGuard],
        ),
        //ErrorReportScreen
        AutoRoute(
          path: '/errorReportScreen',
          page: ErrorReportRoute.page,
          // guards: [AuthGuard],
        ),
        //privacyPolicyScreen
        AutoRoute(
          path: '/privacyPolicyScreen',
          page: PrivacyPolicyRoute.page,
        ),
        //AboutScreen
        AutoRoute(
          path: '/AboutScreen',
          page: AboutRoute.page,
        ),
        //Notifications
        AutoRoute(
          path: '/notificationsScreen',
          page: NotificationsRoute.page,
        ),
        //DisabledAccountScreen
        AutoRoute(
          path: '/DisabledAccountScreen',
          page: DisabledAccountRoute.page,
        ),
      ];
}


// class Routes {
//   static const splashScreen = '/';
//   static const welcomeScreen = '/welcomeScreen';
//   static const mainPageName = '/mainScreen';
//   static const mainPageBodyName = '/mainScreenBody';
//   static const addtripName = '/addTrip';
//   static const searchtripName = '/searchTrips';
//   static const showFilterTripsPage = '/showFilterTripsPage';
//   static const accountSettingsScreen = '/accountSettingsScreen';
//   static const register = '/register';
//   static const _otp = '/otp';
//   static const tripsHistoryListScreen = '/tripsHistoryListScreen';
//   static const profileScreen = '/profileScreen';
//   static const viewMiniProfileScreen = '/viewMiniProfileScreen';
//   static const settingsScreen = '/settingsScreen';
//   static const alarmsScreen = '/alarmsScreen';
//   static const suggestionScreen = '/suggestionScreen';
//   static const errorReportScreen = '/errorReportScreen';
//   static const privacyPolicyScreen = '/privacyPolicyScreen';
//   static const aboutScreen = '/aboutScreen';
//   static const notificationsScreen = '/notificationsScreen';
//   static const disabledAccountScreen = '/disabledAccountScreen';
//   static const _showDriverProfileScreen = '/showDriverProfileScreen';
//   static const _showTripDataScreen = '/showTripDataScreen';
//   static const _showTransporterProfileScreen = '/showTransporterProfileScreen';
//   static const tripsListScreen = '/tripsListScreen';
//   static const overlandTransportsListScreen = '/overlandTransportsListScreen';
//   static const higherRateListScreen = '/higherRateListScreen';
//   static const testScreen = '/testScreen';
//   static const _reportScreen = '/reportScreen';
//   static String getShowDriverProfileScreen(String driverID) =>
//       '$_showDriverProfileScreen?driverID=$driverID';
//   static String getShowTripDataScreen(String tripID) =>
//       '$_showTripDataScreen?tripID=$tripID';
//   static String getShowTransporterProfileScreen(String transporterID) =>
//       '$_showTransporterProfileScreen?transporterID=$transporterID';
//   static String getDriverReportScreen(String driverID) =>
//       '$_reportScreen?driverID=$driverID';
//   static String getOTPScreen(String phoneNumber) =>
//       '$_otp?phoneNumber=$phoneNumber';
//   static final pages = [
//     // splash screen
//     GetPage(
//       name: splashScreen,
//       page: () {
//         return const SplashScreen();
//       },
//     ),
//     // Welcome Screen
//     GetPage(
//       name: welcomeScreen,
//       page: () {
//         return const WelcomeScreen();
//       },
//     ),
//     // main screen
//     GetPage(
//       name: mainPageName,
//       page: () => const MainScreen(),
//       binding: TripBinding(),
//       children: [
//         // main screen
//         GetPage(
//           name: mainPageBodyName,
//           maintainState: true,
//           page: () {
//             return const HandelConnection();
//           },
//           children: [
//             GetPage(
//               name: _showDriverProfileScreen,
//               page: () {
//                 return ShowDriverProfileScreen(
//                   driverId: Get.parameters['driverID']!,
//                 );
//               },
//             ),
//             GetPage(
//               name: _showTripDataScreen,
//               page: () {
//                 return ShowTripDataScreen(
//                   tripId: Get.parameters['tripID']!,
//                 );
//               },
//             ),
//             GetPage(
//               name: _showTransporterProfileScreen,
//               page: () {
//                 return ShowTransporterProfileScreen(
//                   transporterId: Get.parameters['transporterID']!,
//                 );
//               },
//             ),
//             GetPage(
//               name: tripsListScreen,
//               page: () {
//                 return const TripsListScreen();
//               },
//             ),
//             GetPage(
//               name: overlandTransportsListScreen,
//               page: () {
//                 return const OverlandTransportsListScreen();
//               },
//             ),
//             GetPage(
//               name: higherRateListScreen,
//               page: () {
//                 return const HigherRateListScreen();
//               },
//             ),
//           ],
//         ),
//         // add trip
//         GetPage(
//           name: addtripName,
//           page: () {
//             return const AddTripScreen();
//           },
//         ),
//         // search trip
//         GetPage(
//           name: searchtripName,
//           maintainState: true,
//           page: () {
//             return const SearchTrips();
//           },
//           children: [
//             GetPage(
//               name: showFilterTripsPage,
//               page: () {
//                 return const ShowFilterTripsPage();
//               },
//             ),
//           ],
//         ),
//         // accountSettings Screen
//         GetPage(
//           name: accountSettingsScreen,
//           page: () {
//             return const AccountSettingsScreen();
//           },
//         ),
//       ],
//     ),
//     // test Screen
//     GetPage(
//       name: testScreen,
//       page: () {
//         return const TestScreen();
//       },
//     ),
//     // Register
//     GetPage(
//       name: register,
//       page: () {
//         return const Register();
//       },
//     ),
//     // otp Screen
//     GetPage(
//       name: _otp,
//       page: () {
//         return Otp(
//           phoneNumber: Get.parameters['phoneNumber']!,
//         );
//       },
//     ),
//     // test Screen
//     GetPage(
//       name: tripsHistoryListScreen,
//       page: () {
//         return const TripsHistoryListScreen();
//       },
//     ),
//     // ViewMiniProfile Screen
//     GetPage(
//       name: viewMiniProfileScreen,
//       page: () {
//         return const ViewMiniProfileScreen();
//       },
//     ),
//     // Profile Screen
//     GetPage(
//       name: profileScreen,
//       page: () {
//         return const ProfileScreen();
//       },
//     ),
//     // Settings Screen
//     GetPage(
//       name: settingsScreen,
//       page: () {
//         return const SettingsScreen();
//       },
//     ),
//     // Alarms Screen
//     GetPage(
//       name: alarmsScreen,
//       page: () {
//         return const AlarmsScreen();
//       },
//     ),
//     // Suggestion Screen
//     GetPage(
//       name: suggestionScreen,
//       page: () {
//         return const SuggestionScreen();
//       },
//     ),
//     // ErrorReport Screen
//     GetPage(
//       name: errorReportScreen,
//       page: () {
//         return const ErrorReportScreen();
//       },
//     ),
//     // PrivacyPolicy Screen
//     GetPage(
//       name: privacyPolicyScreen,
//       page: () {
//         return const PrivacyPolicyScreen();
//       },
//     ),
//     // About Screen
//     GetPage(
//       name: aboutScreen,
//       page: () {
//         return const AboutScreen();
//       },
//     ),
//     // Notifications Screen
//     GetPage(
//       name: notificationsScreen,
//       page: () {
//         return const NotificationsScreen();
//       },
//     ),
//     // DisabledAccount Screen
//     GetPage(
//       name: disabledAccountScreen,
//       page: () {
//         return const DisabledAccountScreen();
//       },
//     ),
//     // report Screen
//     GetPage(
//       name: _reportScreen,
//       page: () {
//         return ReportScreen(
//           driverID: Get.parameters['driverID']!,
//         );
//       },
//     ),
//   ];
// }
