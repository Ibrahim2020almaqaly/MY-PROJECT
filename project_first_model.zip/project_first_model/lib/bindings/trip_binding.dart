import 'package:get/get.dart';
import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/trip_filter_controller.dart';

class TripBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(TripController(), permanent: true);
    Get.put(TripFilterController(), permanent: true);
    Get.put(RatingController(), permanent: true);
  }
}
