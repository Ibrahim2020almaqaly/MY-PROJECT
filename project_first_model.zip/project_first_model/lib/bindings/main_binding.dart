import 'package:get/get.dart';
import 'package:project_first_model/bindings/trip_binding.dart';
import 'package:project_first_model/controllers/alarm_controllers/alarm_controller.dart';
import 'package:project_first_model/controllers/bottom_nav_bar_controller.dart';
import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/driver_controllers/call_records_controller.dart';
import 'package:project_first_model/controllers/driver_controllers/report_controller.dart';
import 'package:project_first_model/controllers/feedback_controllers/error_report_controller.dart';
import 'package:project_first_model/controllers/feedback_controllers/privacy_controller.dart';
import 'package:project_first_model/controllers/feedback_controllers/suggestion_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/secondary_city_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_local_controller.dart';

class MainBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(ConnectionController(), permanent: true);
    Get.put(FirebaseAuthController(), permanent: true);
    Get.put(UserController(), permanent: true);
    Get.put(UserLocalController(), permanent: true);
    Get.lazyPut(() => CallRecordController(), fenix: true);
    Get.lazyPut(() => AlarmController(), fenix: true);
    Get.lazyPut(() => ReportController(), fenix: true);
    Get.lazyPut(() => SuggestionController(), fenix: true);
    Get.lazyPut(() => PrivacyController(), fenix: true);
    Get.lazyPut(() => ErrorReportController(), fenix: true);
    Get.lazyPut(() => BottomNavBarController(), fenix: true);
    Get.lazyPut(() => SecondaryCityController(), fenix: true);
    TripBinding().dependencies();
  }
}
