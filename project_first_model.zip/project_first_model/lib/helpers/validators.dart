import 'package:flutter/material.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';

class Validators {
  static String? validateNameField(String? value) {
    var empty = checkIfNotEmpty(value);
    if (empty != null) {
      return empty;
    }
    if (value!.length < 8) {
      return 'يجب أن يحتوي الإسم 8 حروف على الأقل';
    }
    return null;
  }

  static String? validateDateFormat(String? value) {
    var empty = checkIfNotEmpty(value);
    if (empty != null) {
      return empty;
    }
    try {
      DateTimeHelpers.convertStringToDate(value!);

      return null;
    } catch (_) {
      return 'الرجاء إدخال تاريخ صحيح';
    }
  }

  static String? validateDateField(String? value) {
    var empty = checkIfNotEmpty(value);
    if (empty != null) {
      return empty;
    }
    try {
      final fdate = DateTimeHelpers.convertStringToDate(value!);

      if (!DateTimeHelpers.isDateNOWAfter(fdate)) {
        return null;
      }
      return 'تاريخ اليوم أكبر من التاريخ المدخل';
    } catch (_) {
      return 'الرجاء إدخال تاريخ صحيح';
    }
  }

  static String? validateTimeField(String? value, String dateController) {
    var empty = checkIfNotEmpty(value);
    if (empty != null) {
      return empty;
    }
    try {
      final fdate = DateTimeHelpers.convertStringToDate(dateController);
      // final format = DateFormat(
      //     ShowDateTimePickers.returnTimeMode(
      //         value));
      final time = DateTimeHelpers.convertToTimeOfDayV2(value!);
      // TimeOfDay.fromDateTime(
      //     format.parse(value));
      final date = DateTimeHelpers.convertToDateTime(fdate, time);
      if (!DateTimeHelpers.isDateTimeNOWAfter(date)) {
        //DateTime.now().isAfter(date)
        return null;
      }
      return 'توقيت الآن أكبر من التوقيت المدخل';
    } catch (e) {
      return 'الرجاء إدخال وقت صحيح';
    }
  }

  static String? validateNumberField(String? value) {
    var empty = checkIfNotEmpty(value);
    if (empty != null) {
      return empty;
    }
    if (!value!.contains(RegExp(r'[0-9]'))) {
      return 'يجب أن يحتوي هذا الحقل على أرقام فقط';
    }
    return null;
  }

  static String? validateMoneyField(String? value) {
    var empty = validateNumberField(value);
    if (empty != null) {
      return empty;
    }
    try {
      var valDouble = double.parse(value!);
      if (valDouble < 0) {
        return 'يجب أن يحتوي هذا الحقل قيمة موجبة';
      }
      return null;
    } on Exception catch (_) {
      return 'يجب أن يحتوي هذا الحقل على أرقام فقط';
    }
  }

  static String? validatePhoneNumberField(String? value, [int atLeastNum = 9]) {
    var empty = checkIfNotEmpty(value);
    if (empty != null) {
      return empty;
    }
    var isNumber = validateNumberField(value);
    if (isNumber != null) {
      return isNumber;
    } else {
      if (value!.length < atLeastNum) {
        return 'يجب أن يحتوي الرقم $atLeastNum أرقام على الأقل';
      }
      return null;
    }
  }

  static String? checkIfNotEmpty(String? value) {
    if (value != null && value.trim().isNotEmpty && value != '') {
      return null;
    }
    return 'لا يمكن أن يكون الحقل فارغاً';
  }

  static String? validateListsField(
    String? value,
    List<TextEditingController>? otherControlersValues,
    String typeName,
    bool allowNullValue,
    List<String> fieldList,
  ) {
    if (value != null && value.isNotEmpty && value != '') {
      for (var i = 0; i < (otherControlersValues?.length ?? 0); i++) {
        if (otherControlersValues![i].text.trim() == value.trim()) {
          return 'إسم $typeName موجود في حقل آخر';
        }
      }

      if (fieldList.contains(value)) {
        return null;
      } else {
        return 'الرجاء كتابة إسم $typeName موجود في القائمة';
      }
    }
    if (allowNullValue) {
      return null;
    }
    return 'لا يمكن أن يكون هذا الحقل فارغاً';
  }
}
