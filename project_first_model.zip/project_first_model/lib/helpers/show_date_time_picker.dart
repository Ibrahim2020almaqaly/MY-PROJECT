import 'package:flutter/material.dart';
import 'package:flutter_rounded_date_picker/flutter_rounded_date_picker.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:project_first_model/controllers/theme_controller.dart';

import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/router/router.dart';

class ShowDateTimePickers {
  ShowDateTimePickers() {
    initializeDateFormatting('en_US', null);
  }

  static Future<String> showCustomDatePicker(
    // BuildContext context,
    String? currentValue, {
    bool firstDateYearAgo = false,
    bool lastDateAfterYear = false,
    DateTime? firstDate,
    DateTime? lastDate,
  }) async {
    var curDate = DateTime.now();

    if (currentValue != null && currentValue != '') {
      curDate = DateTimeHelpers.convertStringToDate(currentValue);
    }

    var firstDateLocal = curDate;

    if (firstDate != null) {
      firstDateLocal = firstDate;
    } else if (firstDate == null && firstDateYearAgo) {
      firstDateLocal = firstDateLocal.subtract(
        const Duration(
          days: 360,
        ),
      );
    }

    final now = DateTime.now();

    var lastDateLocal = DateTime(
      now.year,
      now.month,
      now.day,
      now.hour,
      now.minute,
    );

    if (lastDate != null) {
      lastDateLocal = lastDate;
    } else if (lastDate == null && lastDateAfterYear) {
      lastDateLocal = lastDateLocal.add(
        const Duration(days: 360),
      );
    } else {
      lastDateLocal = lastDateLocal.add(
        const Duration(days: 7),
      );
    }
    final context = Get.find<AppRouter>().navigatorKey.currentContext!;

    final theme = Theme.of(context);

    final pickedDate = await showRoundedDatePicker(
      context: context,
      barrierDismissible: true,
      initialDate: curDate,
      firstDate: firstDateLocal,
      lastDate: lastDateLocal,
      height: 800.h,
      fontFamily: theme.textTheme.bodyLarge?.fontFamily,
      theme: theme.copyWith(
        brightness: theme.brightness,
        primaryColor: theme.colorScheme.primary,
        // textTheme: theme.textTheme.copyWith(
        //   caption: theme.textTheme.caption,
        //   bodyText2: theme.textTheme.bodyText2,
        //   headline1: theme.textTheme.headline2,
        // ),
        // colorScheme: theme.colorScheme.copyWith(
        //   secondary: theme.iconTheme.color,
        // ),
        dialogBackgroundColor: theme.colorScheme.background,
      ),
      description: 'من الأفضل إختيار تاريخ أقرب رحلة "مثل تاريخ الغد"',
      textNegativeButton: 'إلغاء',
      textPositiveButton: 'تأكيد',
      customWeekDays: [
        'سبت',
        'أحد',
        'إثنين',
        'ثلوث',
        'ربوع',
        'خميس',
        'جمعة',
      ],
      builderDay: (dateTime, isCurrentDay, selected, defaultTextStyle) {
        final dateOnly = DateTimeHelpers.getDateOnly(dateTime);
        final nowDateOnly = DateTimeHelpers.getDateOnly(now);
        final isTomorrow =
            dateOnly.compareTo(nowDateOnly.add(const Duration(days: 1))) == 0;
        final isAfterTomorrow =
            dateOnly.compareTo(nowDateOnly.add(const Duration(days: 2))) == 0;
        const tomorrowText = 'غدا';
        const afterTomorrowText = 'بعد غد';
        const todayText = 'اليوم';
        if (selected) {
          final isDark = Get.find<ThemeController>().isDarkMode;
          return Container(
            decoration: BoxDecoration(
              color: theme.appBarTheme.iconTheme?.color,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                isCurrentDay
                    ? todayText
                    : isTomorrow
                        ? tomorrowText
                        : isAfterTomorrow
                            ? afterTomorrowText
                            : dateTime.day.toString(),
                style: defaultTextStyle.copyWith(
                  color: isDark ? Colors.black : Colors.white,
                  fontSize: 36.sp,
                ),
                textAlign: TextAlign.center,
                softWrap: true,
              ),
            ),
          );
        }
        if (isCurrentDay) {
          return _textDate(
            todayText,
            defaultTextStyle,
          );
        }
        if (isTomorrow) {
          return _textDate(
            tomorrowText,
            defaultTextStyle,
          );
        }
        if (isAfterTomorrow) {
          return _textDate(
            afterTomorrowText,
            defaultTextStyle,
          );
        }
        return Center(
          child: _textDate(
            dateTime.day.toString(),
            defaultTextStyle,
          ),
        );
      },
      onTapDay: (dateTime, available) {
        if (!available) {
          ShowAnyMessages.faildTask(
            context,
            'هذا التاريخ غير متاح!',
            showIcon: false,
          );
        }
        return available;
      },
    );

    // final pickedDate = await showDatePicker(
    //   context: context,
    //   initialDate: curDate,
    //   firstDate: firstDateLocal,
    //   lastDate: lastDateLocal,
    //   helpText: 'من الأفضل إختيار تاريخ أقرب رحلة "مثل تاريخ الغد"',
    //   cancelText: 'إلغاء',
    //   confirmText: 'تأكيد',
    //   errorFormatText: 'الرجاء كتابة تنسيق صحيح للتاريخ',
    //   errorInvalidText: 'هذا التنسيق غير صحيح',
    //   fieldHintText: '${curDate.year / curDate.month / curDate.day}',
    //   fieldLabelText: 'أكتب التاريخ',
    // );

    if (pickedDate == null) {
      if (currentValue != null && currentValue != '') {
        return currentValue;
      }
      return ''; // DateTimeHelpers.convertDateToString(curDate);
    }
    // DateFormat.yMd().format(DateTime.now());

    return DateTimeHelpers.convertDateToString(pickedDate);
    // DateFormat.yMd().format(pickedDate);
  }

  static Center _textDate(String text, TextStyle defaultTextStyle) {
    return Center(
      child: Text(
        text,
        style: defaultTextStyle,
        textAlign: TextAlign.center,
      ),
    );
  }

  static Future<String> showCustomTimePicker(
    // BuildContext context,
    String? currentValue,
  ) async {
    final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    var curTime = TimeOfDay.now();
    if (currentValue != null && currentValue != '') {
      curTime = DateTimeHelpers.convertToTimeOfDayV2(currentValue);
    }

    // final theme = Theme.of(context);
    // final pickedTime = await showRoundedTimePicker(
    //   context: context,
    //   initialTime: curTime,
    //   negativeBtn: 'إلغاء',
    //   positiveBtn: 'تأكيد',
    //   fontFamily: theme.textTheme.headlineMedium?.fontFamily,
    //   barrierDismissible: true,
    //   theme: theme,
    //   // .copyWith(
    //   //     brightness: theme.brightness,
    //   //     primaryColor: theme.colorScheme.primary,
    //   //     textTheme: theme.textTheme.copyWith(
    //   //       caption: theme.textTheme.caption,
    //   //       bodyText2: theme.textTheme.bodyText2,
    //   //       headline1: theme.textTheme.headline2,
    //   //     ),
    //   //     colorScheme: theme.colorScheme.copyWith(
    //   //       secondary: theme.iconTheme.color,
    //   //     ),
    //   //     dialogBackgroundColor: theme.colorScheme.background,
    //   //     ),
    // );

    final pickedTime = await showTimePicker(
      context: context,
      initialTime: curTime,
      cancelText: 'إلغاء',
      confirmText: 'تأكيد',
      helpText: 'حدد وقت الرحلة',
      errorInvalidText: 'الرجاء كتابة وقت صحيح',
      hourLabelText: 'الساعة',
      minuteLabelText: 'الدقيقة',
    );

    if (pickedTime == null) {
      if (currentValue != null && currentValue != '') {
        return currentValue;
      }
      return ''; //TimeOfDay.now().format(context);
    }
    if (context.mounted) {
      var time = pickedTime.format(context);
      final amPmTIme = pickedTime.format(context).substring(time.length - 2);
      if (amPmTIme.contains('ص')) {
        time = time.replaceRange(time.indexOf('ص'), null, 'AM');
      } else if (amPmTIme.contains('م')) {
        time = time.replaceRange(time.indexOf('م'), null, 'PM');
      }
      return time;
    }
    return currentValue ?? '';
  }
}
