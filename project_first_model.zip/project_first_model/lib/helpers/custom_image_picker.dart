import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_native_image/flutter_native_image.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart' as syspaths;

class CustomImagePicker {
  static Future<String?> showImagePicker(
    ImageSource imageSource, {
    bool isCircle = false,
    bool saveIntoDevice = false,
  }) async {
    final image = await ImagePicker().pickImage(
      source: imageSource,
      // maxWidth: 500,
      // maxHeight: 500,
      // imageQuality: 50,
    );
    if (image == null) {
      return null;
    }

    // File imageFile = File(image.path);

    final tempImage = await _cropImage(
          image.path,
          isCircle ? CropStyle.circle : CropStyle.rectangle,
        ) ??
        image.path;
    File imageFile = File(tempImage);
    imageFile = await compressImage(imageFile);

    if (!saveIntoDevice) {
      return imageFile.path;
    }

    final appDir = await syspaths.getExternalStorageDirectory();
    final imageName = path.basename(tempImage);
    final saveDir = '${appDir?.path}/$imageName';
    final newImage = await imageFile.copy(saveDir);
    newImage.create();
    // await image.saveTo(saveDir);
    return newImage.path;
  }

  static Future<File> compressImage(File image) {
    return FlutterNativeImage.compressImage(
      image.absolute.path,
      quality: 100,
      percentage: 60,
    );
  }

  static Future<String?> _cropImage(String path, CropStyle cropStyle) async {
    final cropped = await ImageCropper().cropImage(
      sourcePath: path,
      aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
      aspectRatioPresets: [CropAspectRatioPreset.square],
      // compressQuality: 50,
      // maxHeight: 600,
      // maxWidth: 600,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'قص الصورة',
          toolbarColor: Colors.teal,
          toolbarWidgetColor: Colors.white,
          hideBottomControls: true,
          lockAspectRatio: true,
        ),
      ],
      cropStyle: cropStyle,
    );

    if (cropped == null) {
      return null;
    }
    return cropped.path;
  }
}
