import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:project_first_model/router/router.dart';

class CustomOverlayLoading {
  static void showOverlayLoading() {
    final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    context.loaderOverlay.show();
  }

  static bool isLoading() {
    final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    return context.loaderOverlay.visible;
  }

  static void hideOverlayLoading() {
    final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    final isvisible = context.loaderOverlay.visible;
    if (isvisible) {
      context.loaderOverlay.hide();
    }
  }
}
