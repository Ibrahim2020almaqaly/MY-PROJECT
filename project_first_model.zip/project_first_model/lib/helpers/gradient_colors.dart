import 'package:flutter/painting.dart';

class GradientColors {
  final List<Color> colors;
  GradientColors(this.colors);
  // 5 AM - 9 AM
  static List<Color> fire = const [Color(0xFFFF5DCD), Color(0xFFFF8484)];
  // 9 AM - 4 PM
  static List<Color> mango = const [Color(0xFFFFA738), Color(0xFFFFE130)];
  // 4 PM - 6:30 PM
  static List<Color> sunset = const [Color(0xFFFE6197), Color(0xFFFFB463)];
  // 6:30 PM - 3 AM
  static List<Color> sky = const [Color(0xFF6448FE), Color(0xFF5FC6FF)];
  // 3 AM - 5 AM
  static List<Color> sea = const [Color(0xFF61A3FE), Color(0xFF63FFD5)];
}

class GradientTemplates {
  static List<GradientColors> alarmGradientTemplate = [
    GradientColors(GradientColors.fire),
    GradientColors(GradientColors.mango),
    GradientColors(GradientColors.sunset),
    GradientColors(GradientColors.sky),
    GradientColors(GradientColors.sea),
  ];
}
