import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:image_picker/image_picker.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/services/app_info.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';

class ShowCustomDialog {
  static void showCustomAboutDialog(BuildContext context) {
    // Get.generalDialog(
    //   pageBuilder: (ctx, animation, secondaryAnimation) {
    //     return AlertDialog(
    //       title: Row(
    //         children: [
    //           AppInfo.appIcon(),
    //           const HorizantalSizedBox(15.0),
    //           AppInfo.getAppInfo,
    //         ],
    //       ),
    //       content: Column(
    //         mainAxisSize: MainAxisSize.min,
    //         children: [
    //           const VerticalSizedBox(15),
    //           ImageHelpers.getLottieAssetImage(
    //             500,
    //             400,
    //             Assets.lottieIcons.aboutUs,
    //           ),
    //           const VerticalSizedBox(15),
    //           CustomTextButton(
    //             allowRegisterOnly: false,
    //             title: 'الإطلاع على سياسة الخصوصية',
    //             onPressed: () {
    //               // Get.toNamed(Routes.privacyPolicyScreen);
    //               Get.find<AppRouter>().push(const PrivacyPolicyScreenRoute());
    //             },
    //           ),
    //         ],
    //       ),
    //       actions: [
    //         CustomTextButton(
    //           onPressed: () {
    //             // Navigator.of(ctx).pop();
    //             Get.back();
    //           },
    //           allowOnlineOnly: false,
    //           allowRegisterOnly: false,
    //           title: 'موافق',
    //           textStyle: TextStyle(
    //             fontSize: 44.sp,
    //             fontWeight: FontWeight.bold,
    //           ),
    //         ),
    //       ],
    //     );
    //   },
    // );

    // final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Row(
            children: [
              AppInfo.appIcon(),
              const HorizantalSizedBox(15.0),
              AppInfo.getAppInfo,
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const VerticalSizedBox(15),
              ImageHelpers.getLottieAssetImage(
                500,
                400,
                Assets.lottieIcons.aboutUs,
              ),
              const VerticalSizedBox(15),
              CustomTextButton(
                allowRegisterOnly: false,
                title: 'الإطلاع على سياسة الخصوصية',
                onPressed: () {
                  Get.find<AppRouter>().push(const PrivacyPolicyRoute());
                },
              ),
            ],
          ),
          actions: [
            CustomTextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
              },
              allowOnlineOnly: false,
              allowRegisterOnly: false,
              title: 'موافق',
              textStyle: TextStyle(
                fontSize: 44.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        );
      },
    );
  }

  static Future<void> showContactUsDialog(BuildContext context) async {
    // Get.generalDialog(
    //   pageBuilder: (context, animation, secondaryAnimation) {
    //     final theme = Theme.of(context);
    //     return AlertDialog(
    //       title: Row(
    //         children: [
    //           AppInfo.appIcon(),
    //           const HorizantalSizedBox(20),
    //           AppInfo.getAppInfo,
    //         ],
    //       ),
    //       content: Column(
    //         mainAxisSize: MainAxisSize.min,
    //         children: [
    //           Text(
    //             'للتواصل معنا',
    //             style: TextStyle(
    //               fontSize: 46.sp,
    //               fontWeight: FontWeight.bold,
    //             ),
    //             textAlign: TextAlign.center,
    //           ),
    //           const VerticalSizedBox(15),
    //           ImageHelpers.getLottieAssetImage(
    //             500,
    //             400,
    //             Assets.lottieIcons.callCenterSupport,
    //           ),
    //           const VerticalSizedBox(15),
    //           RichText(
    //             textAlign: TextAlign.center,
    //             text: TextSpan(
    //               text: 'يرجى التواصل معنا عير الإيميل:\n',
    //               style: TextStyle(
    //                 color: theme.textTheme.bodyLarge?.color,
    //                 fontSize: 46.sp,
    //                 fontFamily: 'Cairo',
    //               ),
    //               children: [
    //                 TextSpan(
    //                   style: TextStyle(
    //                     color: theme.appBarTheme.actionsIconTheme?.color,
    //                     fontSize: 40.sp,
    //                     decoration: TextDecoration.underline,
    //                   ),
    //                   text: 'masterzteamsupprt@gmail.com\n',
    //                   recognizer: TapGestureRecognizer()
    //                     ..onTap = () {
    //                       Utiles.email('masterzteamsupprt@gmail.com');
    //                     },
    //                 ),
    //                 // const WidgetSpan(child: VerticalSizedBox(30.0)),
    //                 // TextSpan(
    //                 //   text: 'أو الأرقام التالية: \n',
    //                 //   style: TextStyle(
    //                 //     color: theme.textTheme.bodyText1?.color,
    //                 //     fontSize: 46.sp,
    //                 //   ),
    //                 //   children: [
    //                 //     _span('+967777853116',
    //                 //         theme.appBarTheme.actionsIconTheme?.color,),
    //                 //     _span('+967775682995',
    //                 //         theme.appBarTheme.actionsIconTheme?.color,),
    //                 //     _span(
    //                 //       '+967775557889',
    //                 //       theme.appBarTheme.actionsIconTheme?.color,
    //                 //       isLast: true,
    //                 //     ),
    //                 //   ],
    //                 // ),
    //               ],
    //             ),
    //           ),
    //         ],
    //       ),
    //       actions: [
    //         TextButton(
    //           onPressed: () {
    //             Get.back();
    //             // Navigator.of(context).pop();
    //           },
    //           child: Text(
    //             'موافق',
    //             style: TextStyle(
    //               fontSize: 44.sp,
    //               fontWeight: FontWeight.bold,
    //             ),
    //           ),
    //         ),
    //       ],
    //     );
    //   },
    // );

    // final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    await showDialog(
      context: context,
      builder: (ctx) {
        final theme = Theme.of(context);
        return AlertDialog(
          title: Row(
            children: [
              AppInfo.appIcon(),
              const HorizantalSizedBox(20),
              AppInfo.getAppInfo,
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'للتواصل معنا',
                style: TextStyle(
                  fontSize: 46.sp,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const VerticalSizedBox(15),
              ImageHelpers.getLottieAssetImage(
                500,
                400,
                Assets.lottieIcons.callCenterSupport,
              ),
              const VerticalSizedBox(15),
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: 'يرجى التواصل معنا عير الإيميل:\n',
                  style: TextStyle(
                    color: theme.textTheme.bodyLarge?.color,
                    fontSize: 46.sp,
                    fontFamily: 'Cairo',
                  ),
                  children: [
                    TextSpan(
                      style: TextStyle(
                        color: theme.appBarTheme.actionsIconTheme?.color,
                        fontSize: 40.sp,
                        decoration: TextDecoration.underline,
                      ),
                      text: 'masterzteamsupprt@gmail.com\n',
                      recognizer: TapGestureRecognizer()
                        ..onTap = () {
                          Utiles.email('masterzteamsupprt@gmail.com');
                        },
                    ),
                    // const WidgetSpan(child: VerticalSizedBox(30.0)),
                    // TextSpan(
                    //   text: 'أو الأرقام التالية: \n',
                    //   style: TextStyle(
                    //     color: theme.textTheme.bodyText1?.color,
                    //     fontSize: 46.sp,
                    //   ),
                    //   children: [
                    //     _span('+967777853116',
                    //         theme.appBarTheme.actionsIconTheme?.color,),
                    //     _span('+967775682995',
                    //         theme.appBarTheme.actionsIconTheme?.color,),
                    //     _span(
                    //       '+967775557889',
                    //       theme.appBarTheme.actionsIconTheme?.color,
                    //       isLast: true,
                    //     ),
                    //   ],
                    // ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
              },
              child: Text(
                'موافق',
                style: TextStyle(
                  fontSize: 44.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  static GestureRecognizer _call(String number) {
    return TapGestureRecognizer()
      ..onTap = () {
        Utiles.call(number);
      };
  }

  static TextSpan span(
    String number,
    Color? color, {
    bool isLast = false,
  }) {
    return TextSpan(
      style: TextStyle(
        color: color,
        fontSize: 40.sp,
        decoration: TextDecoration.underline,
      ),
      text: '$number ${(isLast ? '' : '\n')} ',
      recognizer: _call(number),
    );
  }

  static Future<String?> showCustomDialogPicker(
    BuildContext context,
    Future<String?> Function(
      ImageSource imageSource, {
      bool isCircle,
      bool saveIntoDevice,
    }) imageHandeler, {
    bool isCircle = false,
    bool saveToDevice = false,
  }) {
    // Get.dialog<String>(
    //   Padding(
    //     padding: CustomEdgeInsets.all(16.0),
    //     child: Column(
    //       mainAxisAlignment: MainAxisAlignment.start,
    //       mainAxisSize: MainAxisSize.min,
    //       children: [
    //         const VerticalSizedBox(42),
    //         TextButton.icon(
    //           icon: const Icon(Icons.photo_library_outlined),
    //           label: const Text('المعرض'),
    //           onPressed: () async {
    //             final imagePath = await imageHandeler(
    //               ImageSource.gallery,
    //               isCircle: isCircle,
    //               saveIntoDevice: saveToDevice,
    //             );
    //             Get.back(result: imagePath);
    //             // if (context.mounted) {
    //             //   Navigator.of(context).pop(imagePath);
    //             // }
    //           },
    //         ),
    //         const VerticalSizedBox(42),
    //         TextButton.icon(
    //           icon: const Icon(Icons.camera_outlined),
    //           label: const Text('كاميرا'),
    //           onPressed: () async {
    //             final imagePath = await imageHandeler(
    //               ImageSource.camera,
    //               isCircle: isCircle,
    //               saveIntoDevice: saveToDevice,
    //             );
    //             Get.back(result: imagePath);
    //             // if (context.mounted) {
    //             //   Navigator.of(context).pop(imagePath);
    //             // }
    //           },
    //         ),
    //       ],
    //     ),
    //   ),
    // final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    return showDialog<String>(
      context: context,
      // barrierDismissible: false,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: CustomEdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const VerticalSizedBox(42),
                TextButton.icon(
                  icon: const Icon(Icons.photo_library_outlined),
                  label: const Text('المعرض'),
                  onPressed: () async {
                    final imagePath = await imageHandeler(
                      ImageSource.gallery,
                      isCircle: isCircle,
                      saveIntoDevice: saveToDevice,
                    );
                    Get.find<AppRouter>().pop(imagePath);
                    // if (context.mounted) {
                    //   Navigator.of(context).pop(imagePath);
                    // }
                  },
                ),
                const VerticalSizedBox(42),
                TextButton.icon(
                  icon: const Icon(Icons.camera_outlined),
                  label: const Text('كاميرا'),
                  onPressed: () async {
                    final imagePath = await imageHandeler(
                      ImageSource.camera,
                      isCircle: isCircle,
                      saveIntoDevice: saveToDevice,
                    );
                    Get.find<AppRouter>().pop(imagePath);
                    // if (context.mounted) {
                    //   Navigator.of(context).pop(imagePath);
                    // }
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  ///the default is yes or no question
  ///to customize it edit the 'yse' ,'no' parameters
  static Future<bool> showConfirmationDialogMessage(
    BuildContext context,
    String message,
    String title, {
    String yseBtn = 'نعم',
    String noBtn = 'لا',
    String? icon,
  }) async {
    // return await Get.defaultDialog<bool>(
    //       content: Column(
    //         mainAxisSize: MainAxisSize.min,
    //         children: [
    //           // Text(
    //           //   title,
    //           //   style: TextStyle(
    //           //     fontSize: 46.sp,
    //           //     fontWeight: FontWeight.bold,
    //           //   ),
    //           //   textAlign: TextAlign.center,
    //           // ),
    //           // const VerticalSizedBox(30),
    //           if (icon != null)
    //             ImageHelpers.getLottieAssetImage(
    //               500,
    //               400,
    //               icon,
    //             ),
    //           Text(
    //             message,
    //             textAlign: TextAlign.center,
    //             style: TextStyle(
    //               fontSize: 40.sp,
    //             ),
    //           ),
    //         ],
    //       ),
    //       title: title,
    //       titleStyle: TextStyle(
    //         fontSize: 46.sp,
    //         fontWeight: FontWeight.bold,
    //       ),
    //       titlePadding: CustomEdgeInsets.only(top: 30),
    //       actions: [
    //         TextButton(
    //           onPressed: () {
    //             // Navigator.of(ctx).pop(true);
    //             Get.back(result: true);
    //           },
    //           child: Text(
    //             yseBtn,
    //             style: TextStyle(
    //               fontSize: 44.sp,
    //               fontWeight: FontWeight.bold,
    //             ),
    //           ),
    //         ),
    //         TextButton(
    //           onPressed: () {
    //             // Navigator.of(ctx).pop(false);
    //             Get.back(result: false);
    //           },
    //           child: Text(
    //             noBtn,
    //             style: TextStyle(
    //               color: Colors.grey,
    //               fontSize: 44.sp,
    //             ),
    //           ),
    //         ),
    //       ],
    //     ) ??
    //     false;

    // final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    return await showDialog<bool>(
          context: context,
          builder: (ctx) {
            return AlertDialog(
              title: Row(
                children: [
                  AppInfo.appIcon(),
                  const HorizantalSizedBox(30),
                ],
              ),
              // title: title,
              // titleTextStyle: TextStyle(
              //   fontSize: 46.sp,
              //   fontWeight: FontWeight.bold,
              // ),
              // titlePadding: CustomEdgeInsets.only(top: 30),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 46.sp,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const VerticalSizedBox(30),
                  if (icon != null)
                    ImageHelpers.getLottieAssetImage(
                      500,
                      400,
                      icon,
                    ),
                  Text(
                    message,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 40.sp,
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Get.find<AppRouter>().pop(true);
                    // Navigator.of(ctx).pop(true);
                  },
                  child: Text(
                    yseBtn,
                    style: TextStyle(
                      fontSize: 44.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Get.find<AppRouter>().pop(false);
                    // Navigator.of(ctx).pop(false);
                  },
                  child: Text(
                    noBtn,
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 44.sp,
                    ),
                  ),
                ),
              ],
            );
          },
        ) ??
        false;
  }

  static Future<bool> notLoggedInUser(BuildContext context) async {
    final log = await showConfirmationDialogMessage(
      context,
      'يجب عليك تسجيل الدخول لإكمال العملية',
      'لا يوجد حساب',
      noBtn: 'إلغاء',
      yseBtn: 'تسجيل حساب',
      icon: Assets.lottieIcons.registerAnumator,
    );
    // if (log) {
    //   // Navigator.of(context).pushNamed(Register.routeName);
    //   Get.find<AppRouter>().push(const RegisterScreenRouter());
    // }
    return log;
  }

  static Future<void> notLoggedInUserWithNavigation(
      BuildContext context) async {
    final log = await notLoggedInUser(context);

    if (log) {
      // Get.toNamed(Routes.register);
      Get.find<AppRouter>().push(const RegisterScreenRouter());
    }
  }
}
