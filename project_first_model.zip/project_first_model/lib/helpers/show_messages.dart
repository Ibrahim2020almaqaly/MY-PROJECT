import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';

const noCONNECTIONMSG =
    'يبدو أنه لا يوجد لديك إتصال بشبكة الإنترنت \n يرجى التحقق من الإتصال والمحاولة لاحقاً';
const appNAME = 'على الطريق';

class ShowAnyMessages {
  static Future<void> noConnMsg(BuildContext context) async {
    await showDialogMessage(
      context,
      noCONNECTIONMSG,
      'الإتصال مقطوع',
      icon: Assets.lottieIcons.animationIcon02Nowifi,
    );
  }

  static Future<void> faildTask(BuildContext context, String message,
      {String title = 'فشل العملية', bool showIcon = true}) async {
    await showDialogMessage(
      context,
      message,
      title,
      icon: showIcon ? Assets.lottieIcons.failedTask : null,
    );
  }

  static Future<void> showDialogMessage(
      BuildContext context, String message, String title,
      {String? icon}) async {
    final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    await showGeneralDialog(
      context: context,
      pageBuilder: (context, animation, secondaryAnimation) {
        return AlertDialog(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 55.sp,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const VerticalSizedBox(30),
              if (icon != null)
                ImageHelpers.getLottieAssetImage(
                  600,
                  400,
                  icon,
                ),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 40.sp,
                ),
              ),
            ],
          ),
          // title: Row(
          //   children: [
          //     AppInfo.appIcon(),
          //     // const HorizantalSizedBox(12),
          //     // Text(
          //     //   title,
          //     // ),
          //   ],
          // ),
          actions: [
            Center(
              child: CustomTextButton(
                onPressed: () {
                  // Get.back();
                  Get.find<AppRouter>().pop();
                },
                allowOnlineOnly: false,
                allowRegisterOnly: false,
                title: 'موافق',
                textStyle: TextStyle(
                  fontSize: 44.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
          // title: title,
          // titleTextStyle: TextStyle(
          //   fontSize: 55.sp,
          //   fontWeight: FontWeight.bold,
          // ),
          // titlePadding: CustomEdgeInsets.only(top: 40),
        );
      },
      barrierDismissible: false,
    );
  }

  static void showSnackBar(
    BuildContext context,
    String message, {
    bool isError = false,
    bool floating = true,
    bool isSuccess = false,
  }) {
    // Get.closeCurrentSnackbar();
    // final context = Get.find<AppRouter>().navigatorKey.currentContext!;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    // Get.showSnackbar(
    //   GetSnackBar(
    //     messageText: Text(
    //       message,
    //       style: const TextStyle(
    //         color: Colors.white,
    //       ),
    //       softWrap: true,
    //       textAlign: TextAlign.center,
    //     ),
    //     snackPosition: floating ? SnackPosition.TOP : SnackPosition.BOTTOM,
    //     snackStyle: floating ? SnackStyle.FLOATING : SnackStyle.GROUNDED,
    //     backgroundColor: isSuccess
    //         ? Colors.green
    //         : isError
    //             ? Colors.red
    //             : const Color(0xFF303030),
    //     duration: const Duration(seconds: 3),
    //     animationDuration: const Duration(seconds: 1),
    //     overlayBlur: 0.5,
    //     barBlur: 0.5,
    //   ),
    // );

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: floating ? SnackBarBehavior.floating : SnackBarBehavior.fixed,
        content: Text(
          message,
          softWrap: true,
        ),
        backgroundColor: isSuccess
            ? Colors.green
            : isError
                ? Colors.red
                : null,
      ),
    );
  }

  static void showToastMSG(String message) async {
    await Fluttertoast.cancel();
    Fluttertoast.showToast(
      msg: message,
      fontSize: 44.sp,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.SNACKBAR,
    );
  }

  // static bool _isFirst = true;
  // static bool isSame = false;
  // static void showSimpleNotificationMessage(bool isOnline) {
  //   if (isSame != isOnline) {
  //     if (!_isFirst) {
  //       // showSimpleNotification(
  //       //   Text(
  //       //     isOnline ? 'متصل بالإنترنت !' : 'غير متصل بالإنترنت !',
  //       //     style: TextStyle(
  //       //       color: Colors.white,
  //       //       fontSize: 50.sp,
  //       //     ),
  //       //     textAlign: TextAlign.center,
  //       //   ),
  //       //   background: isOnline ? Colors.green : Colors.red,
  //       //   duration: const Duration(seconds: 2),
  //       // );
  //     }
  //     isSame = isOnline;
  //   }
  //   _isFirst = false;
  // }
}
