import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:url_launcher/url_launcher.dart';

class Utiles {
  static const privacyPolicyURL = "https://sites.google.com/view/mashyapp/home";
  static const suppurtEmail = "masterzteamsupprt@gmail.com";

  static Future<String> downloadFile(String url, String fileName) async {
    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/ $fileName';
    final response = await http.get(Uri.parse(url));
    final file = File(filePath);

    await file.writeAsBytes(response.bodyBytes);

    return filePath;
  }

  static Future<bool> deleteItem(BuildContext context,
      {String? message}) async {
    final res = await ShowCustomDialog.showConfirmationDialogMessage(
      context,
      message ?? 'هل فعلا تريد الحذف؟',
      'تأكيد الحذف',
      icon: Assets.lottieIcons.deleteBin,
    );

    return res;
  }

  static Future<bool> editItem(BuildContext context, {String? message}) async {
    final res = await ShowCustomDialog.showConfirmationDialogMessage(
      context,
      message ?? 'هل فعلا تريد تعديل البيانات؟',
      'تأكيد التعديل',
      icon: Assets.lottieIcons.drawingPencilEdit,
    );

    return res;
  }

  static Future<bool> replaceItem(BuildContext context,
      {String? message}) async {
    final res = await ShowCustomDialog.showConfirmationDialogMessage(
      context,
      message ?? 'هل فعلا تريد الإستبدال على السابق؟',
      'تأكيد الإستبدال',
      icon: Assets.lottieIcons.replacement,
    );

    return res;
  }

  static String generateRandomString() {
    final rand = Random();
    final results = String.fromCharCodes(
        List.generate(20, (index) => rand.nextInt(33) + 89));

    return results;
  }

  static String getCountString(int count) {
    if (count < 1000) {
      return count.toString();
    } else if ((count / 1000) < 1000) {
      final stringCount = (count / 1000).truncate();
      return '${stringCount}K';
    } else if ((count / 1000000) < 1000) {
      final stringCount = (count / 1000000).truncate();
      return '${stringCount}M';
    }
    return count.toString();
  }

  static Future<void> call(String phoneNumber) async {
    try {
      final tel = 'tel: $phoneNumber';
      final uri = Uri.parse(tel);
      final canLaunch = await canLaunchUrl(uri);
      if (canLaunch) {
        await launchUrl(uri);
      }
    } on Exception catch (_) {
      rethrow;
    }
  }

  static String? encodeQueryParameter(Map<String, String> param) {
    return param.entries
        .map((e) =>
            '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
        .join('&');
  }

  static Future<void> email(
    String email, {
    bool isLinkFull = false,
    String subject = '',
    String body = '',
  }) async {
    late Uri uri;
    if (isLinkFull) {
      uri = Uri.parse(email);
      return;
    } else {
      uri = Uri(
        scheme: 'mailto',
        path: email,
        query: encodeQueryParameter({
          'subject': subject,
          'body': body,
        }),
      );
    }
    // final ema = !isLinkFull ? 'mailto: $email' : email;
    final canLaunch = await canLaunchUrl(uri);
    if (canLaunch) {
      await launchUrl(uri);
    }
  }

  static Future<void> visitSite(
    String siteUrl,
  ) async {
    final uri = Uri.parse(siteUrl);
    final canLaunch = await canLaunchUrl(uri);
    if (canLaunch) {
      await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
    }
  }
}
