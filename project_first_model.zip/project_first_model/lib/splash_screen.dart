import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

// ignore: depend_on_referenced_packages
import 'package:page_transition/page_transition.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/services/app_info.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

@RoutePage(name: 'SplashScreenRouter')
class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedSplashScreen.withScreenRouteFunction(
      backgroundColor: theme.scaffoldBackgroundColor,
      splash: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Expanded(
            child: VerticalSizedBox(double.infinity),
          ),
          CircleAvatar(
            backgroundColor: Colors.transparent,
            radius: 300.r,
            child: ClipOval(
              child: ImageHelpers.getAssetImage(
                600.0,
                600.0,
                pic: Assets.logo.appLogoHigh.path,
              ),
            ),
          ),
          const Expanded(
            child: VerticalSizedBox(double.infinity),
          ),
          ImageHelpers.getAssetImage(
            250.0,
            250.0,
            pic: Assets.images.companyLogo.path,
          ),
          AppInfo.getDevloperTeamNameWidget,
        ],
      ),
      splashIconSize: 1500.h,
      // duration: 8500,
      centered: true,
      animationDuration: const Duration(seconds: 1),
      pageTransitionType: PageTransitionType.rightToLeftWithFade,
      splashTransition: SplashTransition.slideTransition,
      curve: Curves.easeInOutCubic,
      screenRouteFunction: () async {
        await Future.delayed(
          const Duration(seconds: 1),
        );
        // Get.offNamedUntil(
        //   Routes.welcomeScreen,
        //   (route) => false,
        // );
        await Get.find<AppRouter>().pushAndPopUntil(
          const WelcomeScreenRouter(),
          predicate: (route) => false,
        );
        return WelcomeScreenRouter.name;
      },
      disableNavigation: true,
    );
  }
}
