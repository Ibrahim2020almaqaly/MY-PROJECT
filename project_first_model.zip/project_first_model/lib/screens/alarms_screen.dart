import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/alarm_controllers/alarm_controller.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/widgets/alarm_widgets/add_alarm.dart';
import 'package:project_first_model/widgets/alarm_widgets/alarm_items.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

@RoutePage()
class AlarmsScreen extends StatelessWidget {
  const AlarmsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'قائمة التنبيهات',
        ),
        actions: [
          Padding(
            padding: CustomEdgeInsets.all(16),
            child: CustomIconButton(
              iconData: Icons.add_outlined,
              tooltip: "إضافة تنبيه",
              iconSize: 84,
              onPressed: () => showAddReminder(context, "إضافة تنبيه"),
              allowOnlineOnly: false,
              // allowRegisterOnly: false,
            ),
          ),
        ],
      ),
      body: Container(
        padding: CustomEdgeInsets.symmetric(50, 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: GetBuilder<AlarmController>(
                builder: (alarmProv) {
                  final alarmsList = alarmProv.alarms;
                  if (alarmsList.isNotEmpty) {
                    return ListView(
                      children: alarmsList
                          .map<Widget>(
                            (alarm) => AlarmItem(alarm: alarm),
                          )
                          .toList(),
                    );
                  }
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        const Expanded(
                          child: VerticalSizedBox(double.infinity),
                        ),
                        ImageHelpers.getLottieAssetImage(
                          900,
                          600,
                          Assets.lottieIcons.alarmClock,
                        ),
                        const Text(
                          'لايوجد تنبيهات بعد !',
                        ),
                        const Expanded(
                          child: VerticalSizedBox(double.infinity),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
