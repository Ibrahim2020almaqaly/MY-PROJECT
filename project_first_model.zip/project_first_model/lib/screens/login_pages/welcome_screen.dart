import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/widgets/utiles/custom_outlined_button.dart';
import 'package:upgrader/upgrader.dart';

import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/custom_checkbox.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';

@RoutePage(name: 'welcomeScreenRouter')
class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  WelcomeScreenState createState() => WelcomeScreenState();
}

class WelcomeScreenState extends State<WelcomeScreen> {
  final _controller = PageController();

  // var _isTheLast = false;
  var _isChecked = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget buildPage({
    required ThemeData themeColor,
    required String image,
    required Widget title,
    required Widget subtitle,
  }) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        children: [
          ImageHelpers.getLottieAssetImage(
            1500,
            900,
            image,
          ),
          const VerticalSizedBox(30),
          SizedBox(
            width: 900.0.w,
            child: title,
          ),
          const VerticalSizedBox(20),
          SizedBox(
            width: 900.0.w,
            child: subtitle,
          ),
          const VerticalSizedBox(40),
          // SizedBox(
          //   width: double.infinity,
          //   child: CustomElevatedButton(
          //     title: 'البدء',
          //     onPressed: () {
          //       Get.find<AppRouter>().push(const RegisterScreenRouter());
          //     },
          //     padding: 28.0,
          //     textStyle: TextStyle(fontSize: 55.sp),
          //     allowRegisterOnly: false,
          //     allowOnlineOnly: true,
          //   ),
          // ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    return Scaffold(
        body: UpgradeAlert(
          upgrader: Upgrader(
            languageCode: 'ar',
            canDismissDialog: true,
            messages: UpgraderMessages(code: 'ar'),
            dialogStyle: UpgradeDialogStyle.material,
            showReleaseNotes: true,
            showIgnore: false,
          ),
          child: SafeArea(
            child: Padding(
              padding: CustomEdgeInsets.symmetric(0, 0), //24, 32),
              child: Stack(
                children: [
                  // const BezierContainer(),
                  Container(
                    padding: CustomEdgeInsets.only(
                      bottom: 200.0,
                      top: 30,
                      left: 30,
                      right: 30,
                    ),
                    child: buildPage(
                      image: Assets.lottieIcons.aDriver,
                      themeColor: themeColor,
                      title: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          text: 'مرحباً بكم في تطبيق ',
                          style: TextStyle(
                            fontSize: 60.sp,
                            fontWeight: FontWeight.bold,
                            color: themeColor.textTheme.bodyLarge!.color,
                            fontFamily:
                                themeColor.textTheme.bodyLarge?.fontFamily,
                          ),
                          children: [
                            TextSpan(
                              text: appNAME,
                              style: TextStyle(
                                color: themeColor
                                    .floatingActionButtonTheme.backgroundColor,
                                fontSize: 60.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      subtitle: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "أعثر على جميع الرحلات بكل سهولة",
                            style: TextStyle(
                              fontSize: 44.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.blueGrey,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const VerticalSizedBox(20),
                          CustomCheckBox(
                            title: "أوافق على سياسة خوصية التطبيق",
                            style: TextStyle(
                              fontSize: 44.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.blueGrey,
                            ),
                            isChecked: _isChecked,
                            checkedHandeler: (value) {
                              setState(() {
                                _isChecked = value;
                              });
                            },
                            subtitle:
                                "يحب الموافقة على سياسة الخصوصية للمتابعة",
                          ),
                          const VerticalSizedBox(20),
                          CustomOutlinedButton(
                            allowRegisterOnly: false,
                            allowOnlineOnly: false,
                            padding: 30,
                            title: 'الإطلاع على سياسة الخصوصية',
                            textStyle: TextStyle(
                              fontSize: 46.sp,
                              // decoration: TextDecoration.underline,
                              // color: themeColor.primaryColor,
                              fontWeight: FontWeight.bold,
                            ),
                            onPressed: () async {
                              await Utiles.visitSite(Utiles.privacyPolicyURL);
                              // Get.find<AppRouter>()
                              //     .push(const PrivacyPolicyScreenRoute());
                            },
                          ),
                        ],
                      ),
                    ),
                    // PageView(
                    //   controller: _controller,
                    //   onPageChanged: (index) {
                    //     if (index == 2) {
                    //       if (!_isTheLast) {
                    //         setState(() {
                    //           _isTheLast = true;
                    //         });
                    //       }
                    //     } else {
                    //       if (_isTheLast) {
                    //         setState(() {
                    //           _isTheLast = false;
                    //         });
                    //       }
                    //     }
                    //   },
                    //   children: [
                    //     buildPage(
                    //       image: Assets.lottieIcons.runningCar,
                    //       themeColor: themeColor,
                    //       title: RichText(
                    //         textAlign: TextAlign.center,
                    //         text: TextSpan(
                    //           text: appNAME,
                    //           style: TextStyle(
                    //             fontSize: 60.sp,
                    //             fontWeight: FontWeight.bold,
                    //             color: themeColor.textTheme.bodyText1!.color,
                    //             fontFamily:
                    //                 themeColor.textTheme.bodyText1?.fontFamily,
                    //           ),
                    //           // children: [
                    //           //   TextSpan(
                    //           //     text: appNAME,
                    //           //     style: TextStyle(
                    //           //       color: themeColor
                    //           //           .floatingActionButtonTheme.backgroundColor,
                    //           //       fontSize: 60.sp,
                    //           //       fontWeight: FontWeight.bold,
                    //           //     ),
                    //           //   ),
                    //           // ],
                    //         ),
                    //       ),
                    //       subtitle: Text(
                    //         "أعثر على جميع الرحلات بكل سهولة",
                    //         style: TextStyle(
                    //           fontSize: 44.sp,
                    //           fontWeight: FontWeight.bold,
                    //           color: Colors.blueGrey,
                    //         ),
                    //         textAlign: TextAlign.center,
                    //       ),
                    //     ),
                    //     buildPage(
                    //       image: Assets.lottieIcons.aDriver,
                    //       themeColor: themeColor,
                    //       title: Text(
                    //         appNAME,
                    //         textAlign: TextAlign.center,
                    //         style: TextStyle(
                    //           fontSize: 60.sp,
                    //           fontWeight: FontWeight.bold,
                    //         ),
                    //       ),
                    //       subtitle: Text(
                    //         "يوفر التطبيق جميع الرحلات المتاحة من جميع المناطق",
                    //         style: TextStyle(
                    //           fontSize: 44.sp,
                    //           fontWeight: FontWeight.bold,
                    //           color: Colors.blueGrey,
                    //         ),
                    //         textAlign: TextAlign.center,
                    //       ),
                    //     ),
                    //     buildPage(
                    //       image: Assets.lottieIcons.usingMobilePhone,
                    //       themeColor: themeColor,
                    //       title: RichText(
                    //         textAlign: TextAlign.center,
                    //         text: TextSpan(
                    //           text: 'مرحباً بكم في تطبيق ',
                    //           style: TextStyle(
                    //             fontSize: 60.sp,
                    //             fontWeight: FontWeight.bold,
                    //             color: themeColor.textTheme.bodyText1!.color,
                    //             fontFamily:
                    //                 themeColor.textTheme.bodyText1?.fontFamily,
                    //           ),
                    //           children: [
                    //             TextSpan(
                    //               text: appNAME,
                    //               style: TextStyle(
                    //                 color: themeColor
                    //                     .floatingActionButtonTheme.backgroundColor,
                    //                 fontSize: 60.sp,
                    //                 fontWeight: FontWeight.bold,
                    //               ),
                    //             ),
                    //           ],
                    //         ),
                    //       ),
                    //       subtitle: Column(
                    //         children: [
                    //           CustomCheckBox(
                    //             title: "أوافق على سياسة خوصية التطبيق",
                    //             style: TextStyle(
                    //               fontSize: 44.sp,
                    //               fontWeight: FontWeight.bold,
                    //               color: Colors.blueGrey,
                    //             ),
                    //             isChecked: _isChecked,
                    //             checkedHandeler: (value) {
                    //               setState(() {
                    //                 _isChecked = value;
                    //               });
                    //             },
                    //             subtitle:
                    //                 "يحب الموافقة على سياسة الخصوصية للمتابعة",
                    //           ),
                    //           const VerticalSizedBox(20),
                    //           CustomTextButton(
                    //             allowRegisterOnly: false,
                    //             title: 'الإطلاع على سياسة الخصوصية',
                    //             textStyle: TextStyle(
                    //               fontSize: 46.sp,
                    //               decoration: TextDecoration.underline,
                    //               fontWeight: FontWeight.bold,
                    //             ),
                    //             onPressed: () {
                    //               Get.find<AppRouter>()
                    //                   .push(const PrivacyPolicyScreenRoute());
                    //             },
                    //           ),
                    //         ],
                    //       ),
                    //     ),
                    //   ],
                    // ),
                  ),
                  Positioned(
                    top: 5,
                    right: 5,
                    child: CustomTextButton(
                      allowOnlineOnly: false,
                      allowRegisterOnly: false,
                      textStyle: TextStyle(
                        fontSize: 44.sp,
                        fontWeight: FontWeight.bold,
                      ),
                      title: 'تصفح',
                      onPressed: () {
                        // Get.offAllNamed(Routes.mainPageName);
                        Get.find<AppRouter>().pushAndPopUntil(
                          const MainScreenRouter(),
                          predicate: (route) => false,
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomSheet:
            // _isTheLast
            //     ?
            SizedBox(
          width: double.infinity,
          child: CustomElevatedButton(
            allowRegisterOnly: false,
            padding: 44.0,
            textStyle: TextStyle(
              fontSize: 66.sp,
            ),
            title: 'تسجيل الدخول',
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(0),
              ),
              minimumSize: Size.fromHeight(200.h),
            ),
            onPressed: !_isChecked
                ? null
                : () {
                    // Get.toNamed(Routes.register);
                    Get.find<AppRouter>().push(const RegisterScreenRouter());
                  },
          ),
        )
        // :
        // Container(
        //     padding: CustomEdgeInsets.symmetric(30, 20),
        //     height: 200.h,
        //     color: Colors.transparent,
        //     child: Row(
        //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //       children: [
        //         CustomTextButton(
        //           title: 'السابق',
        //           textStyle: TextStyle(
        //             fontSize: 44.sp,
        //             fontWeight: FontWeight.bold,
        //           ),
        //           allowOnlineOnly: false,
        //           allowRegisterOnly: false,
        //           onPressed: () {
        //             _controller.previousPage(
        //               curve: Curves.easeInOut,
        //               duration: const Duration(
        //                 milliseconds: 500,
        //               ),
        //             );
        //           },
        //         ),
        //         Center(
        //           child: SmoothPageIndicator(
        //             controller: _controller,
        //             count: 3,
        //             // effect: WormEffect(
        //             //   spacing: 16,
        //             //   dotColor: Colors.black26,
        //             //   activeDotColor: Colors.teal.shade700,
        //             // ),
        //             onDotClicked: (index) {
        //               _controller.animateToPage(
        //                 index,
        //                 curve: Curves.easeInOut,
        //                 duration: const Duration(
        //                   milliseconds: 500,
        //                 ),
        //               );
        //             },
        //           ),
        //         ),
        //         CustomTextButton(
        //           title: 'التالي',
        //           textStyle: TextStyle(
        //             fontSize: 44.sp,
        //             fontWeight: FontWeight.bold,
        //           ),
        //           allowOnlineOnly: false,
        //           allowRegisterOnly: false,
        //           onPressed: () {
        //             _controller.nextPage(
        //               curve: Curves.easeInOut,
        //               duration: const Duration(
        //                 milliseconds: 500,
        //               ),
        //             );
        //           },
        //         ),
        //       ],
        //     ),
        //   ),
        );
  }
}
