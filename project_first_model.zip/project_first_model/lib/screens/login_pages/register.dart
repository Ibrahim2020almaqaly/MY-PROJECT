import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/login_widgets/send_button.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

@RoutePage(name: 'registerScreenRouter')
class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  RegisterState createState() => RegisterState();
}

class RegisterState extends State<Register> {
  final _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  void _save() async {
    final isValid = _formKey.currentState?.validate() ?? false;

    FocusManager.instance.primaryFocus?.unfocus();

    if (!isValid) return;

    final authProv = Get.find<FirebaseAuthController>();
    try {
      final number = '+967${_phoneController.text.trim()}';
      final yes = await ShowCustomDialog.showConfirmationDialogMessage(
        context,
        '$number \n هل أنت متأكد من الرقم؟',
        'سوف نقوم بالتحقق من هذا الرقم:',
      );
      if (!yes) return;
      // if (!mounted) return;

      authProv.changeButtonStatus(true);
      //check if user Disabled
      final isDisabled = await authProv.checkFromDBIfDisabled(number);
      if (isDisabled) {
        Get.find<AppRouter>().pushAndPopUntil(
          const DisabledAccountRoute(),
          predicate: (route) => false,
        );
        // Get.offAllNamed(Routes.disabledAccountScreen);
        authProv.changeButtonStatus(false);
        return;
      }

      // await authProv.sendOTBMSG(number);
      // Get.toNamed(Routes.getOTPScreen(number));
      Get.find<AppRouter>().push(
        OtpScreenRouter(
          phoneNumber: number,
        ),
      );
    } on CustomException catch (e) {
      ShowAnyMessages.showSnackBar(context, e.errorMessage, isError: true);
    } on Exception catch (e) {
      ShowAnyMessages.showSnackBar(context, e.toString(), isError: true);
    } finally {
      authProv.changeButtonStatus(false);
    }
  }

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        key: _scaffoldKey,
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Stack(
            children: [
              Padding(
                padding: CustomEdgeInsets.symmetric(48, 64),
                child: SingleChildScrollView(
                  reverse: true,
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const VerticalSizedBox(36),
                      Container(
                        width: 900.w,
                        height: 600.h,
                        decoration: const BoxDecoration(
                          // color: Color.fromARGB(255, 255, 255, 255),
                          shape: BoxShape.circle,
                        ),
                        child: ImageHelpers.getLottieAssetImage(
                          900,
                          600,
                          Assets.lottieIcons.usingMobilePhone,
                        ),
                      ),
                      const VerticalSizedBox(48),
                      Text(
                        'قم بإدخال رقمك',
                        style: TextStyle(
                          fontSize: 66.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const VerticalSizedBox(20),
                      RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          text: 'سوف يقوم تطبيق ',
                          style: TextStyle(
                            fontSize: 36.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueGrey,
                            fontFamily:
                                themeColor.textTheme.bodyLarge?.fontFamily,
                          ),
                          children: [
                            TextSpan(
                              text: appNAME,
                              style: TextStyle(
                                color: themeColor
                                    .floatingActionButtonTheme.backgroundColor,
                                fontSize: 50.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const TextSpan(
                              text:
                                  'بإرسال رمز تحقق لهاتفك لكي نستطيع التأكد أنك مالك الرقم ',
                            )
                          ],
                        ),
                      ),
                      const VerticalSizedBox(30),
                      Container(
                        padding: CustomEdgeInsets.all(48),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              CustomTextFormField(
                                label: 'رقم الهاتف',
                                autoFocus: true,
                                textDirection: TextDirection.ltr,
                                maxLength: 9,
                                controller: _phoneController,
                                textInputType: TextInputType.phone,
                                textInputAction: TextInputAction.done,
                                suffix: Padding(
                                  padding: CustomEdgeInsets.horizontal(16),
                                  child: Text(
                                    '(967+)',
                                    style: TextStyle(
                                      fontSize: 54.sp,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                validator: Validators.validatePhoneNumberField,
                                onSaved: null,
                              ),
                              const VerticalSizedBox(48),
                              SendButtonWidget(save: _save),
                              const VerticalSizedBox(38),
                              Text(
                                "ملاحظة في حالة عدم توفر خدمات جوجل في جهازك يجب عليك تخطي ال CAPCHA للإستمرار",
                                style: TextStyle(
                                  fontSize: 36.sp,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blueGrey,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const BottomPadding(),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 40.h,
                left: 40.w,
                child: CustomIconButton(
                  makeTheme: true,
                  onPressed: () => Get.find<AppRouter>().pop(),
                  iconData: Icons.arrow_forward,
                  iconSize: 90,
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                  tooltip: '',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


// W/Firestore( 8167): (24.4.1) [WatchStream]: (adedf96) Stream closed with status: Status{code=UNAVAILABLE, description=null, cause=java.net.NoRouteToHostException: Host unreachable
// W/Firestore( 8167): 	at libcore.io.IoBridge.connect(IoBridge.java:183)
// W/Firestore( 8167): 	at java.net.PlainSocketImpl.socketConnect(PlainSocketImpl.java:142)
// W/Firestore( 8167): 	at java.net.AbstractPlainSocketImpl.doConnect(AbstractPlainSocketImpl.java:390)
// W/Firestore( 8167): 	at java.net.AbstractPlainSocketImpl.connectToAddress(AbstractPlainSocketImpl.java:230)
// W/Firestore( 8167): 	at java.net.AbstractPlainSocketImpl.connect(AbstractPlainSocketImpl.java:212)
// W/Firestore( 8167): 	at java.net.SocksSocketImpl.connect(SocksSocketImpl.java:436)
// W/Firestore( 8167): 	at java.net.Socket.connect(Socket.java:621)
// W/Firestore( 8167): 	at java.net.Socket.connect(Socket.java:570)
// W/Firestore( 8167): 	at java.net.Socket.<init>(Socket.java:450)
// W/Firestore( 8167): 	at java.net.Socket.<init>(Socket.java:250)
// W/Firestore( 8167): 	at javax.net.DefaultSocketFactory.createSocket(SocketFactory.java:285)
// W/Firestore( 8167): 	at io.grpc.okhttp.OkHttpClientTransport$3.run(OkHttpClientTransport.java:535)
// W/Firestore( 8167): 	at io.grpc.internal.SerializingExecutor.run(SerializingExecutor.java:133)
// W/Firestore( 8167): 	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
// W/Firestore( 8167): 	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
// W/Firestore( 8167): 	at java.lang.Thread.run(Thread.java:920)
// W/Firestore( 8167): }.