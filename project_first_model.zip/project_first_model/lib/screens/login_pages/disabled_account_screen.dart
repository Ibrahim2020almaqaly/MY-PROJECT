import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';

@RoutePage()
class DisabledAccountScreen extends StatelessWidget {
  const DisabledAccountScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Padding(
        padding: CustomEdgeInsets.all(32.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ImageHelpers.getLottieAssetImage(
                  800.0,
                  500.0,
                  Assets.lottieIcons.blockedAccount,
                ),
                const VerticalSizedBox(20),
                Text(
                  'حسابك معطل !',
                  style: TextStyle(
                    fontSize: 44.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const VerticalSizedBox(10),
                RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    text: ' قررت إدارة ',
                    style: TextStyle(
                      fontFamily: theme.textTheme.bodyLarge?.fontFamily,
                      color: theme.textTheme.bodyLarge!.color,
                      fontSize: 40.sp,
                    ),
                    children: [
                      TextSpan(
                        text: appNAME,
                        style: TextStyle(
                          color: theme.iconTheme.color,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const TextSpan(
                        text: 'بتعطيل حسابك لأنك لم تلتزم بقواعد مجتمع ',
                      ),
                      TextSpan(
                        text: appNAME,
                        style: TextStyle(
                          color: theme.iconTheme.color,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                const VerticalSizedBox(20),
                CustomTextButton(
                  allowRegisterOnly: false,
                  allowOnlineOnly: false,
                  title: 'مراجعة الإدارة لقرار التعطيل',
                  onPressed: () {
                    Utiles.email('masterzteamsupprt@gmail.com');
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
