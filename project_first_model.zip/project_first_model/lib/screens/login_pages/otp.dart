import 'dart:async';

import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

@RoutePage(name: 'otpScreenRouter')
class Otp extends StatefulWidget {
  final String phoneNumber;
  // final bool createUser;
  const Otp({
    Key? key,
    required this.phoneNumber,
    // required this.createUser,
  }) : super(key: key);

  @override
  OtpState createState() => OtpState();
}

class OtpState extends State<Otp> {
  final _otpController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  void initState() {
    super.initState();
    sendOTP();
  }

  void _close() {
    final authProv = Get.find<FirebaseAuthController>();
    authProv.closeSubscribtion();
  }

  void sendOTP() async {
    try {
      await Future.delayed(Duration.zero);
      // if (!mounted) return;

      final authProv = Get.find<FirebaseAuthController>();
      await authProv.sendOTPMSG(widget.phoneNumber);
    } on CustomException catch (e) {
      ShowAnyMessages.showSnackBar(context, e.errorMessage, isError: true);
    }
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  Future<void> _save() async {
    final isValid = _formKey.currentState?.validate() ?? false;

    FocusManager.instance.primaryFocus?.unfocus();

    if (!isValid) return;
    final prov = Get.find<FirebaseAuthController>();
    if (prov.isCodeReciveved) {
      CustomOverlayLoading.showOverlayLoading();
      await Future.delayed(const Duration(seconds: 2));
      prov.closeSubscribtion();
      Get.find<AppRouter>().pushAndPopUntil(
        const ViewMiniProfileRoute(),
        predicate: (route) => false,
      );
      // Get.offAllNamed(Routes.viewMiniProfileScreen);

      // if (!mounted) return;
      CustomOverlayLoading.hideOverlayLoading();
      return;
    }

    try {
      await prov.verifiyUser(_otpController.text.trim());

      if (prov.isThereAUserLoggedin) {
        // Get.offAllNamed(Routes.viewMiniProfileScreen);
        Get.find<AppRouter>().pushAndPopUntil(
          const ViewMiniProfileRoute(),
          predicate: (route) => false,
        );
        prov.closeSubscribtion();
      }
    } on CustomException catch (e) {
      ShowAnyMessages.showSnackBar(context, e.errorMessage, isError: true);
    } on Exception catch (e) {
      ShowAnyMessages.showSnackBar(context, e.toString(), isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return WillPopScope(
      onWillPop: () {
        _close();
        return Future.value(true);
      },
      child: Scaffold(
        body: SafeArea(
          child: GestureDetector(
            onTap: () {
              FocusScope.of(context).unfocus();
            },
            child: Stack(
              children: [
                Padding(
                  padding: CustomEdgeInsets.symmetric(24, 26),
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    reverse: true,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const VerticalSizedBox(18),
                        Container(
                          width: 900.w,
                          height: 600.h,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                          ),
                          child: ImageHelpers.getLottieAssetImage(
                            900,
                            600,
                            Assets.lottieIcons.otpMobileNotification,
                          ),
                        ),
                        const VerticalSizedBox(30),
                        RichText(
                          textAlign: TextAlign.center,
                          textDirection: TextDirection.rtl,
                          text: TextSpan(
                            text: "سوف تصلك رسالة تحقق إلى هذا الرقم ",
                            style: TextStyle(
                              fontSize: 50.sp,
                              fontWeight: FontWeight.bold,
                              color: theme.colorScheme.onSurface,
                              fontFamily: theme.textTheme.bodyLarge?.fontFamily,
                            ),
                            children: [
                              TextSpan(
                                text: ' ${widget.phoneNumber.substring(1)}',
                                style: TextStyle(
                                  color: theme.floatingActionButtonTheme
                                      .backgroundColor,
                                  fontSize: 60.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const VerticalSizedBox(30),
                        Text(
                          "الرجاء إدخال رمز التحقق",
                          style: TextStyle(
                            fontSize: 40.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueGrey,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const VerticalSizedBox(32),
                        Container(
                          padding: CustomEdgeInsets.all(40),
                          decoration: BoxDecoration(
                            // color: Colors.white,
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          child: Form(
                            key: _formKey,
                            child: Column(
                              children: [
                                GetBuilder<FirebaseAuthController>(
                                  builder: (authProv) {
                                    if (authProv.isCodeReciveved) {
                                      Future.delayed(Duration.zero, () {
                                        _otpController.text = authProv.smsCode;
                                      });
                                    }

                                    return CustomTextFormField(
                                      label: '',
                                      controller: _otpController,
                                      textAlign: TextAlign.center,
                                      textAlignVertical:
                                          TextAlignVertical.center,
                                      textInputAction: TextInputAction.done,
                                      textInputType: TextInputType.number,
                                      imprtantBorder: true,
                                      maxLength: 6,
                                      autoFocus: true,
                                      validator: (value) {
                                        return Validators
                                            .validatePhoneNumberField(value, 6);
                                      },
                                      onSaved: null,
                                      // suffix: null,
                                    );
                                  },
                                ),
                                const VerticalSizedBox(44),
                                SizedBox(
                                  width: double.infinity,
                                  child: VerifiyOTBButton(save: _save),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const VerticalSizedBox(36),
                        Text(
                          "لم تصلك رسالة تحقق بعد !",
                          style: TextStyle(
                            fontSize: 38.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueGrey,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        ResendButton(
                          phoneNumber: widget.phoneNumber,
                        ),
                        const BottomPadding(),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 40.h,
                  left: 40.w,
                  child: CustomIconButton(
                    makeTheme: true,
                    onPressed: () => Get.find<AppRouter>().pop(),
                    iconData: Icons.arrow_forward,
                    iconSize: 90,
                    allowOnlineOnly: false,
                    allowRegisterOnly: false,
                    tooltip: '',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ResendButton extends StatefulWidget {
  final String phoneNumber;
  const ResendButton({
    Key? key,
    required this.phoneNumber,
  }) : super(key: key);

  @override
  State<ResendButton> createState() => _ResendButtonState();
}

class _ResendButtonState extends State<ResendButton> {
  var enableBtn = false;
  var secRemaining = 0;
  var expoRemain = 100;

  Timer? timer;
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      startTimer();
    });
  }

  @override
  void dispose() {
    if (timer?.isActive ?? false) timer?.cancel();
    super.dispose();
  }

  void startTimer() {
    // expoRemain *= 2;
    secRemaining = expoRemain;
    timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) {
        if (secRemaining > 0) {
          setState(() {
            secRemaining--;
          });
        } else {
          setState(() {
            enableBtn = true;
            timer?.cancel();
          });
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FirebaseAuthController>(
      builder: (prov) {
        return CustomTextButton(
          allowRegisterOnly: false,
          title: enableBtn
              ? "إعادة إرسال الرمز"
              : "إرسال الرمز مرة أخرى بعد $secRemaining ثانية",
          onPressed: prov.getLoadingStatus || !enableBtn
              ? null
              : () async {
                  enableBtn = false;
                  startTimer();
                  await prov.sendOTPMSG(widget.phoneNumber);
                },
          textStyle: TextStyle(
            fontSize: 40.sp,
            fontWeight: FontWeight.bold,
          ),
        );
      },
    );
  }
}

class VerifiyOTBButton extends StatelessWidget {
  final Future<void> Function() save;
  const VerifiyOTBButton({
    Key? key,
    required this.save,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FirebaseAuthController>(
      builder: (prov) {
        return ElevatedButton(
          onPressed: prov.isCodeSent || prov.isCodeReciveved
              ? () async {
                  final online = Get.find<ConnectionController>().isOnline;
                  if (!online) {
                    await ShowAnyMessages.noConnMsg(context);
                    return;
                  }
                  await save();
                }
              : null,
          // style: ButtonStyle(
          //   shape: MaterialStateProperty.all<RoundedRectangleBorder>(
          //     RoundedRectangleBorder(
          //       borderRadius: BorderRadius.circular(24.0),
          //     ),
          //   ),
          // ),
          child: Padding(
            padding: CustomEdgeInsets.all(28.0),
            child: prov.getLoadingStatus
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const CircularProgressIndicator(
                        color: Colors.white,
                      ),
                      const HorizantalSizedBox(40),
                      Text(
                        "الرجاء الإنتظار ...",
                        style: TextStyle(fontSize: 40.sp),
                      ),
                    ],
                  )
                : Text(
                    'تحقق',
                    style: TextStyle(fontSize: 40.sp),
                  ),
          ),
        );
      },
    );
  }
}
