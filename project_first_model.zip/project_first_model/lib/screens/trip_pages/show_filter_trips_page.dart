import 'package:auto_route/annotations.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_ui_firestore/firebase_ui_firestore.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/trip_filter_controller.dart';
import 'package:project_first_model/models/filter_model.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/widgets/custom_loadings/custom_list_loading.dart';
import 'package:project_first_model/widgets/custom_loadings/trips_loading_v2.dart';
import 'package:project_first_model/widgets/filter_trips_widget.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/handel_connection.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/no_more_data.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/show_any_list_view.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/snapshot_error.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/offer_items_v2.dart';
import 'package:project_first_model/widgets/utiles/custom_scaffold_scroll.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';

@RoutePage()
class ShowFilterTripsPage extends StatefulWidget {
  const ShowFilterTripsPage({
    Key? key,
  }) : super(key: key);

  @override
  State<ShowFilterTripsPage> createState() => _ShowFilterTripsPageState();
}

class _ShowFilterTripsPageState extends State<ShowFilterTripsPage> {
  final scrollController = ScrollController();

  @override
  void dispose() {
    super.dispose();
    scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffoldScroll(
      controller: scrollController,
      appBar: AppBar(
        title: const Text('نتائج البحث'),
        actions: [
          CustomTextIconButton(
            iconData: Icons.filter_list_outlined,
            title: 'فلترة',
            allowOnlineOnly: false,
            allowRegisterOnly: false,
            onPressed: () async {
              await FilterTrips.showFiltesModal(context);
            },
          ),
        ],
      ),
      body: SafeArea(
        child: HandelConnection(
          showAppBar: false,
          mainWidget: ListView(
            controller: scrollController,
            physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics(),
            ),
            children: [
              _ShowFilteredTrips(
                scrollController: scrollController,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ShowFilteredTrips extends StatelessWidget {
  const _ShowFilteredTrips({
    Key? key,
    required this.scrollController,
  }) : super(key: key);
  final ScrollController scrollController;

  Widget _handelTripDataView(List<QueryDocumentSnapshot<dynamic>> tripDocs,
      int index, BuildContext context) {
    final trip = tripDocs[index].data();
    return OfferItemsV2(
      trip: trip,
      getTripData: (String tripID) async {
        return await Get.find<TripController>().findTripById(tripID);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TripFilterController>(
      init: TripFilterController(),
      builder: (tripProv) {
        if (tripProv.filter == FiltersModel.defaultFilters) {
          return NoMoreData(
            title: 'لا توجد حقول للبحث بها!',
            onPressed: () {
              FilterTrips.showFiltesModal(context);
            },
            showIcon: true,
            btnTitle: 'إضافة حقول للبحث',
          );
        }
        return FirestoreQueryBuilder<TripModel>(
          query: tripProv.getFilterdTripsQuery,
          pageSize: 5,
          builder: (ctx, snapshot, _) {
            if (snapshot.isFetching) {
              return const CustomListLoading(
                count: 20,
                child: TripsLoadingV2(),
              );
            } else if (snapshot.hasError) {
              return SnapshotError(
                error: snapshot.error,
                onPressed: () {
                  tripProv.refershFilteredTripQuery();
                },
              );
            }
            return ShowAnyListView(
              snapshot: snapshot,
              scrollController: scrollController,
              refershQuery: tripProv.refershFilteredTripQuery,
              handelDataView: _handelTripDataView,
              noDataFoundTitle: 'لا توجد رحلات بعد!',
              noMoreDataTitle: 'لا توجد رحلات أخرى!',
            );
          },
        );
      },
    );
  }
}
