import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';

import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/trips_filters_widget.dart';

@RoutePage()
class SearchTrips extends StatelessWidget {
  const SearchTrips({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: const Text('البحث عن رحلة'),
        ),
        body: const SafeArea(
          child: TripsFiltersWidget(),
        ),
      ),
    );
  }
}
