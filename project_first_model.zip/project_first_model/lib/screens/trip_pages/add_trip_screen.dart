// ignore_for_file: use_build_context_synchronously

import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';

import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/secondary_city_controller.dart';
import 'package:project_first_model/controllers/trip_controllers/trip_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/helpers/convert_to_date_time.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_date_time_picker.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/models/cities_model.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/widgets/add_trip_widgets/secondary_dest.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_card.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_checkbox.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';
import 'package:project_first_model/widgets/utiles/custom_text_field.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

enum _Actions {
  add,
  remove,
}

@RoutePage(name: 'AddTripRouter')
class AddTripScreen extends StatefulWidget {
  static const routeName = '/addTripScreen';

  const AddTripScreen({
    Key? key,
    // required this.popAllow,
  }) : super(key: key);

  // final void Function(bool isAllow) popAllow;

  @override
  State<AddTripScreen> createState() => _AddTripScreenState();
}

class _AddTripScreenState extends State<AddTripScreen> {
  final _dateController = TextEditingController();
  final _fromDestController = TextEditingController();
  final _toDestController = TextEditingController();
  final _secondaryDestController = TextEditingController();
  final _timeController = TextEditingController();
  final _notesController = TextEditingController();
  final _priceController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  late TripModel _tripModel;
  TripModel? _oldTrip;
  var alreadyTripThere = false;

  var _deliverPaperAndThings = false;

  void _resetModel() {
    setState(() {
      _tripModel = TripModel.defaultTrip;
      alreadyTripThere = false;
      _oldTrip = null;
      _getData();
    });
  }

  // var _isSet = false;

  @override
  void initState() {
    super.initState();
    initializeDateFormatting('en_US', null);

    Future.delayed(
      Duration.zero,
    ).then((_) => setupScreen());
  }

  void setupScreen() async {
    try {
      CustomOverlayLoading.showOverlayLoading();

      final userProv = Get.find<UserController>();

      final userId = userProv.getUserData.userId;
      if (userId.isNotEmpty && userId != '') {
        final res = await Get.find<TripController>().findByUserId(userId);
        if (res != null) {
          _tripModel = res;
          _oldTrip = res;
          alreadyTripThere = true;
          _getData();
        } else {
          _resetModel();
        }
      } else {
        _resetModel();
      }
      // if (!mounted) return;
      // context.loaderOverlay.hide();
      CustomOverlayLoading.hideOverlayLoading();
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      _resetModel();
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        floating: false,
        isError: true,
      );
    } on Exception catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      _resetModel();
      ShowAnyMessages.showSnackBar(
        context,
        e.toString(),
        floating: false,
        isError: true,
      );
    }
  }

  void _getData() {
    _dateController.text =
        DateTimeHelpers.convertDateToString(_tripModel.tripDate);
    _timeController.text = DateFormat.jm('en_US').format(
        DateTimeHelpers.convertToDateTime(DateTime.now(), _tripModel.tripTime));
    _fromDestController.text = _tripModel.from;
    _toDestController.text = _tripModel.to;
    _notesController.text = _tripModel.notes;
    _priceController.text = _tripModel.tripPrice.toString();
    setState(() {
      _deliverPaperAndThings = _tripModel.trusteeship;
    });
    Get.find<SecondaryCityController>().resetCities();
    Get.find<SecondaryCityController>().addCities(_tripModel.secondaryDest);
  }

  @override
  void dispose() {
    _dateController.dispose();
    _fromDestController.dispose();
    _toDestController.dispose();
    _secondaryDestController.dispose();
    _timeController.dispose();
    _notesController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  void _savePlace(dynamic value, DestType type) {
    _tripModel = _tripModel.copyWith(
      from: type == DestType.from ? value : null,
      to: type == DestType.to ? value : null,
      secondaryDest: type == DestType.secondary ? value : null,
    );
  }

  void _delete() async {
    final delete = await Utiles.deleteItem(
      context,
      message: 'هل فعلا تريد حذف الرحلة؟',
    );
    if (!delete) {
      return;
    }
    await _deleteTrip(deleteFromHistory: true);
  }

  Future<void> _deleteTrip({bool deleteFromHistory = false}) async {
    try {
      CustomOverlayLoading.showOverlayLoading();
      final uid = _tripModel.userId;
      final prov = Get.find<TripController>();
      // first delete dependecies
      if (deleteFromHistory) {
        if (uid.isNotEmpty && uid != '') {
          await prov.deleteTripHistory(_tripModel.tripId);

          // if (!mounted) return;
          final rateProv = Get.find<RatingController>();
          await rateProv.deleteTripRate(uid, _tripModel.tripId);
        }
      }

      await prov.deleteTrip(_tripModel.tripId);
      // if (!mounted) return;
      Get.find<SecondaryCityController>().resetCities();
      _resetModel();

      // if (!mounted) return;
      CustomOverlayLoading.hideOverlayLoading();
      if (deleteFromHistory) {
        ShowAnyMessages.showSnackBar(
          context,
          'تمت الحذف بنجاح',
          isSuccess: true,
        );
      }
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        isError: true,
      );
    } on Exception catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(
        context,
        e.toString(),
        isError: true,
      );
    }
  }

  void _save() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    final authProv = Get.find<FirebaseAuthController>();
    final uid = authProv.getCurrentUser?.uid;

    final userProv = Get.find<UserController>().getUserData;

    _tripModel = _tripModel.copyWith(
      userId: uid,
      driverName: userProv.userName,
      // phoneNumber: userProv.userPhoneNumber,
      driverPic: userProv.userPic,
      carPic1: userProv.userCarPic1,
      carPic2: userProv.userCarPic2,
    );

    _formKey.currentState!.save();
    FocusManager.instance.primaryFocus?.unfocus();
    if (alreadyTripThere) {
      final yes = await Utiles.editItem(
        context,
        message: 'هل فعلاً تريد تعديل الرحلة؟',
      );

      if (!yes) return;

      if (_oldTrip != null && (_oldTrip) == _tripModel) {
        savedSuccessfully();
        return;
      }
    }

    CustomOverlayLoading.showOverlayLoading();

    try {
      if (uid == null) {
        throw CustomException('ليس لديك حساب لكي تستطيع إضافة رحلة');
      }

      final valid = await authProv.validToken();
      if (!valid) return;

      final rateProv = Get.find<RatingController>();

      final tripRating = await rateProv.getDriverRate(userProv.userId);

      _tripModel = _tripModel.copyWith(
        ratingPeopleCount: tripRating.ratingPeopleCount,
        ratingRatio: tripRating.starsRatio,
      );

      // if (!mounted) return;
      final tripProv = Get.find<TripController>();

      if (_tripModel.tripId == '' || (_tripModel.tripId.isEmpty)) {
        _tripModel = await tripProv.addTrip(_tripModel);

        alreadyTripThere = true;
      } else {
        await tripProv.updateTrip(_tripModel, id: _tripModel.tripId);
      }
      // if (!mounted) return;
      CustomOverlayLoading.hideOverlayLoading();

      savedSuccessfully();
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(context, e.errorMessage, isError: true);
    }
  }

  void savedSuccessfully() {
    ShowAnyMessages.showSnackBar(
      context,
      'تم الحفظ بنجاح',
      isSuccess: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Theme.of(context);
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: const Text(
            'إضافة رحلة',
          ),
          iconTheme: themeColor.iconTheme,
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: CustomIconButton(
                iconData: Icons.save_outlined,
                tooltip: 'حفظ الرحلة',
                iconSize: 80.0,
                onPressed: _save,
              ),
            ),
            PopupMenuButton(
              offset: const Offset(10, 40),
              onSelected: (value) async {
                final online = Get.find<ConnectionController>().isOnline;
                if (!online) {
                  await ShowAnyMessages.noConnMsg(context);
                  return;
                }
                switch (value) {
                  case _Actions.add:
                    if (alreadyTripThere) {
                      final yes = await Utiles.replaceItem(
                        context,
                        message:
                            'يبدو أن لديك رحلة بالفعل هل تريد إضافة رحلة جديدة؟\n سوف يقوم التطبيق بحذف الرحلة السابقة وإستبدالها بالحالية',
                      );

                      if (!yes) {
                        return;
                      }
                      await _deleteTrip();
                    }
                    break;
                  case _Actions.remove:
                    _delete();
                    break;
                  default:
                }
              },
              itemBuilder: (context) {
                return [
                  //add new trip
                  const PopupMenuItem(
                    value: _Actions.add,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Icon(Icons.add_outlined),
                        Text('رحلة جديدة'),
                      ],
                    ),
                  ),
                  //delete trip
                  const PopupMenuItem(
                    value: _Actions.remove,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Icon(Icons.delete_outline),
                        Text('حذف الرحلة'),
                      ],
                    ),
                  ),
                ];
              },
            ),
          ],
        ),
        body: SafeArea(
          child: Padding(
            padding: CustomEdgeInsets.all(8.0),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                reverse: true,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const VerticalSizedBox(15),
                    //trip Information
                    CustomCard(
                      title: 'بيانات الرحلة',
                      children: [
                        //date Time
                        Column(
                          children: [
                            //Date Picker
                            CustomTextFormField(
                              label: 'تاريخ الرحلة',
                              controller: _dateController,
                              readOnly: true,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.datetime,
                              validator: Validators.validateDateField,
                              onSaved: (value) {
                                _tripModel = _tripModel.copyWith(
                                  tripDate: DateTimeHelpers.convertStringToDate(
                                      value!),
                                  fullDateTime:
                                      DateTimeHelpers.convertStringToDate(
                                          value),
                                );
                              },
                              showIconButton: true,
                              icon: Icons.date_range_outlined,
                              onIconPressed: () async {
                                await showDateDialog(context);
                              },
                              onTap: () async {
                                await showDateDialog(context);
                              },
                              iconToolTip: 'حدد التاريخ',
                              showClearIcon: false,
                            ),

                            const VerticalSizedBox(35),
                            //time Picker
                            CustomTextFormField(
                              label: 'وقت الرحلة',
                              controller: _timeController,
                              readOnly: true,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.datetime,
                              validator: (value) {
                                return Validators.validateTimeField(
                                    value, _dateController.text.trim());
                              },
                              onSaved: (value) {
                                // final format = DateFormat('hh:mm a');
                                final time =
                                    DateTimeHelpers.convertToTimeOfDayV2(
                                        value!);
                                // TimeOfDay.fromDateTime(
                                //     format.parse(value!));
                                final fullDate =
                                    DateTimeHelpers.convertToDateTime(
                                  _tripModel.tripDate,
                                  time,
                                );
                                _tripModel = _tripModel.copyWith(
                                  fullDateTime: fullDate,
                                  tripTime: time,
                                );
                              },
                              showIconButton: true,
                              icon: Icons.timer_outlined,
                              onIconPressed: () async {
                                await showTimeDialog(context);
                              },
                              onTap: () async {
                                await showTimeDialog(context);
                              },
                              iconToolTip: 'حدد الوقت',
                              showClearIcon: false,
                            ),
                            const VerticalSizedBox(35),
                            const Divider(),
                            //price
                            CustomTextFormField(
                              label: 'السعر للراكب',
                              controller: _priceController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.number,
                              validator: Validators.validateMoneyField,
                              onSaved: (value) {
                                final valueDouble =
                                    double.parse(value ?? '0.0');
                                _tripModel = _tripModel.copyWith(
                                  tripPrice: valueDouble,
                                );
                              },
                            ),
                            const VerticalSizedBox(35),
                            //delivery
                            CustomCheckBox(
                              checkedHandeler: (value) {
                                setState(() {
                                  _tripModel = _tripModel.copyWith(
                                    trusteeship: value,
                                  );
                                  _deliverPaperAndThings = value;
                                });
                              },
                              isChecked: _deliverPaperAndThings,
                              title: 'متاح لتوصيل أوراق & أمانات',
                              subtitle:
                                  'في حالة أنك متاح لتوصيل أمانات قم بالضغط على الزر',
                            ),
                            const VerticalSizedBox(35),
                            const Divider(),
                            //from
                            CustomTextField(
                              title: 'من',
                              autoValidate: true,
                              saveHandeler: _savePlace,
                              textController: _fromDestController,
                              otherControlersValues: [
                                _secondaryDestController,
                                _toDestController
                              ],
                              type: DestType.from,
                              suggestionCallback: CityModel.citySuggestions,
                              fieldList: CityModel.getCities,
                            ),
                            const VerticalSizedBox(35),
                            //to
                            CustomTextField(
                              title: 'إلى',
                              autoValidate: true,
                              saveHandeler: _savePlace,
                              textController: _toDestController,
                              otherControlersValues: [
                                _secondaryDestController,
                                _fromDestController,
                              ],
                              type: DestType.to,
                              suggestionCallback: CityModel.citySuggestions,
                              fieldList: CityModel.getCities,
                            ),
                          ],
                        ),

                        const VerticalSizedBox(35),

                        //Secondary Destenation
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Expanded(
                              child: CustomTextField(
                                title: 'وجهة فرعية',
                                saveHandeler: _savePlace,
                                textController: _secondaryDestController,
                                otherControlersValues: [
                                  _fromDestController,
                                  _toDestController
                                ],
                                type: DestType.secondary,
                                allowNullValue: true,
                                autoValidate: true,
                                isTheLast: false,
                                suggestionCallback: CityModel.citySuggestions,
                                fieldList: CityModel.getCities,
                              ),
                            ),
                            CustomTextIconButton(
                              allowOnlineOnly: false,
                              allowRegisterOnly: false,
                              iconData: Icons.add_outlined,
                              title: 'إضافة',
                              onPressed: () {
                                final cities =
                                    Get.find<SecondaryCityController>();
                                if (_secondaryDestController.text !=
                                        _fromDestController.text &&
                                    _secondaryDestController.text !=
                                        _toDestController.text &&
                                    _secondaryDestController.text.isNotEmpty &&
                                    !cities.cities.contains(
                                        _secondaryDestController.text)) {
                                  cities.addCity(_secondaryDestController.text);
                                  _secondaryDestController.text = '';
                                }
                              },
                            ),
                          ],
                        ),

                        const VerticalSizedBox(35),

                        const SecondaryDestWidget(),

                        const VerticalSizedBox(35),

                        const Divider(),

                        //Notes
                        CustomTextFormField(
                          label: 'ملاحظات',
                          controller: _notesController,
                          minLines: 1,
                          maxLines: 6,
                          maxLength: 100,
                          textInputAction: TextInputAction.newline,
                          textInputType: TextInputType.multiline,
                          validator: null,
                          onSaved: (value) {
                            _tripModel = _tripModel.copyWith(
                              notes: _notesController.text.trim(),
                            );
                          },
                        ),
                      ],
                      // color: themeColor.colorScheme.onSurface,
                    ),

                    const VerticalSizedBox(35),

                    const BottomPadding(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> showTimeDialog(BuildContext context) async {
    _timeController.text = await ShowDateTimePickers.showCustomTimePicker(
      // context,
      _timeController.text,
    );
  }

  Future<void> showDateDialog(BuildContext context) async {
    _dateController.text = await ShowDateTimePickers.showCustomDatePicker(
      // context,
      _dateController.text,
    );
  }
}
