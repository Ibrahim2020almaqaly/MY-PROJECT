import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';

@RoutePage()
class ShowTripDataScreen extends StatelessWidget {
  const ShowTripDataScreen({
    Key? key,
    @PathParam() required this.tripId,
  }) : super(key: key);

  final String tripId;

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('show Trip Data Screen'),
      ),
    );
  }
}
