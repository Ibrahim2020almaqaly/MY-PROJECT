import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:project_first_model/widgets/main_screen_widgets/trips_widgets/show_all_trips_.dart';
import 'package:project_first_model/widgets/utiles/custom_scaffold_scroll.dart';

@RoutePage()
class TripsListScreen extends StatefulWidget {
  const TripsListScreen({Key? key}) : super(key: key);

  @override
  State<TripsListScreen> createState() => _TripsListScreenState();
}

class _TripsListScreenState extends State<TripsListScreen> {
  final scrollController = ScrollController();

  @override
  void dispose() {
    super.dispose();
    scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffoldScroll(
      controller: scrollController,
      appBar: AppBar(
        title: const Text('الرحلات المتاحة'),
      ),
      body: SafeArea(
        child: ListView(
          controller: scrollController,
          children: [
            ShowAllTrips(controller: scrollController),
          ],
        ),
      ),
    );
  }
}
