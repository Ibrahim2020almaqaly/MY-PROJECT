import 'package:auto_route/annotations.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'package:project_first_model/controllers/bottom_nav_bar_controller.dart';
import 'package:project_first_model/controllers/theme_controller.dart';
import 'package:project_first_model/models/trip_model.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';

@RoutePage(name: 'TestScreenRoute')
class TestScreen extends StatefulWidget {
  const TestScreen({Key? key}) : super(key: key);

  @override
  State<TestScreen> createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  final v = List<TripModel>.generate(10, (index) => TripModel.testTrip);
  final controller = ScrollController();

  @override
  void initState() {
    super.initState();
    initializeDateFormatting('ar_SA', null);
    controller.addListener(() {
      // print('object1');
    });
  }

  @override
  void dispose() {
    super.dispose();
    controller.removeListener(() {
      // print('object1');
    });
  }

  @override
  Widget build(BuildContext context) {
    // final bottomProv = Get.find<BottomNavBarController>();
    return SafeArea(
      top: false,
      child: GetBuilder<BottomNavBarController>(
        builder: (bottomProv) {
          return Scaffold(
            body: IndexedStack(
              index: bottomProv.index,
              children: [...bottomProv.screens],
            ),
            resizeToAvoidBottomInset: false,

            bottomNavigationBar: GetBuilder<ThemeController>(
              builder: (themeProv) {
                return CurvedNavigationBar(
                  height: 150.h,
                  color: themeProv.isDarkMode ? Colors.black : Colors.white,
                  backgroundColor:
                      Theme.of(context).iconTheme.color!.withAlpha(70),
                  index: bottomProv.index,
                  animationCurve: Curves.bounceInOut,
                  animationDuration: const Duration(milliseconds: 300),
                  items: [
                    Icon(FontAwesomeIcons.house, size: 80.sp),
                    Icon(FontAwesomeIcons.circlePlus, size: 80.sp),
                    Icon(FontAwesomeIcons.magnifyingGlass, size: 80.sp),
                    const CircleSqureImage(
                      pic: '',
                      height: 100,
                      width: 100,
                      radius: 50,
                    ), //Icon( FontAwesomeIcons.solidUserCircle, size: 28),
                    // Icon(Icons.settings_sharp, size: 33),
                  ],
                  onTap: bottomProv.indexChanged,
                );
              },
            ),

            //     ListView(
            //   // shrinkWrap: true,
            //   children: [
            //     Column(
            //       // mainAxisAlignment: MainAxisAlignment.start,
            //       mainAxisSize: MainAxisSize.min,
            //       children: [
            //         SizedBox(
            //           height: 200,
            //           child: Wrap(
            //             crossAxisAlignment: WrapCrossAlignment.center,
            //             direction: Axis.vertical,
            //             spacing: 5,
            //             runSpacing: 5,
            //             alignment: WrapAlignment.spaceAround,
            //             children: [
            //               ...v.map(
            //                 (e) => Row(
            //                   mainAxisSize: MainAxisSize.max,
            //                   mainAxisAlignment: MainAxisAlignment.start,
            //                   children: const [
            //                     Text('test'),
            //                     SizedBox(
            //                       width: 20,
            //                     ),
            //                     Text('data'),
            //                   ],
            //                 ),
            //               ),
            //             ],
            //           ),
            //           //  ListView.builder(
            //           //   // shrinkWrap: true,
            //           //   itemCount: 100,
            //           //   itemBuilder: (BuildContext context, int index) {
            //           //     return Row(
            //           //       mainAxisSize: MainAxisSize.max,
            //           //       // mainAxisAlignment: MainAxisAlignment.start,
            //           //       children: [
            //           //         Text('test $index'),
            //           //         const SizedBox(
            //           //           width: 20,
            //           //         ),
            //           //         const Text('data'),
            //           //       ],
            //           //     );
            //           //   },
            //           // ),
            //         ),
            //       ],
            //     ),
            //   ],
            // ),
          );
        },
      ),
    );
  }
}
