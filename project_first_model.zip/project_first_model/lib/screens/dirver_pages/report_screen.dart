import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/driver_controllers/report_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/models/report_model.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_card.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

@RoutePage()
class ReportScreen extends StatefulWidget {
  const ReportScreen({
    Key? key,
    required this.driverID,
  }) : super(key: key);

  final String driverID;

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  final _reportController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _reportController.dispose();
    super.dispose();
  }

  void _save() async {
    final valid = _formKey.currentState?.validate() ?? false;
    FocusManager.instance.primaryFocus?.unfocus();

    if (!valid) return;

    try {
      CustomOverlayLoading.showOverlayLoading();

      _formKey.currentState!.save();
      final customerID =
          Get.find<FirebaseAuthController>().getCurrentUser?.uid ?? '';

      if (customerID == '') {
        throw CustomException('فشل في الإرسال يجب تسجيل الدخول أولاً !');
      }

      Get.find<ReportController>().addCustomerReport(
        widget.driverID,
        CustomersReport(
          customerID: customerID,
          reason: _reportController.text.trim(),
        ),
      );
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(context, 'تم الإرسال بنجاح');
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showSnackBar(context, e.errorMessage, isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الإبلاغ'),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            reverse: true,
            padding: CustomEdgeInsets.all(8.0),
            physics: const BouncingScrollPhysics(),
            child: CustomCard(
              title: 'الإبلاغ عن السائق',
              children: [
                Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      const VerticalSizedBox(15),
                      CustomTextFormField(
                        label: 'السبب',
                        controller: _reportController,
                        textInputAction: TextInputAction.newline,
                        textInputType: TextInputType.multiline,
                        validator: Validators.checkIfNotEmpty,
                        onSaved: null,
                        maxLength: 100,
                        minLines: 5,
                        maxLines: 10,
                        autoFocus: true,
                      ),
                      const VerticalSizedBox(15),
                      CustomElevatedIconButton(
                        iconData: Icons.send_outlined,
                        title: 'إرسال',
                        onPressed: _save,
                      ),
                      const VerticalSizedBox(15),
                    ],
                  ),
                ),
              ],
              // color: color,
            ),
          ),
        ),
      ),
    );
  }
}
