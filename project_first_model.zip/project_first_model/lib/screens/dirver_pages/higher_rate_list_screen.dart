import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/models/regions_model.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/main_screen_widgets/higher_rating_drivers/higher_rate_driver_list.dart';
import 'package:project_first_model/widgets/utiles/custom_dropdown_btn.dart';
import 'package:project_first_model/widgets/utiles/custom_scaffold_scroll.dart';

@RoutePage()
class HigherRateListScreen extends StatefulWidget {
  const HigherRateListScreen({Key? key}) : super(key: key);

  @override
  State<HigherRateListScreen> createState() => _HigherRateListScreenState();
}

class _HigherRateListScreenState extends State<HigherRateListScreen> {
  final scrollController = ScrollController();

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffoldScroll(
      controller: scrollController,
      appBar: AppBar(
        title: const Text('الأعلى تقييماَ'),
        actions: [
          Padding(
            padding: CustomEdgeInsets.all(16.0),
            child: SizedBox(
              width: 350.w,
              child: CustomDropDownBtn(
                items:
                    RegionModel.regionsList.followedBy(['غير محدد']).toList(),
                onChange: (value) {
                  Get.find<RatingController>().addFilter(value ?? '');
                },
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          controller: scrollController,
          children: [
            const Divider(),
            HigherRateDriverList(controller: scrollController),
          ],
        ),
      ),
    );
  }
}
