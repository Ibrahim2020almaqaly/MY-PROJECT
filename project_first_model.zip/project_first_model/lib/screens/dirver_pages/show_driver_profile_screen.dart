import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';

@RoutePage()
class ShowDriverProfileScreen extends StatelessWidget {
  const ShowDriverProfileScreen({
    Key? key,
    @PathParam(/**optinal alias in case this param not same */)
    required this.driverId,
  }) : super(key: key);
  final String driverId;

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('show Driver Profile'),
      ),
    );
  }
}
