import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

@RoutePage()
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'الإشعارات',
        ),
        actions: [
          CustomIconButton(
            iconData: Icons.mark_chat_read_outlined,
            tooltip: "تحديد الكل كمقروء",
            iconSize: 84,
            onPressed: () {},
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: CustomEdgeInsets.all(16),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                ImageHelpers.getLottieAssetImage(
                  800.0,
                  500.0,
                  Assets.lottieIcons.bellSnooze,
                ),
                const VerticalSizedBox(20),
                const Text(
                  'لايوجد إشعارات بعد !',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
