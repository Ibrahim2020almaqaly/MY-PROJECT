import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:project_first_model/widgets/main_screen_widgets/overland_transports/overland_transport_list.dart';
import 'package:project_first_model/widgets/utiles/custom_scaffold_scroll.dart';

@RoutePage()
class OverlandTransportsListScreen extends StatefulWidget {
  const OverlandTransportsListScreen({Key? key}) : super(key: key);

  @override
  State<OverlandTransportsListScreen> createState() =>
      _OverlandTransportsListScreenState();
}

class _OverlandTransportsListScreenState
    extends State<OverlandTransportsListScreen> {
  final scrollController = ScrollController();

  @override
  void dispose() {
    super.dispose();
    scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffoldScroll(
      controller: scrollController,
      appBar: AppBar(
        title: const Text('وكالات النقل المتاحة '),
      ),
      body: SafeArea(
        child: ListView(
          controller: scrollController,
          children: [
            OverlandTransportList(
              controller: scrollController,
            ),
          ],
        ),
      ),
    );
    // Scaffold(
    //   appBar: AppBar(
    //     title: const Text('وكالات النقل المتاحة '),
    //     centerTitle: true,
    //   ),
    //   body: SafeArea(
    //     child: ListView(
    //       controller: scrollController,
    //       children: [
    //         OverlandTransportList(
    //           controller: scrollController,
    //         ),
    //       ],
    //     ),
    //   ),
    // );
  }
}
