import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';

@RoutePage()
class ShowTransporterProfileScreen extends StatelessWidget {
  const ShowTransporterProfileScreen({
    Key? key,
    @PathParam() required this.transporterId,
  }) : super(key: key);

  final String transporterId;

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('show Transporter Profile'),
      ),
    );
  }
}
