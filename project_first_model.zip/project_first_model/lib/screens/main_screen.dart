import 'package:auto_route/auto_route.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:project_first_model/router/router.dart';
import 'package:upgrader/upgrader.dart';

import 'package:project_first_model/controllers/bottom_nav_bar_controller.dart';
import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/theme_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/models/cities_model.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';

@RoutePage()
class MainScreen extends StatefulWidget {
  const MainScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  final navigationKey = GlobalKey<CurvedNavigationBarState>();
  late Map<String, Widget> items;

  @override
  void initState() {
    // items = {
    //   'home': const Icon(
    //     FontAwesomeIcons.house,
    //     size: 28,
    //   ),
    //   'addTrip': const Icon(
    //     FontAwesomeIcons.circlePlus,
    //     size: 28,
    //   ),
    //   'search': const Icon(
    //     FontAwesomeIcons.magnifyingGlass,
    //     size: 28,
    //   ),
    //   'profile': GetBuilder<UserController>(
    //     init: UserController(),
    //     builder: (prov) {
    //       return CircleSqureImage(
    //         pic: prov.getUserData.userPic,
    //         height: 100,
    //         width: 100,
    //         radius: 50,
    //         id: prov.getUserData.userPic,
    //       );
    //     },
    //   ),
    // };
    items = Get.find<BottomNavBarController>().items;
    super.initState();
  }

  // void _checkVersion() async {
  //   try {
  //     final isOnline =
  //         Provider.of<ConnectionProvider>(context, listen: false).isOnline;

  //     if (isOnline) {
  //       final newVersion = NewVersionPlus();

  //       final status = await newVersion.getVersionStatus();
  //       if (status == null) return;
  //       if (status.canUpdate) {
  //         newVersion.showUpdateDialog(
  //           context: context,
  //           versionStatus: status,
  //           dialogTitle: 'تحديث متوفر !!',
  //           dismissAction: () => SystemNavigator.pop(),
  //           dismissButtonText: 'إلغاء',
  //           updateButtonText: 'تحميل من المتجر',
  //           dialogText:
  //               'الرجاء تنزيل النسخة ${status.storeVersion} من المتجر \n ${status.releaseNotes}',
  //         );
  //       }
  //     }
  //   } on Exception catch (e) {
  //     ShowAnyMessages.showToastMSG(e.toString());
  //   }
  // }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  void dispose() {
    // AwesomeNotificationService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colorTheme = Theme.of(context);
    return UpgradeAlert(
      upgrader: Upgrader(
        languageCode: 'ar',
        canDismissDialog: true,
        messages: UpgraderMessages(code: 'ar'),
        dialogStyle: UpgradeDialogStyle.material,
        showReleaseNotes: true,
        showIgnore: false,
      ),
      child: AutoTabsScaffold(
          // appBarBuilder: (ctx, tabsRouter) {
          //   return AppBar(
          //     elevation: 0,
          //     actions: [
          //       CustomShowCase(
          //         globalkey: notificationskey,
          //         description: 'هنا سوف يتم تلقي الإشعارات',
          //         child: CustomIconButton(
          //           iconData: Icons.notifications_outlined,
          //           tooltip: 'الإشعارات',
          //           iconSize: 84.0,
          //           allowRegisterOnly: false,
          //           onPressed: () {
          //             Get.find<AppRouter>()
          //                 .push(const NotificationsScreenRoute());
          //           },
          //         ),
          //       ),
          //     ],
          //   );
          // },
          routes: const [
            MainScreenBodyRouter(),
            AddTripRouter(),
            SearchTripsRouter(),
            AccountSettingsScreenRouter(),
          ],
          // body: GetBuilder<BottomNavBarController>(
          //   builder: (bottomProve) {
          //     return IndexedStack(
          //       index: bottomProve.index,
          //       children: bottomProve.screens,
          //     );
          //   },
          // ),

          lazyLoad: true,
          homeIndex: 0,
          animationCurve: Curves.easeInOutCirc,
          // persistentFooterButtons: [
          //   AdsHelper(
          //     adSize: AdSize.banner,
          //     bannerUnitID: GoogleMobAds.getBottomUnitID(),
          //     inlineAd: false,
          //   ),
          // ],

          bottomNavigationBuilder: (_, tabsRouter) {
            return GetBuilder<ThemeController>(
              builder: (themeProv) {
                return CurvedNavigationBar(
                  key: navigationKey,
                  height: 60,
                  backgroundColor: colorTheme.iconTheme.color!.withAlpha(70),
                  color: themeProv.isDarkMode ? Colors.black : Colors.white,
                  index: tabsRouter.activeIndex, //bottomProv.index,
                  animationCurve: Curves.bounceInOut,
                  animationDuration: const Duration(milliseconds: 300),
                  items: items.values.toList(),
                  onTap: (index) async {
                    final screen = items.keys.toList()[index];
                    if (screen != 'addTrip') {
                      tabsRouter.setActiveIndex(index);
                      return;
                    }
                    final onLine = Get.find<ConnectionController>().isOnline;
                    if (!onLine) {
                      await ShowAnyMessages.noConnMsg(context);
                      returnToThePrevPage(tabsRouter.activeIndex);
                      return;
                    }
                    if (screen == 'addTrip') {
                      final auth = Get.find<FirebaseAuthController>()
                          .isThereAUserLoggedin;
                      if (!auth) {
                        // tabsRouter.setActiveIndex(index);
                        // return;
                        final log =
                            await ShowCustomDialog.notLoggedInUser(context);
                        if (log) {
                          Get.find<AppRouter>()
                              .push(const RegisterScreenRouter());
                        }
                        returnToThePrevPage(tabsRouter.activeIndex);
                        return;
                      }
                      //
                      final empty =
                          Get.find<UserController>().checkIfNotEmpty();
                      if (empty != null) {
                        await ShowAnyMessages.showDialogMessage(
                          context,
                          empty,
                          'لا يمكنك إضافة رحلة',
                          icon: Assets.lottieIcons.userProfileV2,
                        );
                        returnToThePrevPage(tabsRouter.activeIndex);
                        return;
                      }
                      tabsRouter.setActiveIndex(index);
                    } else {
                      tabsRouter.setActiveIndex(index);
                    }
                  },
                );
              },
            );
          }),
    );
  }

  void returnToThePrevPage(int activeIndex) {
    //Which is addTrip Screen
    if (activeIndex != 1) {
      navigationKey.currentState!.setPage(activeIndex);
    } else {
      navigationKey.currentState!.setPage(0);
    }
  }
}

class Search extends SearchDelegate<String> {
  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {
          if (query.isEmpty) {
            close(context, '');
          } else {
            query = '';
            showSuggestions(context);
          }
        },
        icon: const Icon(Icons.clear_outlined),
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () => close(context, ''),
      icon: const Icon(Icons.arrow_back_outlined),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            query,
            style: TextStyle(
              color: Colors.black,
              fontSize: 64.sp,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // final suggestions = query.isEmpty
    //     ? [...recentCities]
    //     : cities.where((city) {
    //         final lowerCity = city.toLowerCase();
    //         final lowerQuery = query.toLowerCase();
    //         return lowerCity.startsWith(lowerQuery);
    //       }).toList();

    // return buildSuggestionsSuccess(suggestions);
    return Container(
      color: Theme.of(context).primaryColor,
      child: FutureBuilder(
        future: CityModel.startWithCitySuggestionsString(query),
        initialData: null,
        builder: (context, AsyncSnapshot snapshot) {
          if (query.isEmpty) {
            return const Center(
              child: Text('No Suggestions'),
            );
          }
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
              return const Center(
                child: CircularProgressIndicator(),
              );
            default:
              if (snapshot.hasError || snapshot.data.isEmpty) {
                return const Center(
                  child: Text('No Suggestions'),
                );
              }
              return buildSuggestionsSuccess(snapshot.data);
          }
        },
      ),
    );
  }

  Widget buildSuggestionsSuccess(List<String> suggestions) {
    return Container(
      margin: CustomEdgeInsets.all(20),
      child: ListView.separated(
        itemCount: suggestions.length,
        separatorBuilder: (BuildContext context, int index) {
          return const Divider();
        },
        itemBuilder: (BuildContext context, int index) {
          final suggestion = suggestions[index];
          final queryText = suggestion.substring(0, query.length);
          final remainingText = suggestion.substring(query.length);
          return ListTile(
            onTap: () {
              query = suggestion;
              close(context, suggestion);
              // showResults(context);
            },
            // title: Text(suggestions[index]),
            title: RichText(
              text: TextSpan(
                text: queryText,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.bold,
                  fontSize: 18.sp,
                ),
                children: [
                  TextSpan(
                    text: remainingText,
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 18.sp,
                    ),
                  ),
                ],
              ),
            ),
            subtitle: const Text('Phone Number'),
          );
        },
      ),
    );
  }
}
