import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:project_first_model/widgets/main_screen_widgets/main_screen_body.dart';
import 'package:project_first_model/widgets/utiles/custom_scaffold_scroll.dart';

@RoutePage()
class TestingWidget extends StatefulWidget {
  const TestingWidget({Key? key}) : super(key: key);

  @override
  TestingWidgetState createState() => TestingWidgetState();
}

class TestingWidgetState extends State<TestingWidget> {
  final controller = ScrollController();
  var visible = false;

  @override
  void initState() {
    super.initState();
    // controller.addListener(() {
    //   if (controller.position.atEdge) {
    //     if (visible) {
    //       setState(() {
    //         visible = false;
    //       });
    //     }
    //   } else if (controller.position.pixels > 500) {
    //     if (!visible) {
    //       setState(() {
    //         visible = true;
    //       });
    //     }
    //   } else {
    //     if (visible) {
    //       setState(() {
    //         visible = false;
    //       });
    //     }
    //   }
    // });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffoldScroll(
      appBar: AppBar(),
      controller: controller,
      body: MainScreenBody(controller: controller),
      //     ListView.builder(
      //   controller: controller,
      //   itemCount: 100,
      //   itemBuilder: (BuildContext context, int index) {
      //     return OfferItemsV2(
      //       trip: TripModel.testTrip,
      //       getTripData: (s) async {
      //         return TripModel.testTrip;
      //       },
      //     );
      //   },
      // ),
    );
  }
}
