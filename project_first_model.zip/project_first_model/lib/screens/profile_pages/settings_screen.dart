import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/theme_controller.dart';
import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/services/app_info.dart';
import 'package:project_first_model/services/app_settings.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/image_helpers.dart';
import 'package:project_first_model/widgets/profile_widgets/account_settings_items.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_switch.dart';

@RoutePage()
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var on = AppSettings.getSettingValue(AppSettings.isDataSaverOnKey, false);
    return Scaffold(
      appBar: AppBar(
        title: const Text('الإعدادات'),
      ),
      body: SafeArea(
        child: Padding(
          padding: CustomEdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const VerticalSizedBox(50),
                _CustomGroupSettings(
                  groupTilte: 'الحساب',
                  height: 450,
                  child: Card(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AccountSettingsItems(
                          iconData:
                              Icons.edit_outlined, // FontAwesomeIcons.userp,
                          title: 'تعديل بيانات الملف الشخصي',
                          onTab: () =>
                              // Get.toNamed(Routes.profileScreen),
                              Get.find<AppRouter>().push(const ProfileRoute()),
                        ),
                        const VerticalSizedBox(7),
                        AccountSettingsItems(
                          iconData: Icons.card_travel_outlined,
                          title: 'أرشيف الرحلات',
                          onTab: () =>
                              // Get.toNamed(Routes.tripsHistoryListScreen),
                              Get.find<AppRouter>()
                                  .push(const TripsHistoryListRoute()),
                          subtitle:
                              'يمكنك الوصول إلى هذة الواجهة عن طريق الضغط على أيقونة عدد الرحلات من الواجهة السابقة',
                        ),
                      ],
                    ),
                  ),
                ),
                const VerticalSizedBox(50),
                _CustomGroupSettings(
                  groupTilte: 'المظهر',
                  height: 270,
                  child: Card(
                    child: AccountSettingsItems(
                      key: const Key(AppSettings.themeKey),
                      iconData: Icons.dark_mode_outlined,
                      title: 'الثيم',
                      trailing: _CustomSettingsItems(
                        settingKey: AppSettings.themeKey,
                        values: const {
                          0: 'تلقائي',
                          1: 'فاتح',
                          2: 'مظلم',
                        },
                        initialValue: 0,
                        onchanged: (mode) =>
                            Get.find<ThemeController>().toggleTheme(mode),
                      ),
                    ),
                  ),
                ),
                const VerticalSizedBox(50),
                const _CustomGroupSettings(
                  groupTilte: 'المنبه',
                  height: 410,
                  child: Card(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AccountSettingsItems(
                          key: Key(AppSettings.remindMeKey),
                          iconData: Icons.alarm_outlined,
                          title: 'ذكرني قبل موعد الرحلة ب:',
                          trailing: _CustomSettingsItems(
                            settingKey: AppSettings.remindMeKey,
                            values: {
                              15: 'ربع ساعة',
                              30: 'نصف ساعة',
                              60: 'ساعة',
                              90: 'ساعة ونصف',
                              120: 'ساعتين',
                            },
                            initialValue: 30,
                          ),
                        ),
                        AccountSettingsItems(
                          key: Key(AppSettings.remindTimesKey),
                          iconData: Icons.timer_outlined,
                          title: 'عدد مرات التذكير :',
                          trailing: _CustomSettingsItems(
                            settingKey: AppSettings.remindTimesKey,
                            values: {
                              1: 'مرة',
                              3: 'ثلاث مرات',
                              5: 'خمس مرات',
                            },
                            initialValue: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const VerticalSizedBox(50),
                _CustomGroupSettings(
                  groupTilte: 'توفير البيانات',
                  height: 260,
                  child: Card(
                    child: CustomSwitch(
                      activeColor:
                          Theme.of(context).appBarTheme.actionsIconTheme?.color,
                      enabled: on,
                      title: 'تفعيل وضع توفير البيانات:',
                      updateSwitch: (enabled) {
                        AppSettings.setSettingValue<bool>(
                            AppSettings.isDataSaverOnKey, enabled == 1);
                      },
                    ),
                  ),
                ),
                const VerticalSizedBox(50),
                ImageHelpers.getAssetImage(
                  250.0,
                  250.0,
                  pic: Assets.images.companyLogo.path,
                ),
                AppInfo.getDevloperTeamNameWidget,
                const VerticalSizedBox(50),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CustomSettingsItems extends StatefulWidget {
  const _CustomSettingsItems({
    Key? key,
    required this.settingKey,
    required this.values,
    required this.initialValue,
    this.onchanged,
  }) : super(key: key);

  final String settingKey;
  final Map<int, String> values;
  final int initialValue;
  final void Function(int mode)? onchanged;

  @override
  State<_CustomSettingsItems> createState() => _CustomSettingsItemsState();
}

class _CustomSettingsItemsState extends State<_CustomSettingsItems> {
  late int selected;
  @override
  void initState() {
    selected = AppSettings.getSettingValue<int>(
        widget.settingKey, widget.initialValue);
    super.initState();
  }

  List<DropdownMenuItem<int>>? _buildDropMenuItems() {
    return [
      ...widget.values.entries.map(
        (e) => DropdownMenuItem(
          value: e.key,
          child: Text(e.value),
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return DropdownButton<int>(
      value: selected,
      elevation: 4,
      items: [...?_buildDropMenuItems()],
      onChanged: (mode) async {
        if (mode == null) return;
        AppSettings.setSettingValue<int>(widget.settingKey, mode);
        if (widget.onchanged != null) {
          widget.onchanged!(mode);
        }
        setState(() {
          selected = mode;
        });
      },
    );
  }
}

class _CustomGroupSettings extends StatelessWidget {
  const _CustomGroupSettings({
    Key? key,
    required this.groupTilte,
    required this.child,
    required this.height,
  }) : super(key: key);
  final String groupTilte;
  final Widget child;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height.h,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.max,
        children: [
          Padding(
            padding: CustomEdgeInsets.only(right: 20.0),
            child: Text(
              groupTilte,
              style: const TextStyle(
                color: Colors.teal,
              ),
            ),
          ),
          const VerticalSizedBox(12),
          child,
        ],
      ),
    );
  }
}
