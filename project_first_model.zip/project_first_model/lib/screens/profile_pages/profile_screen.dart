import 'dart:io';

import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/models/user_modelv2.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_card.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_image_viewer.dart';
import 'package:project_first_model/widgets/profile_widgets/mini_profile.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

@RoutePage()
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    Key? key,
    // required this.popAllow,
  }) : super(key: key);

  // final void Function(bool isAllow) popAllow;

  @override
  ProfileScreenState createState() => ProfileScreenState();
}

class ProfileScreenState extends State<ProfileScreen> {
  final _driverNameController = TextEditingController();
  final _regionNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  List<File?> images = [null, null, null];
  UserModelV2 _userModel = UserModelV2.defaultUser;
  UserModelV2? _oldUser;
  var alreadyUser = false;

  void _pickImage(int index, File? image) {
    if (image != null) {
      images[index] = image;
    } else {
      images[index] = null;
    }
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      _setupScreen();
    });
  }

  void _setupScreen() async {
    CustomOverlayLoading.showOverlayLoading();

    try {
      final prov = Get.find<UserController>();
      final user = Get.find<FirebaseAuthController>().getCurrentUser;
      _userModel = await prov.requestMyData();
      if (_userModel != UserModelV2.defaultUser) {
        alreadyUser = true;
        _oldUser = _userModel.copyWith();
      }
      _userModel = _userModel.copyWith(userPhoneNumber: user?.phoneNumber);

      _getData();

      // if (!mounted) return;
      CustomOverlayLoading.hideOverlayLoading();
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();

      ShowAnyMessages.showDialogMessage(
        context,
        e.errorMessage,
        'خطأ',
      );
    } on Exception catch (e) {
      // Loader.hide();
      CustomOverlayLoading.hideOverlayLoading();
      ShowAnyMessages.showDialogMessage(
        context,
        e.toString(),
        'خطأ',
      );
    }
  }

  void _getData() {
    setState(() {
      _driverNameController.text = _userModel.userName;
      _regionNameController.text = _userModel.region;
      _phoneController.text = _userModel.userPhoneNumber;
      _pickImage(0, File(_userModel.userPic));
      _pickImage(1, File(_userModel.userCarPic1));
      _pickImage(2, File(_userModel.userCarPic2));
    });
  }

  String? _getPath(File? image) {
    return image != null
        ? image.path.contains('assets/images')
            ? ''
            : image.path
        : '';
  }

  void _save() async {
    final isValid = _formKey.currentState?.validate() ?? false;

    FocusManager.instance.primaryFocus?.unfocus();

    if (!isValid) return;

    _formKey.currentState!.save();
    _userModel = _userModel.copyWith(
      region: _regionNameController.text.trim(),
      userPic: _getPath(images[0]),
      userCarPic1: _getPath(images[1]),
      userCarPic2: _getPath(images[2]),
    );

    if (alreadyUser) {
      final yes = await Utiles.editItem(
        context,
      );
      if (!yes) return;

      if (_oldUser != null && (_oldUser!) == _userModel) {
        savedSuccessfully();
        return;
      }
    }

    // if (!mounted) return;

    CustomOverlayLoading.showOverlayLoading();

    try {
      final authProv = Get.find<FirebaseAuthController>();

      final valid = await authProv.validToken();
      if (!valid) return;

      // if (!mounted) return;
      final userProv = Get.find<UserController>();
      // final rateProv = Provider.of<RatingProvider>(context, listen: false);

      if (_userModel.userId.isNotEmpty && _userModel.userId != '') {
        await userProv.updateUser(_userModel);
      } else {
        await userProv.addUser(_userModel);
      }
      CustomOverlayLoading.hideOverlayLoading();
      savedSuccessfully();
    } on CustomException catch (e) {
      // Loader.hide();
      CustomOverlayLoading.hideOverlayLoading();
      if (!mounted) return;
      ShowAnyMessages.showSnackBar(
        context,
        e.errorMessage,
        isError: true,
        floating: false,
      );
    }
  }

  void savedSuccessfully() {
    ShowAnyMessages.showSnackBar(
      context,
      'تمت الحفظ بنجاح',
      floating: false,
      isSuccess: true,
    );
  }

  @override
  void dispose() {
    super.dispose();
    _regionNameController.dispose();
    _driverNameController.dispose();
    _phoneController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text(
          'الملف الشخصي',
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 16.0.w),
            child: CustomIconButton(
              iconData: Icons.save_outlined,
              tooltip: 'حفظ',
              iconSize: 80.0,
              onPressed: _save,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: CustomEdgeInsets.all(16.0),
          child: GestureDetector(
            onTap: () {
              FocusManager.instance.primaryFocus?.unfocus();
            },
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                reverse: true,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    //Driver Informatio
                    CustomCard(
                      title: 'معلومات السائق',
                      children: [
                        MiniProfile(
                          imageHandeler: _pickImage,
                          driverNameController: _driverNameController,
                          regionNameController: _regionNameController,
                          onUsernameSaved: (value) {
                            _userModel =
                                _userModel.copyWith(userName: value?.trim());
                          },
                          image: images[0],
                        ),
                        const VerticalSizedBox(35),
                        CustomTextFormField(
                          label: 'رقم الهاتف',
                          maxLength: 13,
                          readOnly: true,
                          controller: _phoneController,
                          textInputAction: TextInputAction.done,
                          textInputType: TextInputType.phone,
                          textDirection: TextDirection.ltr,
                          textAlign: TextAlign.end,
                          validator: Validators.validatePhoneNumberField,
                          onSaved: (value) {
                            _userModel =
                                _userModel.copyWith(userPhoneNumber: value);
                          },
                          canDeleteText: false,
                        ),
                        const VerticalSizedBox(35),
                      ],
                      // color: themeColor.colorScheme.onSurface,
                    ),
                    //Car information
                    CustomCard(
                      title: 'معلومات المركبة',
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Expanded(
                              child: CustomImageViewer(
                                index: 1,
                                imageHandeler: _pickImage,
                                image: images[1],
                                height: 700,
                                id: _userModel.userCarPic1,
                              ),
                            ),
                            const HorizantalSizedBox(30),
                            Expanded(
                              child: CustomImageViewer(
                                index: 2,
                                imageHandeler: _pickImage,
                                image: images[2],
                                height: 700,
                                id: _userModel.userCarPic2,
                              ),
                            ),
                          ],
                        ),
                      ],
                      // color: themeColor.colorScheme.onSurface,
                    ),

                    const VerticalSizedBox(35),

                    CustomElevatedButton(
                      title: 'حفظ',
                      onPressed: _save,
                    ),

                    const BottomPadding(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
