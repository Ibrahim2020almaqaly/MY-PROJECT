import 'dart:io';

import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/models/user_modelv2.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/services/app_settings.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_card.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/profile_widgets/mini_profile.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

@RoutePage()
class ViewMiniProfileScreen extends StatefulWidget {
  const ViewMiniProfileScreen({Key? key}) : super(key: key);

  @override
  State<ViewMiniProfileScreen> createState() => _ViewMiniProfileScreenState();
}

class _ViewMiniProfileScreenState extends State<ViewMiniProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _driverNameController = TextEditingController();
  final _regionNameController = TextEditingController();
  var _userModel = UserModelV2.defaultUser;
  UserModelV2? _oldUser;
  File? userImage;
  var alreadyUser = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      _setupScreen();
    });
  }

  void _setupScreen() async {
    CustomOverlayLoading.showOverlayLoading();

    try {
      final prov = Get.find<UserController>();

      _userModel = await prov.requestMyData();
      if (_userModel != UserModelV2.defaultUser) {
        alreadyUser = true;
        _oldUser = _userModel;
      }

      _getData();

      // if (!mounted) return;
      CustomOverlayLoading.hideOverlayLoading();
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();

      ShowAnyMessages.showDialogMessage(
        context,
        e.errorMessage,
        'خطأ',
      );
    } on Exception catch (e) {
      CustomOverlayLoading.hideOverlayLoading();

      ShowAnyMessages.showDialogMessage(
        context,
        e.toString(),
        'خطأ',
      );
    }
  }

  void _getData() {
    setState(() {
      _driverNameController.text = _userModel.userName;
      _regionNameController.text = _userModel.region;
      userImage = File(_userModel.userPic);
    });
  }

  void _save() async {
    final isValid = _formKey.currentState?.validate() ?? false;

    FocusManager.instance.primaryFocus?.unfocus();

    if (!isValid) return;
    final authProv = Get.find<FirebaseAuthController>();

    _formKey.currentState!.save();
    final phone = authProv.getCurrentUser!.phoneNumber;
    _userModel = _userModel.copyWith(
      userPhoneNumber: phone,
      region: _regionNameController.text.trim(),
      userPic: userImage?.path ?? '',
    );

    if (alreadyUser) {
      final yes = await Utiles.editItem(
        context,
      );
      if (!yes) return;

      if (_oldUser != null && (_oldUser!) == _userModel) {
        savedSuccessfully();
        return;
      }
    }

    // if (!mounted) return;

    CustomOverlayLoading.showOverlayLoading();

    try {
      final valid = await authProv.validToken();
      if (!valid) return;

      // if (!mounted) return;
      final userProv = Get.find<UserController>();

      if (_userModel.userId.isNotEmpty && _userModel.userId != '') {
        await userProv.updateUser(_userModel);
      } else {
        await userProv.addUser(_userModel);
      }

      CustomOverlayLoading.hideOverlayLoading();
      savedSuccessfully();
    } on CustomException catch (e) {
      CustomOverlayLoading.hideOverlayLoading();
      if (!mounted) return;
      ShowAnyMessages.showSnackBar(context, e.errorMessage, isError: true);
    }
  }

  void savedSuccessfully() {
    ShowAnyMessages.showSnackBar(
      context,
      'تمت الحفظ بنجاح',
      isSuccess: true,
    );
    AppSettings.setSettingValue<bool>(AppSettings.enteredTheDataKey, true);
    // Get.offAllNamed(Routes.mainPageName);
    Get.find<AppRouter>()
        .pushAndPopUntil(const MainScreenRouter(), predicate: (route) => false);
  }

  @override
  void dispose() {
    super.dispose();
    _driverNameController.dispose();
    _regionNameController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الملف الشخصي'),
        actions: [
          Padding(
            padding: CustomEdgeInsets.all(8.0),
            child: CustomIconButton(
              iconData: Icons.save_outlined,
              tooltip: 'حفظ',
              iconSize: 80.0,
              onPressed: _save,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              reverse: true,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomCard(
                    title: '',
                    children: [
                      MiniProfile(
                        imageHandeler: (int index, File? image) {
                          userImage = image;
                        },
                        driverNameController: _driverNameController,
                        regionNameController: _regionNameController,
                        onUsernameSaved: (value) {
                          _userModel = _userModel.copyWith(userName: value);
                        },
                        image: userImage,
                      ),
                      const VerticalSizedBox(30),
                      const BottomPadding(),
                    ],
                  ),
                  const VerticalSizedBox(350),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
