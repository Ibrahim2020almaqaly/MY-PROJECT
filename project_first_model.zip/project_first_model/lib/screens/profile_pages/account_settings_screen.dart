import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/alarm_controllers/alarm_controller.dart';
import 'package:project_first_model/controllers/connection_controller.dart';
import 'package:project_first_model/controllers/driver_controllers/rating_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/controllers/user_controllers/user_controller.dart';

import 'package:project_first_model/gen/assets.gen.dart';
import 'package:project_first_model/helpers/show_custom_dialog.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/router/router.gr.dart';
import 'package:project_first_model/services/app_info.dart';
import 'package:project_first_model/widgets/helper_widgets/circle_image.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/profile_widgets/account_settings_items.dart';
import 'package:project_first_model/widgets/profile_widgets/app_icon_theme.dart';
import 'package:project_first_model/widgets/utiles/custom_icon_button.dart';
import 'package:project_first_model/widgets/utiles/custom_ink_well.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

@RoutePage()
class AccountSettingsScreen extends StatelessWidget {
  const AccountSettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إعدادت الحساب'),
        actions: [
          Padding(
            padding: CustomEdgeInsets.all(16.0),
            child: const AppIconTheme(),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: CustomEdgeInsets.all(24.0),
          child: SingleChildScrollView(
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.spaceAround,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CustomInkWell(
                  onTap: () {
                    // Get.toNamed(Routes.profileScreen);
                    Get.find<AppRouter>().push(const ProfileRoute());
                  },
                  child: const _ProfilePreview(),
                ),
                Divider(height: 16.0.h),
                const Divider(),
                GetBuilder<FirebaseAuthController>(
                  init: FirebaseAuthController(),
                  builder: (auth) {
                    if (!auth.isThereAUserLoggedin) {
                      return Column(
                        children: [
                          AccountSettingsItems(
                            iconData: Icons.login_outlined,
                            title: 'تسجيل الدخول',
                            onTab: () async {
                              // Get.toNamed(Routes.welcomeScreen);
                              Get.find<AppRouter>()
                                  .push(const WelcomeScreenRouter());
                            },
                            allowRegisterOnly: false,
                          ),
                          const Divider(),
                        ],
                      );
                    } else {
                      return const SizedBox();
                    }
                  },
                ),
                AccountSettingsItems(
                  iconData: Icons.settings_outlined,
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                  title: 'الإعدادت',
                  subtitle: 'الحساب, المظهر, المنبه, توفير البيانات',
                  onTab: () =>
                      // Get.toNamed(Routes.settingsScreen),
                      Get.find<AppRouter>().push(const SettingsRoute()),
                ),
                AccountSettingsItems(
                  iconData: Icons.alarm_outlined,
                  allowOnlineOnly: false,
                  title: 'التنبيهات',
                  subtitle: 'هنا جميع الرحلات التي سوف يذكّرك التطبيق بها',
                  onTab: () =>
                      // Get.toNamed(Routes.alarmsScreen),
                      Get.find<AppRouter>().push(const AlarmsRoute()),
                ),
                const Divider(),
                AccountSettingsItems(
                  iconData: Icons.info_outline,
                  title: 'حول التطبيق',
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                  onTab: () {
                    // ShowCustomDialog.showCustomAboutDialog(context);
                    Get.find<AppRouter>().push(const AboutRoute());
                    // Get.toNamed(Routes.aboutScreen);
                  },
                ),
                // AccountSettingsItems(
                //   iconData: Icons.share_outlined,
                //   title: 'مشاركة التطبيق',
                //   allowOnlineOnly: false,
                //   allowRegisterOnly: false,
                //   onTab: () {},
                // ),
                AccountSettingsItems(
                  iconData: Icons.contact_support_outlined,
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                  title: 'للتواصل معنا',
                  onTab: () {
                    ShowCustomDialog.showContactUsDialog(context);
                  },
                ),
                AccountSettingsItems(
                  iconData: Icons.feedback_outlined,
                  title: 'آراءكم ومقترحاتكم',
                  onTab: () =>
                      // Get.toNamed(Routes.suggestionScreen),
                      Get.find<AppRouter>().push(const SuggestionRoute()),
                ),
                AccountSettingsItems(
                  iconData: Icons.report_problem_outlined,
                  title: 'التبليغ عن أخطاء',
                  onTab: () =>
                      // Get.toNamed(Routes.errorReportScreen),
                      Get.find<AppRouter>().push(const ErrorReportRoute()),
                ),
                AccountSettingsItems(
                  iconData: Icons.privacy_tip_outlined,
                  title: 'سياسة الخصوصية',
                  onTab: () async {
                    await Utiles.visitSite(Utiles.privacyPolicyURL);
                    // Get.find<AppRouter>().push(const PrivacyPolicyScreenRoute());
                  },
                  allowRegisterOnly: false,
                  allowOnlineOnly: false,
                ),
                const Divider(),
                GetBuilder<FirebaseAuthController>(
                  builder: (auth) {
                    if (auth.isThereAUserLoggedin) {
                      return AccountSettingsItems(
                        iconData: Icons.logout_outlined,
                        title: 'تسجيل الخروج',
                        onTab: () async {
                          final logout = await ShowCustomDialog
                              .showConfirmationDialogMessage(
                            context,
                            'هل تريد فعلاً تسجيل الخروج ؟\n سوف يتم تعطيل جميع تنبيهات الرحلات في حالة تسجيل الخروج',
                            'تأكيد تسجيل الخروج',
                            icon: Assets.lottieIcons.logout,
                          );
                          if (logout) {
                            final alarmProv = Get.find<AlarmController>();
                            await alarmProv.disableAllAlarms();

                            await Get.find<FirebaseAuthController>().logOut();

                            Get.find<AppRouter>().pushAndPopUntil(
                                const WelcomeScreenRouter(),
                                predicate: (route) => false);

                            // Get.offAllNamed(Routes.welcomeScreen);
                          }
                        },
                      );
                    } else {
                      return const SizedBox();
                    }
                  },
                ),
                const VerticalSizedBox(30.0),
                AppInfo.getDevloperTeamNameWidget,
                const VerticalSizedBox(50),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ProfilePreview extends StatelessWidget {
  const _ProfilePreview({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<UserController>(
      builder: (userProv) {
        final user = userProv.getUserData;
        final isAuthed = Get.find<FirebaseAuthController>();
        return Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Hero(
              tag: 'UserPic',
              transitionOnUserGestures: true,
              child: CircleSqureImage(
                pic: user.userPic,
                width: 400,
                height: 400,
                radius: 200,
                id: user.userPic,
              ),
            ),
            const VerticalSizedBox(30),
            Text(
              !isAuthed.isThereAUserLoggedin ? 'لا يوجد حساب' : user.userName,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 60.0.sp,
              ),
            ),
            const VerticalSizedBox(30),
            const Divider(),
            _ProfileDetails(userID: isAuthed.getCurrentUser?.uid ?? ''),
            const VerticalSizedBox(35),
          ],
        );
      },
    );
  }
}

class _ProfileDetails extends StatefulWidget {
  const _ProfileDetails({
    Key? key,
    required this.userID,
  }) : super(key: key);
  final String userID;

  @override
  State<_ProfileDetails> createState() => _ProfileDetailsState();
}

class _ProfileDetailsState extends State<_ProfileDetails> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<RatingController>(
      builder: (prov) {
        prov.getDriverRate(widget.userID);
        final rate = prov.getCurrentDriverRating;
        return Stack(
          clipBehavior: Clip.none,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              mainAxisSize: MainAxisSize.max,
              children: [
                const HorizantalSizedBox(35),
                _ProfileSubItems(
                  allowOnlineOnly: true,
                  iconData: Icons.star,
                  title: 'التقييم',
                  subtitle: rate.starsRatio.toStringAsFixed(1),
                ),
                const HorizantalSizedBox(35),
                _ProfileSubItems(
                  allowRegisterOnly: true,
                  iconData: Icons.people,
                  title: 'عدد المقيمين',
                  subtitle: rate.ratingPeopleCount.toString(),
                ),
                const HorizantalSizedBox(35),
                _ProfileSubItems(
                  iconData: Icons.card_travel_outlined,
                  title: 'عدد الرحلات',
                  subtitle: rate.tripsCount.toString(),
                  allowOnlineOnly: false,
                  allowRegisterOnly: false,
                  onTab: () {
                    // Get.toNamed(Routes.tripsHistoryListScreen);
                    Get.find<AppRouter>().push(const TripsHistoryListRoute());
                  },
                ),
                const HorizantalSizedBox(35),
              ],
            ),
            Positioned(
              right: -20.w,
              top: -40.h,
              child: CustomIconButton(
                  iconData: Icons.refresh_outlined,
                  tooltip: 'تحديث',
                  iconSize: 60,
                  onPressed: () {
                    prov.getDriverRate(widget.userID);
                  }),
            ),
          ],
        );
      },
    );
  }
}

class _ProfileSubItems extends StatelessWidget {
  const _ProfileSubItems({
    Key? key,
    required this.iconData,
    required this.title,
    required this.subtitle,
    this.allowOnlineOnly = true,
    this.allowRegisterOnly = true,
    this.onTab,
  }) : super(key: key);
  final IconData iconData;
  final String title;
  final String subtitle;
  final bool allowOnlineOnly;
  final bool allowRegisterOnly;
  final void Function()? onTab;

  @override
  Widget build(BuildContext context) {
    final isAuthed = Get.find<FirebaseAuthController>().isThereAUserLoggedin;
    return InkWell(
      onTap: onTab == null
          ? null
          : () async {
              if (allowOnlineOnly) {
                final online = Get.find<ConnectionController>().isOnline;
                if (!online) {
                  ShowAnyMessages.showSnackBar(
                    context,
                    noCONNECTIONMSG,
                    isError: true,
                    floating: false,
                  );
                  return;
                }
              }
              if (allowRegisterOnly) {
                final user =
                    Get.find<FirebaseAuthController>().getCurrentUser != null;
                if (!user) {
                  await ShowCustomDialog.notLoggedInUserWithNavigation(context);
                  return;
                }
              }
              onTab!();
            },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        mainAxisSize: MainAxisSize.max,
        children: [
          Icon(
            iconData,
            size: 80.sp,
          ),
          Text(
            !isAuthed ? '--' : subtitle,
            style: TextStyle(
              fontSize: 50.sp,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              color: Colors.blueGrey,
              fontSize: 46.sp,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
