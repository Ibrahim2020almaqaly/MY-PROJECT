import 'dart:io';

import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import 'package:project_first_model/controllers/feedback_controllers/error_report_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_image_picker.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/models/error_report_model.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_card.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_image_viewer.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

@RoutePage()
class ErrorReportScreen extends StatefulWidget {
  const ErrorReportScreen({Key? key}) : super(key: key);

  @override
  State<ErrorReportScreen> createState() => _ErrorReportScreenState();
}

class _ErrorReportScreenState extends State<ErrorReportScreen> {
  final _errorController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  var imagePath = '';
  @override
  void initState() {
    super.initState();
  }

  void _save() async {
    final isValid = _formKey.currentState?.validate() ?? false;
    if (!isValid) {
      return;
    }
    try {
      CustomOverlayLoading.showOverlayLoading();
      _formKey.currentState?.save();

      final authProv = Get.find<FirebaseAuthController>();

      final userID = authProv.getCurrentUser?.uid ?? '';
      if (userID == '') {
        throw CustomException('ليس لديك حساب يرجى تسجيل الدخول أولاَ');
      }

      final valid = await authProv.validToken();
      if (!valid) return;

      final error = ErrorReportModel(
        userID: userID,
        error: _errorController.text.trim(),
        errorScreenImgURL: imagePath,
      );

      // if (!mounted) return;

      await Get.find<ErrorReportController>().addErrorReport(error);

      CustomOverlayLoading.hideOverlayLoading();
      if (!mounted) return;
      ShowAnyMessages.showDialogMessage(
        context,
        'شكراَ لمساهمتك في جعل التطبيق أكثر متانة من خلال التبليغ عن الأخطاء',
        appNAME,
      );
    } on CustomException catch (e) {
      ShowAnyMessages.showSnackBar(context, e.errorMessage);
      CustomOverlayLoading.hideOverlayLoading();
    }
  }

  @override
  void dispose() {
    _errorController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('تبليغ عن أخطاء'),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            reverse: true,
            child: CustomCard(
              title: 'الخطأ',
              children: [
                Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    // crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const VerticalSizedBox(15),
                      CustomTextFormField(
                        label: '',
                        controller: _errorController,
                        textInputAction: TextInputAction.newline,
                        textInputType: TextInputType.multiline,
                        validator: Validators.checkIfNotEmpty,
                        onSaved: null,
                        maxLength: 100,
                        minLines: 5,
                        maxLines: 15,
                        autoFocus: true,
                      ),
                      const VerticalSizedBox(15),
                      CustomTextButton(
                        title: 'إدراج صورة توضيحية',
                        allowOnlineOnly: false,
                        allowRegisterOnly: false,
                        onPressed: () async {
                          final image = await CustomImagePicker.showImagePicker(
                              ImageSource.gallery);
                          if (image == null || image == '') return;
                          setState(() {
                            imagePath = image;
                          });
                        },
                      ),
                      const VerticalSizedBox(15),
                      Padding(
                        padding: CustomEdgeInsets.horizontal(50),
                        child: CustomImageViewer(
                          height: 500.0,
                          image: File(imagePath),
                          enableTabToChoose: false,
                        ),
                      ),
                      const VerticalSizedBox(25),
                      SizedBox(
                        width: double.infinity,
                        child: CustomElevatedIconButton(
                          iconData: Icons.send_outlined,
                          title: 'إرسال',
                          onPressed: _save,
                          padding: 10.0,
                          style: TextStyle(fontSize: 55.sp),
                        ),
                      ),
                      const BottomPadding(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
