import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:project_first_model/controllers/feedback_controllers/suggestion_controller.dart';
import 'package:project_first_model/controllers/user_controllers/firebase_auth_controller.dart';
import 'package:project_first_model/helpers/custom_exception.dart';
import 'package:project_first_model/helpers/custom_overlay_loading.dart';
import 'package:project_first_model/helpers/show_messages.dart';
import 'package:project_first_model/helpers/validators.dart';
import 'package:project_first_model/models/suggestion_model.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_card.dart';
import 'package:project_first_model/widgets/utiles/bottom_padding.dart';
import 'package:project_first_model/widgets/utiles/custom_elevated_button.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_form_field.dart';

@RoutePage()
class SuggestionScreen extends StatefulWidget {
  const SuggestionScreen({Key? key}) : super(key: key);

  @override
  State<SuggestionScreen> createState() => _SuggestionScreenState();
}

class _SuggestionScreenState extends State<SuggestionScreen> {
  final _suggestionController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  void initState() {
    super.initState();
  }

  void _save() async {
    final isValid = _formKey.currentState?.validate() ?? false;
    if (!isValid) {
      return;
    }
    try {
      CustomOverlayLoading.showOverlayLoading();
      _formKey.currentState?.save();

      final authProv = Get.find<FirebaseAuthController>();

      final userID = authProv.getCurrentUser?.uid ?? '';
      if (userID == '') {
        throw CustomException('ليس لديك حساب يرجى تسجيل الدخول أولاَ');
      }

      final valid = await authProv.validToken();
      if (!valid) return;

      final suggestion = SuggestionModel(
        userID: userID,
        suggestion: _suggestionController.text.trim(),
      );
      // if (!mounted) return;

      await Get.find<SuggestionController>().addSuggestion(suggestion);

      CustomOverlayLoading.hideOverlayLoading();
      if (!mounted) return;
      ShowAnyMessages.showDialogMessage(
        context,
        'شكراَ لمساهمتك في جعل التطبيق رائعاَ عن طريق إرسال مقترحاتك إلينا',
        appNAME,
      );
    } on CustomException catch (e) {
      ShowAnyMessages.showSnackBar(context, e.errorMessage);
      CustomOverlayLoading.hideOverlayLoading();
    }
  }

  @override
  void dispose() {
    _suggestionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الآراء والمقترحات'),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: CustomCard(
              title: 'أكتب مقترحاتك',
              children: [
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      const VerticalSizedBox(15),
                      CustomTextFormField(
                        label: '',
                        controller: _suggestionController,
                        textInputAction: TextInputAction.newline,
                        textInputType: TextInputType.multiline,
                        validator: Validators.checkIfNotEmpty,
                        onSaved: null,
                        maxLength: 100,
                        minLines: 5,
                        maxLines: 15,
                        autoFocus: true,
                      ),
                      const VerticalSizedBox(15),
                      SizedBox(
                        width: double.infinity,
                        child: CustomElevatedIconButton(
                          iconData: Icons.send_outlined,
                          title: 'إرسال',
                          onPressed: _save,
                          padding: 10.0,
                          style: TextStyle(fontSize: 55.sp),
                        ),
                      ),

                      const BottomPadding(),
                      // const VerticalSizedBox(15),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
