import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:styled_text/styled_text.dart';

import 'package:project_first_model/controllers/feedback_controllers/privacy_controller.dart';
import 'package:project_first_model/helpers/utiles.dart';
import 'package:project_first_model/models/privacy_model.dart';
import 'package:project_first_model/router/router.dart';
import 'package:project_first_model/services/app_info.dart';
import 'package:project_first_model/widgets/custom_loadings/custom_loading.dart';
import 'package:project_first_model/widgets/helper_widgets/custom_edge_insets.dart';
import 'package:project_first_model/widgets/main_screen_widgets/list_helpers/snapshot_error.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';

@RoutePage()
class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({Key? key}) : super(key: key);
  static const hh = '''
&space;<title_head>سياسة الخصوصية</ title_head>
&space;&space;نحن فريق MASTERZ TEAM قمنا ببناء تطبيق<app_name> رحلة </app_name> كتطبيق مجاني التحميل. 
&space;&space;في إعلان سياسة الخصوصية هذا، قمنا بتجميع جميع المعلومات الأساسية حول كيفية تعاملنا مع بياناتك الشخصية وحقوقك في هذا الصدد، ويمكننا أيضا تغيير إعلان سياسة الخصوصية في أي وقت عن طريق نشر الإصدار الذي تم تغييره على صفحة الويب أو من داخل التطبيق نفسه.
&space;&space;إذا قمت بتحميل التطبيق وتثبيته على جهازك فهذا يعني أنك موافق على سياسة الخصوصية الموضحة أدناه.
&space;<title_head>سياسة الوصول إلى بيانات المستخدمين</ title_head>
&space;&space;1. التطبيق لا يقوم بنسخ أي معلومات أو طلب أي تصاريح من جهاز المستخدم إلا عند الحاجة مثل (طلب تصاريح عمل إشعارات).
&space;&space;2. لا يتم جمع بيانات عن المستخدمين إلا المعلومات الأساسية التي يوفرها المستخدم عند تسجيل الدخول مثل (الاسم، رقم الهاتف، المحافظة، الخ).
&space;&space;3. يتم توفير رقم هاتف السائق للمستخدمين المسجلين في التطبيق فقط.
&space;&space;4. لا يتم مشاركة ارقام هواتف المستخدمين الا مع المستخدمين الذين لديهم حساب في التطبيق.
&space;&space;5. يجب على المستخدم توفير معلومات صحيحة وإذا تم التأكد من عدم صحتها يحق لإدارة التطبيق حظر الحساب.
&space;&space;6. قد يزود بعض المستخدمين ببيانات وهمية او خاطئة وإدارة التطبيق غير مسؤولة عن صحة البيانات.
&space;&space;7. عند توفير صورة للمستخدم أو للمركبة يجب عدم إضافة صورة مخلة للآداب.
&space;&space;8. أي اتفاق بين السائق والراكب يمثل فقط نفسه ونحن غير مسؤولين.
&space;&space;9. يقوم التطبيق بتسجيل وقت الاتصال الذي يتم بين الراكب والسائق إذا تم الاتصال عبر زر التطبيق.
&space;&space;10. يمكن للتطبيق توفير قائمة بالمستخدمين الذين حصلوا على رقمك عبر التطبيق.
&space;<title_head>سياسة التطبيق عند إضافة أي رحلة</ title_head>
&space;&space;1. يجب على السائق الذي وفر الرحلة والزبون الالتزام بالمواعيد.
&space;&space;2. في حالة عدم الالتزام بالمواعيد يتم إعطاء كل من السائق أو الراكب إنذار.
&space;&space;3. يجب على السائق كتابة بيانات واقعية حول معلومات الرحلة وعدم استخدامها للاحتيال.
&space;<title_head>الحماية والأمان</ title_head>
نحن نقدر ثقتك بتقديمك لنا معلوماتك الشخصية حيث نقوم بحماية هذه المعلومات، ولكن يجب أن تذكر أنه لا يوجد أمان بشكل كامل في خدمات الإنترنت أو أمان في وسائل التخزين، ونحن لا نضمن الحماية الكاملة. للخدمات المقدمة على الإنترنت.
&space;<title_head>سياسة التطبيق في حالة انتهاك إحدى السياسات السابقة</ title_head>
&space;&space;1. يحق لإدارة التطبيق حظر المستخدم في حالة عدم الالتزام بمواعيد الرحلات سواء من السائق أو الراكب.
&space;&space;2. في حالة وجود تحايل في الرحلات أو إضرار بالمستخدمين يحق لإدارة التطبيق بإعطاء بيانات المستخدم للجهات الأمنية.
&space;&space;3. يحق لإدارة التطبيق حظر المستخدم في حالة وجود بلاغات عديدة عليه.
&space;4. يحق لإدارة التطبيق حظر وحذف أي حساب للأسباب التي تراها مناسبة.
&space;<title_head>للتواصل معنا</ title_head>
&space;&space;إذا كانت لديك أي استفسارات أو مقترحات حول سياسة الخصوصية لا تتردد في التواصل معنا عبر الإيميل   <link href="mailto: masterzteamsupprt@gmail.com"> masterzteamsupprt@gmail.com </link>
''';
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final privacyProv = Get.find<PrivacyController>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('سياسة الخصوصية'),
        // actions: [
        //   TextButton(
        //     child: const Text('title'),
        //     onPressed: () {
        //       privacyProv.addPrivacy(
        //         const PrivacyModel(privacy: hh),
        //       );
        //     },
        //   ),
        // ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: CustomEdgeInsets.all(16.0),
            child: FutureBuilder<PrivacyModel>(
                future: privacyProv.getPrivacy(),
                builder: (ctx, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CustomLoading(),
                    );
                  } else if (snapshot.hasError || snapshot.data == null) {
                    return SnapshotError(
                      btnText: 'الرجوع',
                      error: snapshot.error,
                      onPressed: () {
                        // Get.back();
                        Get.find<AppRouter>().pop();
                      },
                    );
                  }

                  final privacy = snapshot.data;
                  if (privacy == PrivacyModel.defaultPrivacy) {
                    return SnapshotError(
                      btnText: 'الرجوع',
                      error: snapshot.error,
                      onPressed: () {
                        Get.find<AppRouter>().pop();
                        // Get.back();
                      },
                    );
                  }

                  return Column(
                    children: [
                      AppInfo.appIcon(
                        radius: 100.0,
                        circle: 200,
                      ),
                      const VerticalSizedBox(12),
                      AppInfo.getAppInfo,
                      const VerticalSizedBox(25),
                      StyledText(
                        text: privacy!.privacy,
                        style: TextStyle(
                          fontSize: 44.sp,
                          fontFamily: 'Cairo',
                          leadingDistribution: TextLeadingDistribution.even,
                        ),
                        textAlign: TextAlign.start,
                        strutStyle: const StrutStyle(
                          leading: 2,
                        ),
                        textDirection: TextDirection.rtl,
                        tags: {
                          'title_head': StyledTextTag(
                            style: TextStyle(
                              fontSize: 55.sp,
                              color: theme.appBarTheme.actionsIconTheme?.color,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          'app_name': StyledTextTag(
                            style: TextStyle(
                              fontSize: 50.sp,
                              color: theme
                                  .floatingActionButtonTheme.backgroundColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          'link': StyledTextActionTag(
                            (text, attributes) async {
                              final link = attributes['href']!;
                              Utiles.email(link, isLinkFull: true);
                            },
                            style: TextStyle(
                              decoration: TextDecoration.underline,
                              color: theme.appBarTheme.actionsIconTheme?.color,
                            ),
                          ),
                        },
                      ),
                      const VerticalSizedBox(20.0),
                      AppInfo.getDevloperTeamNameWidget,
                      const VerticalSizedBox(20.0),
                    ],
                  );
                }),
          ),
        ),
      ),
    );
  }
}
