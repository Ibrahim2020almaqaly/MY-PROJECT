import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:project_first_model/services/app_info.dart';
import 'package:project_first_model/widgets/utiles/custom_sized_box.dart';
import 'package:project_first_model/widgets/utiles/custom_text_button.dart';

@RoutePage()
class AboutScreen extends StatelessWidget {
  const AboutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                AppInfo.getAppName,
                style: TextStyle(
                  fontSize: 60.sp,
                ),
              ),
              const VerticalSizedBox(15),
              Text(
                'Version ${AppInfo.getAppVersion}',
                style: TextStyle(
                  fontSize: 50.sp,
                  color: Colors.grey,
                ),
              ),
              const VerticalSizedBox(20),
              AppInfo.appIcon(
                circle: 400,
                radius: 180,
              ),
              const VerticalSizedBox(20),
              Text(
                AppInfo.getTeamInfo,
                style: TextStyle(
                  fontSize: 50.sp,
                  color: Colors.grey,
                ),
              ),
              const VerticalSizedBox(30),
              CustomTextButton(
                allowOnlineOnly: false,
                allowRegisterOnly: false,
                title: 'التراخيص',
                textStyle: TextStyle(
                  fontSize: 50.sp,
                  decoration: TextDecoration.underline,
                ),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => LicensePage(
                        applicationIcon: AppInfo.appIcon(
                          circle: 200,
                          radius: 100,
                        ),
                        applicationName: AppInfo.getAppName,
                        applicationVersion: AppInfo.getAppVersion,
                        applicationLegalese: AppInfo.getTeamInfo,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
