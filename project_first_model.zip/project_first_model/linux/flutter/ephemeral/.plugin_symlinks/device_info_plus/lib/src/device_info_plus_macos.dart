/// The platform interface handles the method channel calls. This file exists to silence errors on pub.
